import { Observable, Subject, BehaviorSubject, ReplaySubject } from 'rxjs';
import * as i0 from '@angular/core';
import { OnInit, OnDestroy, EventEmitter, InjectionToken, ModuleWithProviders, ElementRef, Renderer2, AfterViewInit, QueryList, RendererFactory2, AfterContentInit, OnChanges, SimpleChanges, TemplateRef, ExistingProvider, ChangeDetectorRef, ViewContainerRef, PipeTransform, AfterViewChecked, DoCheck, StaticProvider, TrackByFunction } from '@angular/core';
import * as i1 from '@angular/cdk/a11y';
import { FocusOrigin, FocusMonitor, FocusableOption, FocusKeyManager } from '@angular/cdk/a11y';
import * as i3 from '@angular/cdk/platform';
import * as i6 from 'angular-split';
import { SplitAreaComponent } from 'angular-split';
import * as i2 from '@angular/common';
import { WeekDay } from '@angular/common';
import * as i3$1 from '@angular/router';
import { NavigationExtras } from '@angular/router';
import * as i3$2 from '@angular/forms';
import { ControlValueAccessor, NgModel, FormGroupDirective, Validator, ValidationErrors } from '@angular/forms';
import { BooleanInput, NumberInput } from '@angular/cdk/coercion';
import * as i2$1 from '@angular/cdk/overlay';
import { Overlay, ScrollDispatcher, OverlayRef } from '@angular/cdk/overlay';
import * as i3$3 from '@angular/cdk/observers';
import { ComponentPortal, DomPortalOutlet, TemplatePortal } from '@angular/cdk/portal';
import * as i2$2 from '@angular/cdk/drag-drop';
import { CdkDragHandle, CdkDrag, CdkDropList, CdkDragEnter } from '@angular/cdk/drag-drop';
import { ViewportRuler } from '@angular/cdk/scrolling';
import { SafeHtml } from '@angular/platform-browser';
import * as _ux_aspects_ux_aspects from '@ux-aspects/ux-aspects';
import { HierarchyPointNode, HierarchyRectangularNode } from 'd3';
import { ArrayDataSource } from '@angular/cdk/collections';
import * as i3$4 from '@angular/cdk/tree';
import { FlatTreeControl } from '@angular/cdk/tree';
import { AnimationEvent } from '@angular/animations';
import { Chart } from 'chart.js';

declare enum Color {
    Primary = "primary",
    Accent = "accent",
    Secondary = "secondary",
    Alternate1 = "alternate1",
    Alternate2 = "alternate2",
    Alternate3 = "alternate3",
    Vibrant1 = "vibrant1",
    Vibrant2 = "vibrant2",
    Grey1 = "grey1",
    Grey2 = "grey2",
    Grey3 = "grey3",
    Grey4 = "grey4",
    Grey5 = "grey5",
    Grey6 = "grey6",
    Grey7 = "grey7",
    Grey8 = "grey8",
    Chart1 = "chart1",
    Chart2 = "chart2",
    Chart3 = "chart3",
    Chart4 = "chart4",
    Chart5 = "chart5",
    Chart6 = "chart6",
    Ok = "ok",
    Warning = "warning",
    Critical = "critical",
    Partition1 = "partition1",
    Partition9 = "partition9",
    Partition10 = "partition10",
    Partition11 = "partition11",
    Partition12 = "partition12",
    Partition13 = "partition13",
    Partition14 = "partition14",
    SocialChartNode = "social-chart-node",
    SocialChartEdge = "social-chart-edge"
}

/**
 * Determine the type of icon based upon the identifier.
 *
 * We support the following iconset:
 *
 * - `ux-icon` - UX Icon Set
 * - `component` - Component icon not tied to a specific set
 *
 * @param identifier - The name of the icon
 */
declare function getIconType(identifier: string | null): IconType;
declare enum IconType {
    UxIcon = "ux-icon",
    Component = "component"
}

/**
 * This is a simple RxJS operator to allow us to avoid the
 * "expression has changed after it was checked issue"
 * by making the subscription asynchronous. We could just use a
 * delay operator but this uses a timeout which is significantly
 * slower than using requestAnimationFrame.
 */
declare const tick: <T>() => (source: Observable<T>) => Observable<T>;

type AnchorAlignment = 'start' | 'center' | 'end';

type AnchorPlacement = 'top' | 'right' | 'bottom' | 'left';

/**
 * A button will trigger a click event whenever the a mouse click occurs or the enter key is pressed.
 * These functions can be used to identify if a `click` event was caused by the keyboard or
 * by a mouse.
 *
 * The `event.detail` property will change based on the source of the event.
 * A mouse click will have varying values based on the browser, however
 * the enter key will always have a value of `0` so we can check against that
 */
declare function isKeyboardTrigger(event: MouseEvent | KeyboardEvent): boolean;
declare function isMouseTrigger(event: MouseEvent | KeyboardEvent): boolean;

declare class AccordionPanelHeadingDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionPanelHeadingDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AccordionPanelHeadingDirective, "ux-accordion-panel-header", never, {}, {}, never, never, true, never>;
}

declare class AccordionService {
    collapseOthers: boolean;
    collapse: Subject<void>;
    collapseAll(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccordionService>;
}

declare class AccordionPanelComponent implements OnInit, OnDestroy {
    readonly accordion: AccordionService;
    panelId: string;
    headingId: string;
    disabled: boolean;
    heading: string;
    expanded: boolean;
    expandedChange: EventEmitter<boolean>;
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    toggle(): void;
    expand(): void;
    collapse(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccordionPanelComponent, "ux-accordion-panel", never, { "panelId": { "alias": "panelId"; "required": false; }; "headingId": { "alias": "headingId"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "heading": { "alias": "heading"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "expandedChange": "expandedChange"; }, never, ["ux-accordion-panel-header", "*"], true, never>;
}

declare class AccordionComponent {
    private readonly _accordion;
    set collapseOthers(collapseOthers: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccordionComponent, "ux-accordion", never, { "collapseOthers": { "alias": "collapseOthers"; "required": false; }; }, {}, never, ["*"], true, never>;
}

interface AccessibilityOptions {
    /** Indicate whether or not mouse events should cause the focus indicator to appear */
    mouseFocusIndicator?: boolean;
    /** Indicate whether or not touch events should cause the focus indicator to appear */
    touchFocusIndicator?: boolean;
    /** Indicate whether or not keyboard events should cause the focus indicator to appear */
    keyboardFocusIndicator?: boolean;
    /** Indicate whether or not programmatic events should cause the focus indicator to appear */
    programmaticFocusIndicator?: boolean;
}

declare const colorSets: {
    keppel: {
        colorValueSet: {
            primary: string;
            accent: string;
            secondary: string;
            alternate1: string;
            alternate2: string;
            alternate3: string;
            vibrant1: string;
            vibrant2: string;
            grey1: string;
            grey2: string;
            grey3: string;
            grey4: string;
            grey5: string;
            grey6: string;
            grey7: string;
            grey8: string;
            chart1: string;
            chart2: string;
            chart3: string;
            chart4: string;
            chart5: string;
            chart6: string;
            ok: string;
            warning: string;
            critical: string;
            partition1: string;
            partition9: string;
            partition10: string;
            partition11: string;
            partition12: string;
            partition13: string;
            partition14: string;
            'social-chart-node': string;
            'social-chart-edge': string;
        };
    };
    microFocus: {
        colorValueSet: {
            'brand-blue': string;
            cerulean: string;
            aqua: string;
            aquamarine: string;
            fuchsia: string;
            indigo: string;
            'dark-blue': string;
            white: string;
            'slightly-gray': string;
            'bright-gray': string;
            gray: string;
            silver: string;
            'dim-gray': string;
            'dark-gray': string;
            black: string;
            'crimson-negative': string;
            apricot: string;
            yellow: string;
            'green-positive': string;
            ultramarine: string;
            skyblue: string;
            'pale-aqua': string;
            'pale-green': string;
            lime: string;
            orange: string;
            magenta: string;
            'pale-purple': string;
            'dark-ultramarine': string;
            steelblue: string;
            'arctic-blue': string;
            emerald: string;
            olive: string;
            goldenrod: string;
            purple: string;
            'pale-eggplant': string;
            red: string;
            'pale-amber': string;
            'pale-lemon': string;
            'pale-emerald': string;
            plum: string;
            copper: string;
            amber: string;
            'leaf-green': string;
            'forest-green': string;
            primary: string;
            accent: string;
            secondary: string;
            alternate1: string;
            alternate2: string;
            alternate3: string;
            vibrant1: string;
            vibrant2: string;
            grey1: string;
            grey2: string;
            grey3: string;
            grey4: string;
            grey5: string;
            grey6: string;
            grey7: string;
            grey8: string;
            chart1: string;
            chart2: string;
            chart3: string;
            chart4: string;
            chart5: string;
            chart6: string;
            info: string;
            ok: string;
            warning: string;
            danger: string;
            critical: string;
            partition1: string;
            partition9: string;
            partition10: string;
            partition11: string;
            partition12: string;
            partition13: string;
            partition14: string;
            'social-chart-node': string;
            'social-chart-edge': string;
        };
    };
};
type ColorSet = {
    colorValueSet: {
        [key: string]: string;
    };
};
/** Provide a default color set for an application */
declare const COLOR_SET_TOKEN: InjectionToken<ColorSet>;

declare class ColorServiceModule {
    /**
     * The function allows the consuming applications to specify the applications
     * color set once in the app module, eg:
     * ```
     * ColorServiceModule.forRoot(colorSets.microFocus);
     * ```
     * @param colorSet The color set the application should use
     */
    static forRoot(colorSet: ColorSet): ModuleWithProviders<ColorServiceModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorServiceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ColorServiceModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ColorServiceModule>;
}

declare class AccessibilityOptionsService {
    /** Get the user specified options - but handle cases where they may not be specified */
    readonly _options: AccessibilityOptions;
    /** Determine the default options */
    private readonly _defaultOptions;
    /** Get the complete options populating unspecified options with the default values */
    get options(): AccessibilityOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccessibilityOptionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccessibilityOptionsService>;
}

declare class LocalFocusIndicatorOptions implements AccessibilityOptions {
    mouseFocusIndicator: boolean;
    touchFocusIndicator: boolean;
    keyboardFocusIndicator: boolean;
    programmaticFocusIndicator: boolean;
}

declare class FocusIndicatorDirective implements OnInit, OnDestroy {
    readonly optionsService: AccessibilityOptionsService;
    private readonly _elementRef;
    private readonly _focusIndicatorService;
    private readonly _ngZone;
    readonly localOptions: LocalFocusIndicatorOptions;
    /** Specify whether or not we should mark this element as having focus if a child is focused */
    set checkChildren(checkChildren: boolean | string);
    /** Indicate whether or not mouse events should cause the focus indicator to appear - will override any global setting */
    set mouseFocusIndicator(mouseFocusIndicator: boolean | string);
    /** Indicate whether or not touch events should cause the focus indicator to appear - will override any global setting */
    set touchFocusIndicator(touchFocusIndicator: boolean | string);
    /** Indicate whether or not keyboard events should cause the focus indicator to appear - will override any global setting */
    set keyboardFocusIndicator(keyboardFocusIndicator: boolean | string);
    /** Indicate whether or not programmatic events should cause the focus indicator to appear - will override any global setting */
    set programmaticFocusIndicator(programmaticFocusIndicator: boolean | string);
    /** Emit the latest focus state */
    indicator: EventEmitter<boolean>;
    /** Store a private reference for the checkChildren option */
    private _checkChildren;
    /** Store all configuation options*/
    private readonly _options;
    /** Store a reference to the focus handler */
    private _focusIndicator;
    /** Unsubscribe on component destroy */
    private readonly _onDestroy;
    constructor();
    /** Setup the focus monitoring */
    ngOnInit(): void;
    /** Tear down the directive */
    ngOnDestroy(): void;
    /** Focus this element with a specific origin */
    focus(origin?: FocusOrigin, options?: {
        preventScroll: boolean;
    }): void;
    /** Update the focus indicator with the latest options */
    private setOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusIndicatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FocusIndicatorDirective, "[uxFocusIndicator]", ["ux-focus-indicator"], { "checkChildren": { "alias": "checkChildren"; "required": false; }; "mouseFocusIndicator": { "alias": "mouseFocusIndicator"; "required": false; }; "touchFocusIndicator": { "alias": "touchFocusIndicator"; "required": false; }; "keyboardFocusIndicator": { "alias": "keyboardFocusIndicator"; "required": false; }; "programmaticFocusIndicator": { "alias": "programmaticFocusIndicator"; "required": false; }; }, { "indicator": "indicator"; }, never, never, true, never>;
}

/**
 * This directive can be used to target specific elements based on their CSS
 * class so we can control when the focus shows. This will help prevent us
 * polluting the FocusIndicatorDirective with an lot of selectors.
 *
 * If the button has a uxFocusIndicator, uxMenuTriggerFor or uxMenuNavigationToggle directive applied we should skip this
 */
declare class DefaultFocusIndicatorDirective extends FocusIndicatorDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultFocusIndicatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultFocusIndicatorDirective, ".btn:not([uxFocusIndicator]):not([uxMenuNavigationToggle]):not([uxMenuTriggerFor]), a[href]:not([uxFocusIndicator]):not([uxMenuNavigationToggle]):not([uxMenuTriggerFor])", never, {}, {}, never, never, true, never>;
}

declare class FocusIndicatorOptionsDirective implements AccessibilityOptions {
    private readonly _options;
    /** If `true`, this element will receive a focus indicator when the element is clicked on. */
    set mouseFocusIndicator(mouseFocusIndicator: boolean);
    /** If `true`, this element will receive a focus indicator when the element is touched. */
    set touchFocusIndicator(touchFocusIndicator: boolean);
    /** If `true`, this element will receive a focus indicator when the element is focused using the keyboard. */
    set keyboardFocusIndicator(keyboardFocusIndicator: boolean);
    /** If `true`, this element will receive a focus indicator when the element is programmatically focused. */
    set programmaticFocusIndicator(programmaticFocusIndicator: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusIndicatorOptionsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FocusIndicatorOptionsDirective, "[uxFocusIndicatorOptions]", never, { "mouseFocusIndicator": { "alias": "mouseFocusIndicator"; "required": false; }; "touchFocusIndicator": { "alias": "touchFocusIndicator"; "required": false; }; "keyboardFocusIndicator": { "alias": "keyboardFocusIndicator"; "required": false; }; "programmaticFocusIndicator": { "alias": "programmaticFocusIndicator"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FocusIndicatorOriginService {
    /** Store the most recent origin event */
    private _origin;
    /** Store the event source origin */
    setOrigin(origin: FocusOrigin): void;
    /** Get the most recent event origin */
    getOrigin(): FocusOrigin | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusIndicatorOriginService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FocusIndicatorOriginService>;
}

declare class FocusIndicatorOriginDirective implements OnDestroy {
    readonly focusOriginService: FocusIndicatorOriginService;
    readonly elementRef: ElementRef<any>;
    readonly renderer: Renderer2;
    /** Store the instance of the focus indicator origin */
    private readonly _focusOrigin;
    constructor();
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusIndicatorOriginDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FocusIndicatorOriginDirective, "[uxFocusIndicatorOrigin]", never, {}, {}, never, never, true, never>;
}

declare class FocusWithinDirective implements OnDestroy {
    private readonly _elementRef;
    /** Emits when a child element gains focus */
    uxFocusWithin: EventEmitter<void>;
    /** Emits when a child element loses focus */
    uxBlurWithin: EventEmitter<void>;
    /**
     * Note: We used to use @angular/cdk FocusMonitor here instead of manually listening
     * to focus blur events, however this was problematic as any child elements using the FocusMonitor,
     * eg: `uxFocusIndicator` which not get the correct `origin`, they will instead get a programmatic
     * origin even if it was clicked or focused via the keyboard.
     */
    constructor();
    ngOnDestroy(): void;
    private onFocus;
    private onBlur;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusWithinDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FocusWithinDirective, "[uxFocusWithin],[uxBlurWithin]", never, {}, { "uxFocusWithin": "uxFocusWithin"; "uxBlurWithin": "uxBlurWithin"; }, never, never, true, never>;
}

declare class ManagedFocusContainerDirective implements OnInit, OnDestroy {
    private readonly _elementRef;
    private readonly _managedFocusContainerService;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ManagedFocusContainerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ManagedFocusContainerDirective, "[uxManagedFocusContainer]", never, {}, {}, never, never, true, never>;
}

declare class SplitterAccessibilityDirective implements OnInit, AfterViewInit, OnDestroy {
    private readonly _elementRef;
    private readonly _renderer;
    private readonly _splitter;
    private readonly _focusIndicatorService;
    private readonly _platform;
    /** Emit an event whenever the gutter is moved using the keyboard */
    gutterKeydown: EventEmitter<KeyboardEvent>;
    /** Find all the split areas */
    areas: QueryList<SplitAreaComponent>;
    /** Store all the gutter elements */
    private _gutters;
    /** Watch for gutters being added or removed */
    private _observer;
    /** Teardown our observables on destroy */
    private readonly _onDestroy;
    /** Store references to all focus indicators */
    private _focusIndicators;
    ngOnInit(): void;
    /** Once initialised make the gutters accessible */
    ngAfterViewInit(): void;
    /** Destroy all observables and observers */
    ngOnDestroy(): void;
    /** We should focus the gutter when it is clicked */
    onClick(event: MouseEvent): void;
    /** Find all the gutters and set their attributes */
    private onGutterChange;
    /** Get all the gutter elements */
    private getGutters;
    /** Set the appropriate attributes on the gutter elements */
    private setGutterAttributes;
    /** Apply the aria attribute values */
    private updateGutterAttributes;
    /** Apply the value now aria attribute */
    private setGutterValueNow;
    /** Apply the value min aria attribute */
    private setGutterValueMin;
    /** Apply the value max aria attribute */
    private setGutterValueMax;
    onKeydown(event: KeyboardEvent): void;
    onIncreaseKey(event: KeyboardEvent): void;
    onDecreaseKey(event: KeyboardEvent): void;
    onHomeKey(event: KeyboardEvent): void;
    onEndKey(event: KeyboardEvent): void;
    /** Determine if an element is a gutter */
    private isSplitterGutter;
    /** Update the gutter position */
    private setGutterPosition;
    /** Get the split areas associated with a given gutter */
    private getAreasFromGutter;
    static ɵfac: i0.ɵɵFactoryDeclaration<SplitterAccessibilityDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SplitterAccessibilityDirective, "as-split", never, {}, { "gutterKeydown": "gutterKeydown"; }, ["areas"], never, true, never>;
}

interface FocusIndicatorOptions extends AccessibilityOptions {
    checkChildren: boolean;
}

declare class FocusIndicator {
    private readonly _element;
    private readonly _focusMonitor;
    private readonly _renderer;
    private _options;
    private readonly _focusIndicatorOrigin;
    /** Apply a class when the item is focused */
    set isFocused(isFocused: boolean);
    /** Provide a convenience getter to allow access to focus state without a subscription */
    get isFocused(): boolean;
    /** An observable to monitor the focus state */
    readonly isFocused$: BehaviorSubject<boolean>;
    /** An observable to monitor the focus origin */
    readonly origin$: Subject<FocusOrigin>;
    /** Remove all subscriptions on destroy */
    private readonly _onDestroy;
    constructor(_element: HTMLElement, _focusMonitor: FocusMonitor, _renderer: Renderer2, _options: FocusIndicatorOptions, _focusIndicatorOrigin: FocusIndicatorOriginService);
    /** Setup the focus monitoring */
    private initialise;
    /** Focus the element with a specific origin */
    focus(origin?: FocusOrigin, options?: {
        preventScroll?: boolean;
    }): void;
    /** Tear down the subscriptions */
    destroy(): void;
    /** Allow the options to be updates */
    setOptions(options: FocusIndicatorOptions): void;
    /** Monitor changes to an elements focus state */
    private onFocusChange;
}

declare class FocusIndicatorService {
    private readonly _localOptions;
    readonly rendererFactory: RendererFactory2;
    private readonly _focusMonitor;
    private readonly _globalOptions;
    private readonly _focusIndicatorOrigin;
    /** We need the renderer to add and remove classes */
    private readonly _renderer;
    constructor();
    /** This is essentially just a factory method to prevent the user having to pass in focus monitor, renderer and global options each time */
    monitor(element: HTMLElement, options?: FocusIndicatorOptions): FocusIndicator;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusIndicatorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FocusIndicatorService>;
}

declare class TabbableListItemDirective implements FocusableOption, OnDestroy {
    /** Access the service to programmatically control focus indicators */
    readonly focusIndicatorService: FocusIndicatorService;
    /** Access the tabbable list service */
    private readonly _tabbableList;
    /** Access the tabbable item element */
    private readonly _elementRef;
    /** Access the service responsible for handling focus in child elements */
    private readonly _managedFocusContainerService;
    /** Access the service which can provide us with browser identification */
    private readonly _platform;
    /** Access the change detector to ensure tabindex gets updated as expects */
    private readonly _changeDetector;
    /** Access the focus origin if one is provided */
    private readonly _focusOriginService;
    /** Access the renderer to make manual dom manipulations */
    private readonly _renderer;
    /** Indicate the parent tabbable list item if one is present. */
    parent: TabbableListItemDirective;
    rank: number;
    /** Indicate if this item is disabled */
    disabled: boolean;
    /** Indicate if the item is expanded if used as a hierarchical item. */
    expanded: boolean;
    /** Provide a unique key to help identify items when used in a virtual list */
    set key(key: any);
    get key(): any;
    /** Emit when the expanded state changes. */
    expandedChange: EventEmitter<boolean>;
    /** Emit when the element receives focus via the tabbable list. */
    activated: EventEmitter<FocusOrigin>;
    get tabindex(): number;
    /** Give each tabbable item a unique id */
    id: number;
    /** Each item in the list needs to be initialised by the service. When the item QueryList changes this is used to identify which items previously existed and which are new */
    initialized: boolean;
    /** Store a list of all child tabbable items */
    children: TabbableListItemDirective[];
    /** Emit whenever the expanded state changes */
    keyboardExpanded$: Subject<boolean>;
    /** Automatically unsubscribe from all observables */
    private readonly _onDestroy;
    /** Store a reference to the focus indicator instance */
    private readonly _focusIndicator;
    /** Store the current key - it may change in a ngFor/uxVirtualFor if the cell is reused. */
    private _key;
    /** Store a default key to use if one is not provided */
    private readonly _defaultKey;
    /** Determine if this element has a focus indicator visible */
    private _focusOrigin;
    constructor();
    onInit(): void;
    ngOnDestroy(): void;
    focus(): void;
    onFocus(): void;
    onBlur(): void;
    onKeydown(event: KeyboardEvent): void;
    getFocused(): boolean;
    /** We can programmatically focus an element but may want a different origin than 'programmatic' */
    focusWithOrigin(origin: FocusOrigin, preventScroll?: boolean): void;
    private isTabbable;
    private setTabIndex;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabbableListItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TabbableListItemDirective, "[uxTabbableListItem]", ["ux-tabbable-list-item"], { "parent": { "alias": "parent"; "required": false; }; "rank": { "alias": "rank"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "key": { "alias": "key"; "required": false; }; }, { "expandedChange": "expandedChange"; "activated": "activated"; }, never, never, true, never>;
}

declare class TabbableListDirective implements AfterContentInit, OnDestroy {
    /** Access the tabbable list service */
    private readonly _tabbableList;
    /** Access the native dom element */
    readonly elementRef: ElementRef<any>;
    /** Determine whether the up/down arrows should be used or the left/right arrows */
    direction: 'horizontal' | 'vertical';
    /** Indicate whether or not focus should loop back to the first element after the last */
    wrap: boolean;
    /** Indicate whether or not the first item should receive focus on show - useful for modals and popovers */
    focusOnShow: boolean;
    /** Indicate whether or not focus should be returned to the previous element (only applicable when using focusOnShow) */
    returnFocus: boolean;
    /** Enabling handling of hierarchical lists via use of the `TabbableListItemDirective.parent` property. */
    set hierarchy(value: boolean);
    /** Prevent keyboard interaction when alt modifier key is pressed */
    set allowAltModifier(value: boolean);
    /** Prevent keyboard interaction when ctrl modifier key is pressed */
    set allowCtrlModifier(value: boolean);
    /** Focus the first or last item when Home or End keys are pressed */
    set allowBoundaryKeys(value: boolean);
    /** Find all tabbable list items */
    items: QueryList<TabbableListItemDirective>;
    /** Store the currently focused HTML element */
    private _focusedElement;
    /** Store the items in a specific order */
    private _orderedItems;
    /** Unsubscribe from all observables automatically on destroy */
    private readonly _onDestroy;
    get focusKeyManager(): FocusKeyManager<TabbableListItemDirective>;
    constructor();
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    setFirstItemTabbable(): void;
    focus(): void;
    focusTabbableItem(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabbableListDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TabbableListDirective, "[uxTabbableList]", ["ux-tabbable-list"], { "direction": { "alias": "direction"; "required": false; }; "wrap": { "alias": "wrap"; "required": false; }; "focusOnShow": { "alias": "focusOnShow"; "required": false; }; "returnFocus": { "alias": "returnFocus"; "required": false; }; "hierarchy": { "alias": "hierarchy"; "required": false; }; "allowAltModifier": { "alias": "allowAltModifier"; "required": false; }; "allowCtrlModifier": { "alias": "allowCtrlModifier"; "required": false; }; "allowBoundaryKeys": { "alias": "allowBoundaryKeys"; "required": false; }; }, {}, ["items"], never, true, never>;
}

declare class ColorContrastDirective {
    private readonly _colorService;
    private readonly _contrastService;
    /**
     * Define the background color for contrast comparison.
     * This can be a CSS color value or the name of a
     * color from the color palette.
     */
    set uxColorContrast(backgroundColor: string);
    /**
     * Define the light color for contrast comparison.
     * This can be a CSS color value or the name of a
     * color from the color palette.
     */
    set lightColor(lightColor: string);
    /**
     * Define the dark color for contrast comparison.
     * This can be a CSS color value or the name of a
     * color from the color palette.
     */
    set darkColor(darkColor: string);
    /** Determine the color to set based on the supplied parameters */
    get _color(): string | null;
    /** Store the background color as a ThemeColor object */
    private _backgroundColor;
    /** Store the light color as a ThemeColor object */
    private _lightColor;
    /** Store the light color as a ThemeColor object */
    private _darkColor;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorContrastDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ColorContrastDirective, "[uxColorContrast]", never, { "uxColorContrast": { "alias": "uxColorContrast"; "required": false; }; "lightColor": { "alias": "lightColor"; "required": false; }; "darkColor": { "alias": "darkColor"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AccessibilityModule {
    static forRoot(options: AccessibilityOptions): ModuleWithProviders<AccessibilityModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccessibilityModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccessibilityModule, never, [typeof i1.A11yModule, typeof ColorServiceModule, typeof i3.PlatformModule, typeof DefaultFocusIndicatorDirective, typeof FocusIndicatorDirective, typeof FocusIndicatorOptionsDirective, typeof FocusIndicatorOriginDirective, typeof FocusWithinDirective, typeof ManagedFocusContainerDirective, typeof SplitterAccessibilityDirective, typeof TabbableListDirective, typeof TabbableListItemDirective, typeof FocusIndicatorOriginDirective, typeof ColorContrastDirective], [typeof DefaultFocusIndicatorDirective, typeof FocusIndicatorDirective, typeof FocusIndicatorOptionsDirective, typeof FocusIndicatorOriginDirective, typeof FocusWithinDirective, typeof ManagedFocusContainerDirective, typeof SplitterAccessibilityDirective, typeof TabbableListDirective, typeof TabbableListItemDirective, typeof FocusIndicatorOriginDirective, typeof ColorContrastDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccessibilityModule>;
}

declare class AccordionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccordionModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof AccordionComponent, typeof AccordionPanelComponent, typeof AccordionPanelHeadingDirective], [typeof AccordionComponent, typeof AccordionPanelComponent, typeof AccordionPanelHeadingDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccordionModule>;
}

declare class AlertIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AlertIconDirective, "[uxAlertIcon]", never, {}, {}, never, never, true, never>;
}

declare class AlertComponent {
    private readonly colorService;
    /** Determine the style of the alert */
    type: AlertType;
    /** Determine the the alert can be dismissed */
    dismissible: boolean;
    /** Define a custom background color */
    backgroundColor: string;
    /** Define a custom foreground color */
    foregroundColor: string;
    /** Define a custom aria label for the dismiss button */
    dismissAriaLabel: string;
    /** Emit when the dismiss button is pressed */
    dismiss: EventEmitter<void>;
    /** Identify if we have an icon */
    icon: AlertIconDirective;
    /** Resolve the background color from the color set */
    get _backgroundColor(): string;
    /** Resolve the foreground color from the color set */
    get _foregroundColor(): string;
    /** Determine if we are using a prefined type or custom colors */
    get _isCustomColor(): boolean;
    private getColor;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertComponent, "ux-alert", never, { "type": { "alias": "type"; "required": false; }; "dismissible": { "alias": "dismissible"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "foregroundColor": { "alias": "foregroundColor"; "required": false; }; "dismissAriaLabel": { "alias": "dismissAriaLabel"; "required": false; }; }, { "dismiss": "dismiss"; }, ["icon"], ["[uxAlertIcon]", "*"], true, never>;
}
type AlertType = 'info' | 'error' | 'warning' | 'success' | 'dark';

interface IconDefinition {
    name: string;
    iconset: string;
    icon: string;
    size?: string | string[];
}
/**
 * This is an internal interface that ensures size is a string
 * and not an array as internally we will store an individual record
 * for each size but we allow the user to pass us definitions with an
 * array for convenience.
 */
interface SingleIconDefinition extends IconDefinition {
    size?: string;
}

interface IconModuleOptions {
    /**
     * Define the default iconset or additional custom icons
     */
    icons?: ReadonlyArray<IconDefinition>;
}

declare class IconComponent implements OnChanges, AfterViewInit, OnDestroy {
    private readonly _elementRef;
    private readonly _renderer;
    private readonly _iconService;
    /** Define the icon to display */
    name: string;
    /** Define a custom size for the icon */
    size: string;
    /** The number of degrees to rotate the icon */
    set rotate(rotation: IconRotation | number);
    get rotate(): IconRotation | number;
    /** Define if the icon should be horizontally flipped */
    set flipHorizontal(flipHorizontal: boolean);
    get flipHorizontal(): boolean;
    /** Define if the icon should be horizontally flipped */
    set flipVertical(flipVertical: boolean);
    get flipVertical(): boolean;
    /** Store the matching icon definition */
    _icon: IconDefinition;
    /** Store the numeric value of rotation */
    private _rotate;
    /** Store the boolean value of flip vertical */
    private _flipVertical;
    /** Store the boolean value of flip horizontal */
    private _flipHorizontal;
    /** Automatically unsubscribe from observables */
    private readonly _onDestroy;
    /** When inputs change ensure we have the best icon definition */
    ngOnChanges(changes: SimpleChanges): void;
    /** Watch for changes to the iconset */
    ngAfterViewInit(): void;
    /** Cleanup on component destroy */
    ngOnDestroy(): void;
    /** get the icon definition based on the name and size specified */
    updateIcon(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconComponent, "ux-icon", never, { "name": { "alias": "name"; "required": false; }; "size": { "alias": "size"; "required": false; }; "rotate": { "alias": "rotate"; "required": false; }; "flipHorizontal": { "alias": "flipHorizontal"; "required": false; }; "flipVertical": { "alias": "flipVertical"; "required": false; }; }, {}, never, never, true, never>;
}
type IconRotation = 90 | 180 | 270;

declare class IconModule {
    /** Allow configuration at AppModule level */
    static forRoot(options?: IconModuleOptions): ModuleWithProviders<IconModule>;
    /** Allow configuration at a child module level */
    static forChild(options?: IconModuleOptions): ModuleWithProviders<IconModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IconModule, never, [typeof IconComponent], [typeof IconComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IconModule>;
}

declare class AlertModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AlertModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof IconModule, typeof AlertComponent, typeof AlertIconDirective], [typeof AlertComponent, typeof AlertIconDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AlertModule>;
}

declare class BreadcrumbsComponent {
    /** The list of breadcrumbs to display. */
    crumbs: ReadonlyArray<Breadcrumb>;
    clickCrumb(event: MouseEvent, crumb: Breadcrumb): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbsComponent, "ux-breadcrumbs", never, { "crumbs": { "alias": "crumbs"; "required": false; }; }, {}, never, never, true, never>;
}
interface Breadcrumb {
    title: string;
    routerLink?: string;
    fragment?: string;
    queryParams?: unknown;
    onClick?: (event: MouseEvent) => void;
}

declare class BreadcrumbsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BreadcrumbsModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof i3$1.RouterModule, typeof BreadcrumbsComponent], [typeof BreadcrumbsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BreadcrumbsModule>;
}

declare class ResizeService implements OnDestroy {
    private readonly _zone;
    private readonly _observer;
    private readonly _targets;
    ngOnDestroy(): void;
    addResizeListener(target: HTMLElement): ReplaySubject<ResizeDimensions>;
    removeResizeListener(target: HTMLElement): void;
    private elementDidResize;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResizeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ResizeService>;
}
interface ResizeDimensions {
    width: number;
    height: number;
}

declare class ResizeDirective implements OnInit, OnDestroy {
    private readonly _elementRef;
    private readonly _resizeService;
    private readonly _ngZone;
    /** Debounce the resize event emitter */
    throttle: number;
    /** Emits whenever a resize event occurs */
    uxResize: EventEmitter<ResizeDimensions>;
    /** Remove all subscriptions on component destroy */
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResizeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ResizeDirective, "[uxResize]", never, { "throttle": { "alias": "throttle"; "required": false; }; }, { "uxResize": "uxResize"; }, never, never, true, never>;
}

declare class ResizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ResizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ResizeModule, never, [typeof ResizeDirective], [typeof ResizeDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ResizeModule>;
}

declare class CardTabComponent implements OnDestroy {
    private readonly _tabService;
    active$: Observable<boolean>;
    content: TemplateRef<void>;
    constructor();
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardTabComponent, "ux-card-tab", never, {}, {}, ["content"], ["*"], true, never>;
}

declare class CardTabsService implements OnDestroy {
    tab$: BehaviorSubject<CardTabComponent>;
    tabs$: BehaviorSubject<CardTabComponent[]>;
    position$: BehaviorSubject<string>;
    private readonly _subscription;
    constructor();
    ngOnDestroy(): void;
    /**
     * Add a tab to the list of tabs
     */
    addTab(tab: CardTabComponent): void;
    /**
     * Remove a tab from the list
     */
    removeTab(tab: CardTabComponent): void;
    /**
     * Select the tab
     */
    select(tab: CardTabComponent): void;
    /**
     * Set the position of the tab content
     */
    setPosition(position: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardTabsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CardTabsService>;
}

declare class CardTabsetComponent {
    tabService: CardTabsService;
    set position(direction: string);
    get position(): string;
    tablist: ElementRef;
    offset: number;
    bounds: CardTabsBounds;
    private _width;
    private _innerWidth;
    select(tab: CardTabComponent, element: HTMLElement): void;
    resize(dimensions: ResizeDimensions): void;
    previous(): void;
    next(): void;
    private moveIntoView;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardTabsetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardTabsetComponent, "ux-card-tabset", never, { "position": { "alias": "position"; "required": false; }; }, {}, never, ["*"], true, never>;
}
interface CardTabsBounds {
    lower: number;
    upper: number;
}

declare class CardTabContentDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardTabContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CardTabContentDirective, "[uxCardTabContent]", never, {}, {}, never, never, true, never>;
}

declare class CardTabsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardTabsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CardTabsModule, never, [typeof i2.CommonModule, typeof ResizeModule, typeof IconModule, typeof CardTabsetComponent, typeof CardTabComponent, typeof CardTabContentDirective], [typeof CardTabsetComponent, typeof CardTabComponent, typeof CardTabContentDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CardTabsModule>;
}

interface FocusableControl extends FocusableOption {
    setInputTabIndex(tabindex: number): void;
}

declare const CHECKBOX_VALUE_ACCESSOR: ExistingProvider;
declare class CheckboxComponent<T = number> implements ControlValueAccessor, FocusableControl {
    private readonly _changeDetector;
    /** Provide a default unique id value for the checkbox */
    _checkboxId: string;
    /** Determines if the checkbox should be checked, unchecked or indeterminate. */
    id: string;
    /** Specifies the form name of the element. */
    name: string | null;
    /** Determines if the checkbox should be checked, unchecked or indeterminate. */
    value: boolean | T;
    /** Specified if this is a required input. */
    required: boolean;
    /** Specifies the tabindex of the input. */
    tabindex: number;
    /** If set to `true` the checkbox will not toggle state when clicked. */
    clickable: boolean;
    /** If set to `true` the checkbox will be displayed without a border and background. */
    simplified: boolean;
    /**
     * If `value` is set to the indeterminate value specified using this attribute, it will neither
     * display the checkbox as checked or unchecked, and will instead show the indeterminate variation.
     */
    indeterminateValue: T | number;
    /** Specify if the checkbox should be disabled. */
    disabled: boolean;
    /** Provide an aria label for the checkbox. */
    ariaLabel: string;
    /** Provide an aria-labelled by property for the checkbox. */
    ariaLabelledby: string;
    /** Emits when `value` has been changed. */
    valueChange: EventEmitter<boolean | T>;
    /** Determine if the underlying input component has been focused with the keyboard */
    _focused: boolean;
    /** Used to inform Angular forms that the component has been touched */
    onTouchedCallback: () => void;
    /** Used to inform Angular forms that the component value has changed */
    onChangeCallback: (_: boolean | T) => void;
    /** Get the focus indicator to set focus */
    _focusIndicator?: FocusIndicatorDirective;
    /** Toggle the current state of the checkbox */
    toggle(): void;
    writeValue(value: boolean | T): void;
    /** Allow Angular forms for provide us with a callback for when the input value changes */
    registerOnChange(fn: (_: boolean | T) => void): void;
    /** Allow Angular forms for provide us with a callback for when the touched state changes */
    registerOnTouched(fn: () => void): void;
    /** Allow Angular forms to disable the component */
    setDisabledState(isDisabled: boolean): void;
    /** Focus the input element */
    focus(origin: FocusOrigin): void;
    setInputTabIndex(tabindex: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxComponent<any>, "ux-checkbox", never, { "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; "value": { "alias": "value"; "required": false; }; "required": { "alias": "required"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; "clickable": { "alias": "clickable"; "required": false; }; "simplified": { "alias": "simplified"; "required": false; }; "indeterminateValue": { "alias": "indeterminateValue"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; }, { "valueChange": "valueChange"; }, never, ["*"], true, never>;
}

declare class CheckboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckboxModule, never, [typeof AccessibilityModule, typeof CheckboxComponent], [typeof CheckboxComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckboxModule>;
}

type ColorPickerInputColors = ColorPickerColor | string;
type ColorPickerButtonStyle = 'square' | 'circle';
type ColorPickerButtonSize = 'sm' | 'md' | 'lg';
type ColorPickerInputMode = 'hex' | 'rgba';

/**
 * Type representing a color, including its descriptive name.
 */
declare class ColorPickerColor {
    /**
     * Human-readable name of the color.
     */
    name: string;
    /**
     * Hex value of the color, e.g. `#ffffff`.
     */
    get hex(): string;
    /**
     * RGBA value of the color, e.g. `rgba(255, 255, 255, 1)`.
     */
    get rgba(): string;
    get r(): number;
    get g(): number;
    get b(): number;
    get a(): number;
    private readonly _color;
    private readonly _originalHexValue;
    private readonly _originalRgbaValue;
    constructor(name: string, value: string, inputMode?: ColorPickerInputMode);
    toString(): string;
}

declare class ThemeColor {
    private _r;
    private _g;
    private _b;
    private _a;
    constructor(_r: string, _g: string, _b: string, _a?: string);
    /**
     * Create a ThemeColor object from a CSS color string
     * @param value The CSS color string to derive a ThemeColor object from
     */
    static parse(value: string): ThemeColor;
    /**
     * Clone a theme color so it can be modified without affecting other places using the color
     * @param themeColor The original theme color to clone
     */
    static from(themeColor: ThemeColor): ThemeColor;
    /**
     * Determine if an object is an instance of a theme color.
     * Using a simple instanceof check will not always work in plunker
     * where the ThemeColor is from @ux-aspects/ux-aspects and the color
     * comes from @micro-focus/ux-aspects
     */
    static isInstanceOf(themeColor: unknown): themeColor is ThemeColor;
    /**
     * Convert the theme color to a CSS hex color code
     */
    toHex(): string;
    /**
     * Convert the theme color to a CSS rgb color code
     */
    toRgb(): string;
    /**
     * Convert the theme color to a CSS rgbs color code
     */
    toRgba(): string;
    /**
     * Get the red value from the RGBA color value
     */
    getRed(): string;
    /**
     * Get the green value from the RGBA color value
     */
    getGreen(): string;
    /**
     * Get the blue value from the RGBA color value
     */
    getBlue(): string;
    /**
     * Get the alpha value from the RGBA color value
     */
    getAlpha(): string;
    /**
     * Set the red value from the RGBA color value
     */
    setRed(red: string): this;
    /**
     * Set the green value from the RGBA color value
     */
    setGreen(green: string): this;
    /**
     * Set the blue value from the RGBA color value
     */
    setBlue(blue: string): this;
    /**
     * Set the alpha value from the RGBA color value
     */
    setAlpha(alpha: string | number): this;
}

declare class ColorService {
    private _colorSet;
    /** Set the default theme to the Keppel colorset */
    private _theme;
    /** Allow the color set to be provided in a forRoot function otherwise set it to the Keppel theme by default */
    constructor();
    /**
     * Get a ThemeColor object from a color name
     * @param colorName The name of the color from the color palette
     */
    getColor(colorName: ColorIdentifier): ThemeColor;
    /**
     * Get the active color set
     */
    getColorSet(): ColorSet;
    /**
     * Define the current color set and produce a Theme from it
     */
    setColorSet(colorSet: ColorSet): void;
    /**
     * Resolve a color value. This may be the name of a color from the color set
     * or it may simply be a hex or rgb(a) color value. This function will return
     * a CSS color value regardless of which one of these formats it is
     * @param value The color name, hex code or rgb(a) value to resolve
     * @returns If the color is the name of a color in the set, the `rgba` color will be returned, otherwise the original CSS value will be returned.
     */
    resolve(value: string): string;
    /**
     * Converts a color name to an appropriate ColorSet name. For example
     * a color may be written in lower-camel-case, however color sets are in
     * kebab-case. This will convert to the appropriate naming format
     * @param colorName The color name to resolve
     */
    resolveColorName(colorName?: string): string;
    /** Determine if the current colorset has a specific color */
    colorExists(name: string): boolean;
    /** Create a theme from a colorset */
    private getTheme;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ColorService>;
}
interface Theme {
    [name: string]: ThemeColor;
}
type ColorIdentifier = string;

declare class ContrastService {
    /**
     * Calculate the contract ratio between two colors.
     * This uses the official WCAG Color Contrast Ratio
     * Algorithm: https://www.w3.org/TR/WCAG20-TECHS/G17.html
     */
    getContrastColor(backgroundColor: ThemeColor, lightColor: ThemeColor, darkColor: ThemeColor): ThemeColor;
    private getLuminance;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContrastService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContrastService>;
}

/**
 * When working with component host elements
 * we cannot apply directives, eg. FocusIndicatorOriginDirective
 * however we may still want the functionality to be applied to
 * the host element. This class allows the host element to become
 * a focus indicator origin
 */
declare class FocusIndicatorOrigin {
    private readonly _focusIndicatorOrigin;
    /** Store all event handlers */
    private readonly _handlers;
    /** Click events can be trigged by both mouse and keyboard so we want to ensure we emit the correct origin */
    private _isMouseEvent;
    constructor(_focusIndicatorOrigin: FocusIndicatorOriginService, elementRef: ElementRef, renderer: Renderer2);
    /** Remove all event handlers */
    destroy(): void;
    onMouseDown(): void;
    onClick(): void;
    onKeydown(): void;
}

declare class ManagedFocusContainerService {
    readonly rendererFactory: RendererFactory2;
    private _containers;
    private readonly _renderer;
    constructor();
    /**
     * Create or get an existing object which manages the tabindex of descendants.
     * @param element The element containing focusable descendants.
     * @param component The component requesting the managed focus container.
     */
    register(element: HTMLElement, component: unknown): void;
    /**
     * Remove the container object. This will call `unregister` on the container if `component` is the last reference
     * to it.
     * @param element The element containing focusable descendants.
     * @param component The component requesting the managed focus container.
     */
    unregister(element: HTMLElement, component: unknown): void;
    /**
     * Get an observable which can be used to determine when the element or one of its descendants has focus.
     * @param element The element containing focusable descendants.
     */
    hasFocus(element: HTMLElement): Observable<boolean>;
    private getContainer;
    static ɵfac: i0.ɵɵFactoryDeclaration<ManagedFocusContainerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ManagedFocusContainerService>;
}

declare const ACCESSIBILITY_OPTIONS_TOKEN: InjectionToken<AccessibilityOptions>;

declare class TabbableListService implements OnDestroy {
    /** Indicate is this is being using on a hierarchichal set of items */
    hierarchy: boolean;
    /** Determine if we all the alt key */
    allowAltModifier: boolean;
    /** Determine if we all the ctrl key */
    allowCtrlModifier: boolean;
    /** Determine if we allow the Home/End keys */
    allowBoundaryKeys: boolean;
    /** Determine if we should scroll the item into view on focus */
    shouldScrollInView: boolean;
    /** Store the instance of the focus key manager */
    focusKeyManager: FocusKeyManager<TabbableListItemDirective>;
    /** Indicate if we should refocus an item on QueryList change - for use within virtual lists */
    shouldFocusOnChange: boolean;
    /** Store the container element */
    containerRef: HTMLElement;
    /** Emit whenever focus does not change but tabindexes have */
    onTabIndexChange: Subject<void>;
    /** Determine if focus is currently within the tabbable list */
    isFocused: boolean;
    /** Store the list of tabbable items */
    private _items;
    /** Store the direction of the list */
    private _direction;
    /** Unsubscribe from all observables on destroy */
    private readonly _onDestroy;
    ngOnDestroy(): void;
    initialize(items: QueryList<TabbableListItemDirective>, direction: 'horizontal' | 'vertical', wrap: boolean): void;
    /** Give and item focus or just make it the current tabbable item */
    activate(item: TabbableListItemDirective, updateIndexOnly?: boolean): void;
    /** Give and item focus or just make it the current tabbable item */
    activateItemAtIndex(index: number, updateIndexOnly?: boolean): void;
    isItemActive(item: TabbableListItemDirective): boolean;
    setFirstItemTabbable(): void;
    isAnyItemTabbable(): boolean;
    ensureTabbableItem(): void;
    focusTabbableItem(): void;
    onKeydown(source: TabbableListItemDirective, event: KeyboardEvent): void;
    sortItemsByHierarchy(list: QueryList<TabbableListItemDirective>): TabbableListItemDirective[];
    /**
     * In a uxVirtualFor list cells can be resused. This means that when we scroll
     * the data associated with a given element may change and not the actual elements. If only the data changes
     * then the QueryList will not emit a change so we may show focus indicatator on the element that previously displayed
     * the correct data but no longer does.
     *
     * We need to handle this correctly here. We already have keys implements to handle virtual elements so we can check
     * if a key changes and use it to update the focused item even if the QueryList doesn't inform us that we have changed.
     */
    itemReferenceChange(previousKey: unknown, origin: FocusOrigin): void;
    /** Update the active item without causing focus */
    updateActiveItemIndex(index: number): void;
    /** Determine if there is an item with a tabindex of 0 */
    hasTabbableItem(): boolean;
    private getItemByKey;
    private flattenHierarchy;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabbableListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TabbableListService>;
}

declare class ColorPickerComponent implements OnInit, OnDestroy {
    id: string;
    /**
     * The collection of colors to display in the color swatch.
     *
     * Colors can be specified either as a string, which is the hex or RGBA value of the color; or as a `ColorPickerColor` object,
     * which allows a name to be associated with the color. See below for details of the `ColorPickerColor` class.
     * This property is either a one-dimensional or two-dimensional array. If a two-dimensional array is provided,
     * the colors will be split into rows, providing more control over the appearance of the swatch.
     */
    set inputColors(colors: ColorPickerInputColors[] | ColorPickerInputColors[][]);
    /**
     * The currently selected color. If this is one of the `colors` in the colors collection, it will be visually
     * highlighted in the swatch. It will also be shown in the input panel, if enabled (see showInput).
     * Note that this will always be a `ColorPickerColor` object, even if plain strings are provided to the colors property.
     * See below for details of the `ColorPickerColor` class.
     */
    set selected(selected: ColorPickerColor);
    /**
     * The number of columns to display in the color swatch. Set this to -1 if the width should be specified by a stylesheet
     * instead, e.g. to provide a responsive layout.
     */
    set columns(columns: number);
    /** The style of the color swatch buttons. */
    buttonStyle: ColorPickerButtonStyle;
    /** The size of the color swatch buttons. Three size variants are currently supported. */
    set buttonSize(buttonSize: ColorPickerButtonSize);
    /** Whether to show tooltips above the color swatch buttons. These contain the color name if provided; otherwise the color hex/RGBA value. */
    showTooltips: boolean;
    /** Whether to show the hex/RGBA input panel. */
    showInput: boolean;
    /** The default input mode to display in the input panel. The user can switch modes using the toggle button. */
    inputMode: ColorPickerInputMode;
    /** Defines a function that returns an aria-label for ColorPickerColor. */
    colorAriaLabel: (color: ColorPickerColor) => string;
    /** Defines a function that returns an aria-label for the button that switches input modes. */
    switchModeAriaLabel: (mode: ColorPickerInputMode) => string;
    /** Define a function that returns an aria-label for the input control. */
    inputAriaLabel: (mode: ColorPickerInputMode) => string;
    /** Emitted when the user changes the selected color, either by clicking a color swatch button, or entering a valid color value into the input panel text field. */
    selectedChange: EventEmitter<ColorPickerColor>;
    /** Emitted when the user changes the colour input mode */
    inputModeChange: EventEmitter<ColorPickerInputMode>;
    /** Emitted when the user presses enter in the input panel text field. This can be used to commit a color change and/or close a popup. */
    inputSubmit: EventEmitter<void>;
    cssWidth: string;
    colors: ColorPickerColor[][];
    selected$: BehaviorSubject<ColorPickerColor>;
    columns$: BehaviorSubject<number>;
    buttonSize$: BehaviorSubject<ColorPickerButtonSize>;
    inputPatterns: {
        hex: RegExp;
        rgba: RegExp;
    };
    /** Access the ngModel instance of the input field */
    inputFormControl: NgModel;
    tabbableList: TabbableListDirective;
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    onFocus(): void;
    updateColorValue(input: string, mode: ColorPickerInputMode): void;
    toggleColorEntryType(): void;
    private getColorAriaLabel;
    private getSwitchModeAriaLabel;
    private getInputAriaLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorPickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorPickerComponent, "ux-color-picker", ["ux-color-picker"], { "id": { "alias": "id"; "required": false; }; "inputColors": { "alias": "colors"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "buttonStyle": { "alias": "buttonStyle"; "required": false; }; "buttonSize": { "alias": "buttonSize"; "required": false; }; "showTooltips": { "alias": "showTooltips"; "required": false; }; "showInput": { "alias": "showInput"; "required": false; }; "inputMode": { "alias": "inputMode"; "required": false; }; "colorAriaLabel": { "alias": "colorAriaLabel"; "required": false; }; "switchModeAriaLabel": { "alias": "switchModeAriaLabel"; "required": false; }; "inputAriaLabel": { "alias": "inputAriaLabel"; "required": false; }; }, { "selectedChange": "selectedChange"; "inputModeChange": "inputModeChange"; "inputSubmit": "inputSubmit"; }, never, never, true, never>;
}

declare const NUMBER_PICKER_VALUE_ACCESSOR: {
    provide: i0.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: i0.Type<any>;
    multi: boolean;
};
declare class NumberPickerComponent implements ControlValueAccessor, OnDestroy, OnChanges {
    readonly _formGroup: FormGroupDirective;
    private readonly _changeDetector;
    private _min;
    private _max;
    private _step;
    private _disabled;
    private _value;
    private _lastValue;
    private _focused;
    private _propagateChange;
    _touchedChange: () => void;
    /** Sets the id of the number picker. The child input will have this value with a -input suffix as its id. */
    id: string;
    /** Provide an aria label for the number picker. */
    ariaLabel: string;
    /** Provide an aria labelledby attribute */
    labelledBy: string;
    /** Define the precision of floating point values */
    precision: number;
    /** The placeholder text which appears in the text input area when it is empty.*/
    placeholder: string;
    /** Specified if this is a required input. */
    required: boolean;
    /** Specified if this is a readonly input. */
    set readonly(value: boolean);
    get readonly(): boolean;
    /** If two way binding is used this value will be updated any time the number picker value changes. */
    valueChange: EventEmitter<number>;
    /** Sets the value displayed in the number picker component. */
    get value(): number;
    set value(value: number);
    /** Defines the minimum value the number picker can set. */
    get min(): number;
    set min(value: number);
    /** Defines the maximum value the number picker can set. */
    get max(): number;
    set max(value: number);
    /** Defines the amount the number picker should increase or decrease when the buttons or arrow keys are used. */
    set step(value: number | ((value: number, direction: StepDirection) => number));
    /** Indicate if the number picker is disabled or not. */
    get disabled(): boolean;
    set disabled(value: boolean);
    get inputId(): string;
    /** Store the current valid state */
    _valid: boolean;
    /** This is a flag to indicate when the component has been destroyed to avoid change detection being made after the component
     *  is no longer instantiated. A workaround for Angular Forms bug (https://github.com/angular/angular/issues/27803) */
    private _isDestroyed;
    private _readonly;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    getStep(direction: StepDirection): number;
    increment(event?: MouseEvent | KeyboardEvent): void;
    decrement(event?: MouseEvent | KeyboardEvent): void;
    isValid(): boolean;
    onScroll(event: WheelEvent): void;
    writeValue(value: number): void;
    registerOnChange(fn: (_: number) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    /** Set the value and emit the change to the output and Angular forms. */
    _emitValueChange(value: number): void;
    getMaxValueForComparison(): number;
    getMinValueForComparison(): number;
    onFocusIn(): void;
    onFocusOut(): void;
    static ngAcceptInputType_readonly: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<NumberPickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NumberPickerComponent, "ux-number-picker, ux-number-picker-inline", never, { "id": { "alias": "id"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "labelledBy": { "alias": "aria-labelledby"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "required": { "alias": "required"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "value": { "alias": "value"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "step": { "alias": "step"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
declare enum StepDirection {
    Increment = 0,
    Decrement = 1
}

declare class NumberPickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NumberPickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NumberPickerModule, never, [typeof i2.CommonModule, typeof IconModule, typeof i3$2.FormsModule, typeof NumberPickerComponent], [typeof NumberPickerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NumberPickerModule>;
}

declare class TooltipComponent<T = any> implements OnDestroy {
    protected readonly _changeDetectorRef: ChangeDetectorRef;
    /** Define a unique id for each tooltip */
    id: string;
    /** Define the tooltip role */
    role: string;
    /** The content of the tooltip, either a string or a TemplateRef for further customization */
    content: string | TemplateRef<T>;
    /** Allow the user to supply a context for the tooltip TemplateRef */
    context: T;
    /** The position the tooltip should display relative to the associated element */
    placement: AnchorPlacement;
    /** The position the callout should display relative to the popover element */
    alignment: AnchorAlignment;
    /** Allow a custom class to be added to the tooltip to allow custom styling */
    customClass: string;
    /** Emit when the tooltip need to update it's position */
    reposition$: Subject<void>;
    /** Indicates whether or not the content is a string or a TemplateRef */
    get isTemplateRef(): boolean;
    /** The name of the css class to use for the tooltip direction */
    _positionClass: string;
    get positionClass(): string;
    set positionClass(positionClass: string);
    /** Cleanup after the component is destroyed */
    ngOnDestroy(): void;
    /** Inform the parent directive that it needs to recalulate the position */
    reposition(): void;
    /** This will update the content of the tooltip and trigger change detection */
    setContent(content: string | TemplateRef<any>): void;
    /** This will update the tooltip placement and trigger change detection */
    setPlacement(placement: AnchorPlacement): void;
    /** This will update the tooltip alignment and trigger change detection */
    setAlignment(alignment: AnchorAlignment): void;
    /** This will set a custom class on the tooltip and trigger change detection */
    setClass(customClass: string): void;
    /** Updates the context used by the TemplateRef */
    setContext(context: T): void;
    /** Specify the tooltip role attribute */
    setRole(role: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TooltipComponent<any>, "ux-tooltip", never, { "content": { "alias": "content"; "required": false; }; "context": { "alias": "context"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TooltipDirective implements OnInit, OnChanges, OnDestroy {
    protected readonly _elementRef: ElementRef<any>;
    protected readonly _viewContainerRef: ViewContainerRef;
    protected readonly _overlay: Overlay;
    protected readonly _scrollDispatcher: ScrollDispatcher;
    private readonly _changeDetectorRef;
    private readonly _renderer;
    private readonly _tooltipService;
    private readonly _overlayFallback;
    /** Contains the content of the tooltip or a TemplateRef for more detailed content */
    content: string | TemplateRef<any>;
    /** Allow the tooltip to be conditionally disabled */
    disabled: boolean;
    /** All the user to add a custom class to the tooltip */
    customClass: string;
    /** All the user to add a role to the tooltip - default is tooltip */
    role: string;
    /** Provide the TemplateRef a context object */
    context: any;
    /** Delay the showing of the tooltip by a number of miliseconds */
    delay: number;
    /** Programmatically show and hide the tooltip */
    isOpen: boolean;
    /** Customize how the tooltip should be positioned relative to the element */
    placement: AnchorPlacement;
    /** Specify the fallback placement if the specified placement cannot be used */
    fallbackPlacement: AnchorPlacement;
    /** Customize the position of the callout */
    alignment: AnchorAlignment;
    /** Specify which events should show the tooltip */
    showTriggers: OverlayTrigger[];
    /** Specify which events should hide the tooltip */
    hideTriggers: OverlayTrigger[];
    /** Emits an event when the tooltip is shown */
    shown: EventEmitter<void>;
    /** Emits a event when the tooltip is hidden */
    hidden: EventEmitter<void>;
    /** Allow two way binding to track the visibility of the tooltip */
    isOpenChange: EventEmitter<boolean>;
    /** Keep track of the tooltip visibility */
    isVisible: boolean;
    /** The name of the css class to use for the tooltip direction */
    positionClass: AnchorPlacement;
    /** Define the overlay class */
    protected _overlayClass: string;
    /** A reference to the CDK portal containing the overlay */
    protected _portal: ComponentPortal<TooltipComponent>;
    /** A reference to the overlay the tooltip will be inserted into */
    protected _overlayRef: OverlayRef;
    /** A reference to the instance of the tooltip component when created */
    protected _instance: TooltipComponent;
    /** This will emit when the directive is destroyed allowing us to unsubscribe all subscriptions automatically */
    protected _onDestroy: Subject<void>;
    /** Store the timeout interval for cancelation */
    private _showTimeoutId;
    /** Internally store the type of this component - usual for distinctions when extending this class */
    protected _type: string;
    /** Set up the triggers and bind to the show/hide events to keep visibility in sync */
    ngOnInit(): void;
    /**
     * We need to send input changes to the tooltip component
     * We can't use setters as they may trigger before tooltip initialised and can't resend once initialised
     **/
    ngOnChanges(changes: SimpleChanges): void;
    /** Ensure we clean up after ourselves */
    ngOnDestroy(): void;
    /** Make the tooltip open */
    show(): void;
    /** If a tooltip exists and is visible, hide it */
    hide(): void;
    /** Toggle the visibility of the tooltip */
    toggle(): void;
    /** Recalculate the position of the popover */
    reposition(): void;
    /** Create an instance from the overlay ref - allows overriding and additional logic here */
    protected createInstance(overlayRef: OverlayRef): TooltipComponent;
    /** Create the component portal - allows overriding to allow other portals eg. popovers */
    protected createPortal(): ComponentPortal<any>;
    /** Create the overlay and set up the scroll handling behavior */
    private createOverlay;
    /** Recreate the overlay ref using the updated origin and overlay positions */
    private destroyOverlay;
    private getPositionClass;
    /**
     * Simple utility method - because IE doesn't support array.includes
     * And it isn't included in the core-js/es6 polyfills which are the
     * only ones required by Angular and guaranteed to be there
     **/
    protected includes<T>(array: Array<T>, value: T): boolean;
    /** Handle the click event - show or hide accordingly */
    protected onClick(): void;
    /** Handle the mouse enter event - show or hide accordingly */
    protected onMouseEnter(): void;
    /** Handle the mouse leave event - show or hide accordingly */
    protected onMouseLeave(): void;
    /** Handle the focus event - show or hide accordingly */
    protected onFocus(): void;
    /** Handle the blur event - show or hide accordingly */
    protected onBlur(): void;
    /** Programmatically update the aria-describedby property */
    protected setAriaDescribedBy(id: string | null): void;
    /** Cancel any pending tooltip (waiting on delay ellapsing) */
    private cancelTooltip;
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TooltipDirective, "[uxTooltip]", ["ux-tooltip"], { "content": { "alias": "uxTooltip"; "required": false; }; "disabled": { "alias": "tooltipDisabled"; "required": false; }; "customClass": { "alias": "tooltipClass"; "required": false; }; "role": { "alias": "tooltipRole"; "required": false; }; "context": { "alias": "tooltipContext"; "required": false; }; "delay": { "alias": "tooltipDelay"; "required": false; }; "isOpen": { "alias": "isOpen"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "fallbackPlacement": { "alias": "fallbackPlacement"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; "showTriggers": { "alias": "showTriggers"; "required": false; }; "hideTriggers": { "alias": "hideTriggers"; "required": false; }; }, { "shown": "shown"; "hidden": "hidden"; "isOpenChange": "isOpenChange"; }, never, never, true, never>;
}
type OverlayTrigger = 'click' | 'clickoutside' | 'escape' | 'mouseenter' | 'focus' | 'mouseleave' | 'blur';

declare class TooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TooltipModule, never, [typeof i2.CommonModule, typeof i2$1.OverlayModule, typeof i3$3.ObserversModule, typeof TooltipComponent, typeof TooltipDirective], [typeof TooltipDirective, typeof TooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TooltipModule>;
}

declare class ColorPickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorPickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ColorPickerModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof i3$2.FormsModule, typeof NumberPickerModule, typeof TooltipModule, typeof IconModule, typeof ColorPickerComponent], [typeof ColorPickerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ColorPickerModule>;
}

declare class ColumnSortingDirective implements OnDestroy {
    /** If set to true the column will sort by only this column, removing sorting from all others. */
    singleSort: boolean;
    /** Provide a custom template for the sort indicator */
    sortIndicator: TemplateRef<ColumnSortingIndicatorContext>;
    /** Emit the current sort state for all columns within the table */
    events: Subject<readonly ColumnSortingOrder[]>;
    /** Store the current sort state for all columns within the table */
    order: ReadonlyArray<ColumnSortingOrder>;
    ngOnDestroy(): void;
    /** Toggle the sorting state of a column */
    toggleColumn(sorting: ColumnSortingOrder): ReadonlyArray<ColumnSortingOrder>;
    /** Explicitly set the column state */
    setColumnState(key: string, state: ColumnSortingState): void;
    /** Toggle the sorting state of a column when using single select */
    private toggleSingleColumn;
    /** Toggle the sorting state of a column when using multiple select */
    private toggleMultipleColumn;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnSortingDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ColumnSortingDirective, "[uxColumnSorting]", never, { "singleSort": { "alias": "singleSort"; "required": false; }; "sortIndicator": { "alias": "sortIndicator"; "required": false; }; }, {}, never, never, true, never>;
}
interface ColumnSortingOrder {
    key: string;
    state: ColumnSortingState;
}
declare enum ColumnSortingState {
    Ascending = "ascending",
    Descending = "descending",
    NoSort = "none"
}
interface ColumnSortingIndicatorContext {
    state: ColumnSortingState;
    order: number;
}

declare class ColumnSortingComponent implements OnInit, OnChanges, OnDestroy {
    private readonly _sorter;
    private readonly _changeDetector;
    /** Defines the sorting order of a column: `NoSort`, `Ascending` or `Descending`. */
    state: ColumnSortingState;
    /** Defines a unique identifier for the column that can be used when sorting. */
    key: string;
    /** Store the order of the sorting - used when multiple columns are being sorted at once */
    order: number;
    /** Determine if a column can have a `NoSort` state */
    allowNoSort: boolean;
    /** Specifies name of the ascending icon */
    ascendingIcon: string;
    /** Specifies name of the descending icon */
    descendingIcon: string;
    /**
     * Changes the state of the sorting on the column between `NoSort`, `Ascending` and `Descending`.
     * This returns an array of objects for each column being sorted containing `key: string` and `state: ColumnSortingState`.
     * State can be used to find the current sorting state of the column eg. `(state === ColumnSortingState.Ascending)`.
     * The `ColumnSortingOrder` interface has been provided for objects in the array.
     */
    stateChange: EventEmitter<ColumnSortingState>;
    /** Emit whenever the order changes */
    orderChange: EventEmitter<number>;
    /** Expose the sorting state enum to the view */
    ColumnSortingState: typeof ColumnSortingState;
    /** Access the custom sort indicator if one was provided */
    get _sortIndicator(): TemplateRef<ColumnSortingIndicatorContext>;
    /** Unsubscribe from all observables on component destroy */
    private readonly _onDestroy$;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    /** Toggle the sorting state of a column - this is designed to be programmatically called by the consuming component */
    changeState(): ColumnSortingOrder[];
    /** Update the state based on column order */
    private updateState;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnSortingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColumnSortingComponent, "ux-column-sorting", ["ux-column-sorting"], { "state": { "alias": "state"; "required": false; }; "key": { "alias": "key"; "required": false; }; "order": { "alias": "order"; "required": false; }; "allowNoSort": { "alias": "allowNoSort"; "required": false; }; "ascendingIcon": { "alias": "ascendingIcon"; "required": false; }; "descendingIcon": { "alias": "descendingIcon"; "required": false; }; }, { "stateChange": "stateChange"; "orderChange": "orderChange"; }, never, never, true, never>;
}

declare class ColumnSortingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnSortingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ColumnSortingModule, never, [typeof i2.CommonModule, typeof IconModule, typeof ColumnSortingComponent, typeof ColumnSortingDirective], [typeof ColumnSortingComponent, typeof ColumnSortingDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ColumnSortingModule>;
}

interface ConduitProperties {
    id: number | string;
    acceptsInput?: boolean | string[];
    producesOutput?: boolean;
    changeDetection?: (x: any, y: any) => boolean;
    map?: any;
}
declare const defaultConduitProps: Partial<ConduitProperties>;

interface ConduitMetadata extends ConduitProperties {
    subject?: Subject<any>;
    currentValue?: any;
    lastModified?: Date;
    target?: object;
    propertyKey?: string;
}

interface ConduitEvent {
    conduit: ConduitMetadata;
    value: any;
    zoneId: string;
}

declare class ConduitZone implements OnDestroy {
    /** Create a global subject store */
    static subjects: ConduitSubject[];
    /** Expose an event stream of new values */
    static events: Subject<ConduitEvent>;
    /** Store the zone name */
    private _zoneId;
    ngOnDestroy(): void;
    /** Store reference to the repository and begin watching for and emitting changes */
    registerConduit(conduit: ConduitMetadata): void;
    /** Destroy a conduit */
    unregisterConduit(conduit: ConduitMetadata): void;
    /** Provide the zone with an ID */
    setZoneId(zoneId: string): void;
    /** Emit a value to all zones for checking */
    emit(event: ConduitEvent): void;
    /** Retrieve a conduit subsject object from the rxjs subject */
    getConduitSubject(subject: Subject<void>): ConduitSubject | null;
    /** Get all subjects from all zones */
    getSubjects(): ConduitSubject[];
    /** Alter the properties of a conduit dynamically */
    setConduitProperties(subject: Subject<string>, properties: Partial<ConduitProperties>): void;
    /** Programmatically create a conduit at runtime */
    createConduit(subject: Subject<void>, properties: ConduitProperties): void;
    /** Register all conduits in a component */
    registerConduits(component: any): void;
    /** Register all conduits in a component */
    unregisterConduits(component: any): void;
    /** Return the global event stream */
    getEvents(): Subject<ConduitEvent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConduitZone, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConduitZone>;
}

declare class ConduitSubject {
    conduit: ConduitMetadata;
    private readonly _zone;
    zoneId: string;
    private readonly _subject;
    private readonly _onDestroy;
    constructor(conduit: ConduitMetadata, _zone: ConduitZone, zoneId: string);
    /** Check all allow inputs to see if there is a value we should initially set the conduit to */
    getInitialValue(): void;
    /** This will be triggered when a conduits value has changed */
    onInput(event: ConduitEvent): void;
    /** This will be fired when this conduit emits a new value */
    onOutput(value: any): void;
    /** Unsubscribe once this subject is destroyed */
    destroy(): void;
}

declare class ConduitComponent implements OnInit, OnDestroy {
    protected _zone: ConduitZone;
    /** We need to register the conduits with the zone when the component is initialised */
    ngOnInit(): void;
    /** We need to unregister the conduits when the component is destroyed */
    ngOnDestroy(): void;
    /** Alter the properties of a conduit dynamically */
    setConduitProperties(subject: Subject<string>, properties: Partial<ConduitProperties>): void;
    /** Programmatically create a conduit at runtime */
    createConduit(subject: Subject<void>, properties: ConduitProperties): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConduitComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ConduitComponent, "ux-conduit", never, {}, {}, never, never, true, never>;
}

declare abstract class ConduitZoneComponent extends ConduitComponent implements OnInit {
    abstract zoneId: string;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConduitZoneComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ConduitZoneComponent, "ux-conduit-zone", never, {}, {}, never, never, true, never>;
}

/** Expose the property that conduits will be stored in */
declare const CONDUITS = "_conduits";
type PropertyDecorator = (target: Object, propertyKey: string | symbol) => void;
/** Create the conduit property decorator */
declare function Conduit(properties: ConduitProperties | Function): PropertyDecorator;

/**
 * This module is not required to be imported but is required
 * by the Angular compiler, otherwise it will complain that
 * ConduitZoneComponent is not part of an NgModule and will
 * fail to build
 */
declare class ConduitModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConduitModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConduitModule, never, [typeof ConduitComponent, typeof ConduitZoneComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConduitModule>;
}

interface DragScrollEvent {
    offsetX: number;
    offsetY: number;
}
declare class DragDirective<T = unknown> implements OnDestroy {
    private readonly _elementRef;
    private readonly _ngZone;
    private readonly _renderer;
    private readonly _scrollDispatcher;
    private readonly _drag;
    /** Detemine if we should show a clone when dragging */
    clone: boolean;
    /** Define the group the drag event belongs to */
    group: string;
    /** Associate some data with the drag event */
    model: T;
    /** Allow the dragging to be enabled/disabled */
    draggable: boolean;
    /** Emit an event when dragging starts */
    onDragStart: EventEmitter<MouseEvent>;
    /** Emit an event when the mouse moves while dragging */
    onDrag: EventEmitter<MouseEvent>;
    /** Emit an event when the document scrolls while dragging */
    onDragScroll: EventEmitter<DragScrollEvent>;
    /** Emit an event when the dragging finishes */
    onDragEnd: EventEmitter<void>;
    /** Emit when the user drops an item in a drop area */
    onDrop: EventEmitter<T>;
    /** Emit when the user drags over a drop area */
    onDropEnter: EventEmitter<void>;
    /** Emit when the user drags out of a drop area */
    onDropLeave: EventEmitter<void>;
    /** Store the element we have cloned */
    private _clone;
    /** Store the dragging state */
    private _isDragging;
    /** Store the mouse offset for the cloned element position */
    private _offset;
    /** The nearest scrolling ancestor, populated while dragging */
    private _scrollParent;
    /** The current scroll position of _scrollParent */
    private _scrollPosition;
    /** The scroll event listener handle */
    private _scrollListener;
    /** The offset in pixels currently being scrolled while dragging */
    private _scrollOffset;
    /** The current `setInterval` handle for periodic scrolling */
    private _scrollIntervalHandle;
    /** Create an observable from the mouse down event */
    private readonly _mousedown$;
    /** Create an observable from the mouse move event */
    private readonly _mousemove$;
    /** Create an observable from the mouse up event */
    private readonly _mouseup$;
    /** Use an observable to unsubscribe from all subscriptions */
    protected _onDestroy: Subject<void>;
    constructor();
    /** Emit events and create clone when drag starts */
    dragStart(event: MouseEvent): void;
    /** Emit event and update clone position when dragging moves */
    dragMove(event: MouseEvent): void;
    /** Emit event and destroy clone when dragging ends */
    dragEnd(): void;
    /** Emit the onDragScroll event */
    scroll(): void;
    /** Create an exact clone of an element */
    cloneNode(event: MouseEvent): void;
    /** Position the clone relative to the mouse */
    updateNodePosition(event: MouseEvent): void;
    /** Inline all styles to ensure styling is consistent regardless of its position in the dom */
    inlineStyles(source: Element, target: Element): void;
    /** Unsubscribe from all subscriptions */
    ngOnDestroy(): void;
    private updateScrolling;
    private getScrollParent;
    private createScrollEventListener;
    private removeScrollEventListener;
    private getScrollOffsets;
    private startScrolling;
    private stopScrolling;
    private performScroll;
    static ɵfac: i0.ɵɵFactoryDeclaration<DragDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DragDirective<any>, "[uxDrag]", never, { "clone": { "alias": "clone"; "required": false; }; "group": { "alias": "group"; "required": false; }; "model": { "alias": "model"; "required": false; }; "draggable": { "alias": "draggable"; "required": false; }; }, { "onDragStart": "onDragStart"; "onDrag": "onDrag"; "onDragScroll": "onDragScroll"; "onDragEnd": "onDragEnd"; "onDrop": "onDrop"; "onDropEnter": "onDropEnter"; "onDropLeave": "onDropLeave"; }, never, never, true, never>;
}

declare class DragService<T = unknown> implements OnDestroy {
    /** Emit when dragging begins */
    onDragStart: Subject<UxDragEvent<T>>;
    /** Emit when dragging moves */
    onDrag: Subject<UxDragEvent<T>>;
    /** Emit when dragging ends */
    onDragEnd: Subject<UxDragEvent<T>>;
    /** Emit when the user is dragging over the drop area */
    onDropEnter: Subject<void>;
    /** Emit when the user is dragging out of the drop area */
    onDropLeave: Subject<void>;
    /** Emit when a drop occurs */
    onDrop: Subject<T>;
    /** Destroy all observables */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DragService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DragService<any>>;
}
type UxDragEvent<T = unknown> = {
    group?: string;
    event?: MouseEvent;
    data?: T;
};

declare class DropDirective<T = unknown> implements OnDestroy {
    private readonly _dragService;
    /** Define a specific group of dragged items to listen to */
    group: string | string[];
    /** Define whether or not dropping is enabled */
    dropDisabled: boolean;
    /** Emit the model of the item dropped */
    onDrop: EventEmitter<T>;
    /** Determine whether or not the mouse is within the drop region */
    isMouseOver: boolean;
    /** Determine whether or not we are currently dragging an item */
    isDragging: boolean;
    /** Store the group of the dragged item */
    private _group;
    /** Ensure we destroy all subscriptions */
    private readonly _onDestroy;
    constructor();
    ngOnDestroy(): void;
    /** Update the mouse over state */
    onMouseOver(): void;
    /** Update the mouse over state */
    onMouseLeave(): void;
    /** Update the dragging state */
    onDragStart(): void;
    /** Update the dragging state */
    onDragEnd(event: UxDragEvent<T>): void;
    /** Determine whether or not the event is part of the specified groups */
    private isDropAllowed;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DropDirective<any>, "[uxDrop]", never, { "group": { "alias": "group"; "required": false; }; "dropDisabled": { "alias": "dropDisabled"; "required": false; }; }, { "onDrop": "onDrop"; }, never, never, true, never>;
}

declare class DragModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DragModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DragModule, never, [typeof DragDirective, typeof DropDirective], [typeof DragDirective, typeof DropDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DragModule>;
}

declare enum DashboardStackMode {
    Regular = 0,
    Stacked = 1,
    /** Determine the mode automatically based on dashboard width. */
    Auto = 2
}

declare class DashboardWidgetComponent implements OnInit, AfterViewInit, OnDestroy, OnChanges {
    readonly dashboardService: DashboardService;
    /** Sets the ID of the widget. Each widget should be given a unique ID. */
    id: string;
    /** Defines a name for the widget used for accessibility */
    name: string;
    /** Defines the column the widget is placed in */
    set col(col: number);
    get col(): number;
    /** Defines the row the widget is placed in */
    set row(row: number);
    get row(): number;
    /** Defines the number of columns this widget should occupy. */
    get colSpan(): number;
    set colSpan(colSpan: number);
    /** Defines the number of rows this widget should occupy. */
    get rowSpan(): number;
    set rowSpan(rowSpan: number);
    /** Defines the minimum number of columns this widget should occupy. */
    get minColSpan(): number;
    set minColSpan(minColumns: number);
    /** Defines the minimum number of rows this widget should occupy. */
    get minRowSpan(): number;
    set minRowSpan(minRows: number);
    /** Defines whether or not this widget can be resized. */
    resizable: boolean;
    /** Defines whether or not this widget will be automatically repositioned */
    set autoPositioning(autoPositioning: boolean);
    get autoPositioning(): boolean;
    /** Defines a function that returns an aria label for the widget */
    widgetAriaLabel: (widgets: DashboardWidgetComponent) => string | string;
    x: number;
    y: number;
    width: number;
    height: number;
    padding: number;
    zIndex: number;
    ariaLabel: string;
    role: string;
    isDragging: boolean;
    isGrabbing: boolean;
    isResizing: boolean;
    isDraggable: boolean;
    private readonly _column;
    private readonly _row;
    private readonly _columnSpan;
    private readonly _rowSpan;
    private _minColSpan;
    private _minRowSpan;
    private _autoPositioning;
    private readonly _onDestroy;
    constructor();
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * If component is removed, then unregister it from the service
     */
    ngOnDestroy(): void;
    /**
     * Apply the current dashboard options
     */
    update(): void;
    /**
     * Set the actual position and size values
     */
    render(): void;
    getColumn(mode?: DashboardStackMode): number;
    getRow(mode?: DashboardStackMode): number;
    setColumn(column: number, render?: boolean): void;
    setRow(row: number, render?: boolean): void;
    getColumnSpan(): number;
    getRowSpan(): number;
    setColumnSpan(columnSpan: number, render?: boolean): void;
    setRowSpan(rowSpan: number, render?: boolean): void;
    bringToFront(): void;
    sendToBack(): void;
    setBounds(x: number, y: number, width: number, height: number): void;
    dragstart(handle: HTMLElement, event: MouseEvent, direction: ActionDirection): void;
    drag(handle: HTMLElement, event: MouseEvent, direction: ActionDirection): void;
    dragend(): void;
    getAriaLabel(): string;
    private getDefaultAriaLabel;
    /**
     * Allows automatic setting of stackable value
     * @param property The current StackableValue object
     * @param value The value to set in the appropriate field
     */
    private setStackableValue;
    /**
     * Return the appropriate value from a stackable value
     * @param property The Stackable value object
     */
    private getStackableValue;
    /** Determine if the layout has been performed yet */
    private hasPosition;
    static ngAcceptInputType_autoPositioning: BooleanInput;
    static ngAcceptInputType_col: NumberInput;
    static ngAcceptInputType_row: NumberInput;
    static ngAcceptInputType_colSpan: NumberInput;
    static ngAcceptInputType_rowSpan: NumberInput;
    static ngAcceptInputType_minColSpan: NumberInput;
    static ngAcceptInputType_minRowSpan: NumberInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardWidgetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DashboardWidgetComponent, "ux-dashboard-widget", never, { "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; "col": { "alias": "col"; "required": false; }; "row": { "alias": "row"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "rowSpan": { "alias": "rowSpan"; "required": false; }; "minColSpan": { "alias": "minColSpan"; "required": false; }; "minRowSpan": { "alias": "minRowSpan"; "required": false; }; "resizable": { "alias": "resizable"; "required": false; }; "autoPositioning": { "alias": "autoPositioning"; "required": false; }; "widgetAriaLabel": { "alias": "widgetAriaLabel"; "required": false; }; "role": { "alias": "role"; "required": false; }; }, {}, never, ["*"], true, never>;
}
interface StackableValue {
    regular: number;
    stacked: number;
}

declare class DashboardService implements OnDestroy {
    private _widgetOrigin;
    private _actionWidget;
    private _rowHeight;
    private _cache;
    private _event;
    initialized$: BehaviorSubject<boolean>;
    widgets$: BehaviorSubject<DashboardWidgetComponent[]>;
    options$: BehaviorSubject<DashboardOptions>;
    dimensions$: BehaviorSubject<DashboardDimensions>;
    height$: Observable<number>;
    placeholder$: BehaviorSubject<DashboardPlaceholder>;
    layout$: BehaviorSubject<DashboardLayoutData[]>;
    stacked$: BehaviorSubject<boolean>;
    isDragging$: BehaviorSubject<DashboardWidgetComponent>;
    isGrabbing$: BehaviorSubject<DashboardWidgetComponent>;
    userLayoutChange$: Subject<DashboardLayoutData[]>;
    get options(): DashboardOptions;
    get widgets(): DashboardWidgetComponent[];
    get stacked(): boolean;
    get dimensions(): DashboardDimensions;
    get columnWidth(): number;
    /** Unsubscribe from all observables on destroy */
    private readonly _onDestroy;
    constructor();
    ngOnDestroy(): void;
    /**
     * Add a widget to the dashboard
     * @param widget The widget component to add to the dashboard
     */
    addWidget(widget: DashboardWidgetComponent): void;
    /**
     * Remove a widget from the dashboard
     * @param widget The widget to remove
     */
    removeWidget(widget: DashboardWidgetComponent): void;
    /**
     * Indicate that the dashboard element has been resized
     * @param width The width of the dashboard element in px
     * @param height The height of the dashboard element in px
     */
    setDimensions(width?: number, height?: number): void;
    /**
     * Produce an object containing all the required layout data.
     * This can be useful for exporting/saving a layout
     */
    getLayoutData(): DashboardLayoutData[];
    /**
     * Position widgets programatically
     */
    setLayoutData(widgets: DashboardLayoutData[]): void;
    /**
     * Update the positions and sizes of the widgets
     */
    renderDashboard(): void;
    /**
     * Determine where widgets should be positioned based on their positions, width and the size of the container
     */
    setDashboardLayout(): void;
    updateWhenStacked(): void;
    /** Get widgets in the order they visually appear as the widgets array order does not reflect this */
    getWidgetsByOrder(): DashboardWidgetComponent[];
    /**
     * Find a position that a widget can fit in the dashboard
     * @param widget The widget to try and position
     */
    setWidgetPosition(widget: DashboardWidgetComponent): void;
    /**
     * Check if a position in the dashboard is vacant or not
     */
    getPositionAvailable(column: number, row: number, columnSpan: number, rowSpan: number, ignoreWidget?: DashboardWidgetComponent): boolean;
    getOccupiedSpaces(): DashboardSpace[];
    /**
     * Begin resizing a widget
     * @param action The the widget to resize
     */
    onResizeStart(action: DashboardAction): void;
    onResizeDrag(action: DashboardAction): void;
    onResizeEnd(): void;
    onDragStart(action: DashboardAction): void;
    onDragEnd(): void;
    onDrag(action: DashboardAction): void;
    onDragScroll(widget: DashboardWidgetComponent, event: DragScrollEvent): void;
    getRowHeight(): number;
    cacheWidgets(): DashboardCache[];
    restoreWidgets(ignoreActionWidget?: boolean, cache?: DashboardCache[], restoreSize?: boolean): void;
    /**
     * Return the set of widgets which overlap the given dashboard region.
     */
    getOverlappingWidgets(region: DashboardRegion, actionWidget: DashboardWidgetComponent): DashboardWidgetComponent[];
    /**
     * Resolve any overlapping widgets after a widget changes rowSpan/colSpan.
     */
    resizeWidget(widget: DashboardWidgetComponent): void;
    /**
     * Move any widgets which intersect with the given dashboard region.
     */
    shiftWidgetsFromRegion(region: DashboardRegion, actionWidget: DashboardWidgetComponent, validatePosition?: (shiftDirection: ActionDirection) => void): void;
    /**
     * When dragging any widgets that need to be moved should be moved to an appropriate position
     */
    shiftWidgets(): void;
    /**
     * After shifts have taken place we should verify the place holder position is still valid
     * @param shiftDirection - the position widgets were shifted
     */
    validatePlaceholderPosition(shiftDirection: ActionDirection): void;
    /**
     * Determine if a widget can be moved left - or if it can move the widgets to the right to make space for the widget
     */
    canWidgetMoveLeft(widget: DashboardWidgetComponent, performMove?: boolean, shift?: number): boolean;
    /**
     * Determine if a widget can be moved right - or if it can move the widgets to the right to make space for the widget
     */
    canWidgetMoveRight(widget: DashboardWidgetComponent, performMove?: boolean, shift?: number): boolean;
    /**
     * Store the initial position of the widget being dragged
     */
    setWidgetOrigin(): void;
    /**
     * Calculate all the required positions is a widget was to be positioned at a particular point
     */
    getRequiredSpacesFromPoint(widget: DashboardWidgetComponent, column: number, row: number): DashboardSpace[];
    /**
     * Position widgets based on the position of the placeholder - this is temporary until confirmed
     */
    updateWidgetPositions(widget: DashboardWidgetComponent): void;
    /**
     * Determine if a widget is occupying a specific row and column
     * @param column The columns to check if occupied
     * @param row The row to check if occupied
     * @param ignoreResizing Whether or not to ignore the widget currently being resized
     */
    getWidgetsAtPosition(column: number, row: number, ignoreResizing?: boolean): DashboardWidgetComponent[];
    /**
     * Update the placeholder visibility, position and size
     */
    setPlaceholderBounds(visible: boolean, x: number, y: number, width: number, height: number): void;
    /**
     * Get the placeholder column position
     */
    getPlaceholderColumn(x: number, width: number): number;
    /**
     * Get the column span of the placeholder
     */
    getPlaceholderColumnSpan(width: number): number;
    /**
     * Get the row position of the placeholder
     */
    getPlaceholderRow(y: number, height: number): number;
    /**
     * Get the row span of the placeholder
     */
    getPlaceholderRowSpan(height: number): number;
    getColumnFromPx(x: number, rounding?: Rounding): number;
    getRowFromPx(y: number, rounding?: Rounding): number;
    commitWidgetChanges(): void;
    /**
     * Get the current column width
     */
    getColumnWidth(): number;
    /**
     * Calculate the number of rows populated with widgets
     */
    getRowCount(): number;
    /**
     * Set the height of the dashboard container element
     */
    setDashboardHeight(): void;
    /**
     * Orders the z-index of all widgets to move the active one to the front
     * @param widget The widget that should be brought to the front
     */
    bringToFront(widget: DashboardWidgetComponent): void;
    /**
     * Move a widget down - if widgets are in the position below, then move them down further
     * @param widget The widget to move downwards
     */
    moveWidgetDown(widget: DashboardWidgetComponent, distance?: number): void;
    /**
     * Widgets should not be allowed to have a vacant space above them - if there is one they should move upwards to fill it
     */
    shiftWidgetsUp(): boolean;
    /**
     * Iterate over each space a widget occupied
     * @param widget The widget to determine spaces
     * @param callback The function to be called for each space, should expect a column and row argument witht he context being the widget
     */
    forEachBlock(widget: DashboardWidgetComponent, callback: (column: number, row: number) => void): void;
    getWidgetBelow(widget: DashboardWidgetComponent): DashboardWidgetComponent | null;
    /**
     * Returns the number of columns available
     */
    getColumnCount(): number;
    onShiftStart(widget: DashboardWidgetComponent): void;
    /** Programmatically move a widget in a given direction */
    onShift(widget: DashboardWidgetComponent, direction: ActionDirection): void;
    onShiftEnd(): void;
    /** Programmatically resize a widget in a given direction */
    onResize(widget: DashboardWidgetComponent, direction: ActionDirection): void;
    getSurroundingWidgets(widget: DashboardWidgetComponent, direction: ActionDirection): DashboardWidgetComponent[];
    private moveWidget;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DashboardService>;
}
declare const defaultOptions: DashboardOptions;
interface DashboardDimensions {
    width?: number;
    height?: number;
}
interface DashboardWidgetDimensions {
    x: number;
    y: number;
    width: number;
    height: number;
}
interface DashboardAction {
    widget: DashboardWidgetComponent;
    direction: ActionDirection;
    event?: MouseEvent;
    handle?: HTMLElement;
}
interface DashboardSpace {
    widget: DashboardWidgetComponent;
    column: number;
    row: number;
}
interface DashboardRegion {
    column?: number;
    row?: number;
    columnSpan?: number;
    rowSpan?: number;
}
interface DashboardPlaceholder extends DashboardRegion {
    visible: boolean;
    x: number;
    y: number;
    width: number;
    height: number;
}
interface DashboardCache {
    id: string;
    column: number;
    row: number;
    columnSpan: number;
    rowSpan: number;
}
interface DashboardLayoutData {
    id: string;
    col: number;
    row: number;
    colSpan: number;
    rowSpan: number;
    minColSpan?: number;
    minRowSpan?: number;
}
declare enum ActionDirection {
    Top = 0,
    TopRight = 1,
    Right = 2,
    BottomRight = 3,
    Bottom = 4,
    BottomLeft = 5,
    Left = 6,
    TopLeft = 7,
    Move = 8
}
declare enum Rounding {
    RoundDown = 0,
    RoundDownBelowHalf = 1,
    RoundUp = 2,
    RoundUpOverHalf = 3
}

declare class DashboardGrabHandleDirective implements OnInit, OnDestroy {
    readonly widget: DashboardWidgetComponent;
    private readonly _dashboard;
    private readonly _handle;
    private readonly _elementRef;
    private readonly _announcer;
    /** Specify whether or not this handle can be used to perform moving */
    uxGrabAllowMove: boolean;
    /** Specify whether or not this handle can be used to perform resizing */
    uxGrabAllowResize: boolean;
    /** The aria label for the grab handle */
    uxGrabAriaLabel: (widget: DashboardWidgetComponent) => string | string;
    /** Customize the announcement that is made whenever an item has successfully been moved or resized */
    uxGrabChangeSuccessAnnouncement: (widget: DashboardWidgetComponent, differences: DashboardLayoutDiff[]) => string | string;
    /** Customize the announcement that is made whenever an item enters 'grab' mode */
    uxGrabStartAnnouncement: (widget: DashboardWidgetComponent) => string | string;
    /** Customize the announcement thqt is made whenever an item cannot be moved */
    uxGrabMoveFailAnnouncement: (widget: DashboardWidgetComponent, direction: ActionDirection) => string | string;
    /** Customize the announcement thqt is made whenever an item cannot be resized */
    uxGrabResizeFailAnnouncement: (widget: DashboardWidgetComponent, direction: ActionDirection) => string | string;
    /** Customize the announcement made whenever the moving/resizing is commited */
    uxGrabConfirmAnnouncement: (widget: DashboardWidgetComponent) => string | string;
    /** Customize the announcement made whenever the moving/resizing is cancelled */
    uxGrabCancelAnnouncement: (widget: DashboardWidgetComponent) => string | string;
    /** Binding for the grab handle aria label */
    ariaLabel: string;
    /** We must programmatically control the focus of the drag handles */
    tabIndex: number;
    /** Store the current dragging state */
    isGrabbing: boolean;
    /** Store the current layout when we enter 'grab' mode */
    private _cache;
    /** Store the layout after the most recent successful move or resize */
    private _lastMovement;
    /** Emit when the directive is destroyed to unsubscribe from all observables */
    private readonly _onDestroy;
    constructor();
    /** Set the initial aria label and subscribe to layout changes */
    ngOnInit(): void;
    /** Unsubscribe from all observables */
    ngOnDestroy(): void;
    /** Begin drag mode and cache initial state */
    enableDragMode(): void;
    /** Finish drag mode and commit the current state */
    disableDragMode(): void;
    /** Finish the drag mode and restore the original state */
    cancelDragMode(): void;
    /** Toggle the drag mode state */
    toggleDragMode(): void;
    /** Set the tab index and optionally focus the DOM element */
    focus(focusElement?: boolean): void;
    /** Make this item non-tabbable */
    blur(): void;
    /** When the grab handle loses focus then exit 'grab' mode */
    onBlur(): void;
    /** Handle key events */
    onKeydown(event: KeyboardEvent, key: number, ctrlKey: boolean): void;
    /** Get an announcement from the inputs - they may be a string or a function so handle both */
    getAnnouncement(announcement: Function | string, ...args: any[]): string;
    /** Move the widget in a given direction based on arrow keys */
    private moveWidget;
    /** Resize the widgets accordingly based on the arrow keys */
    private resizeWidget;
    /** Shift focus between the variour grab handles */
    private moveFocus;
    /** Convert an arrow key code into an ActionDirection enum */
    private getDirectionFromKey;
    /** Supply the default grab handle aria label based on the provided constraints */
    private getDefaultAriaLabel;
    /** Get the default announcement whenever a movement or resize was successful */
    private getChangeSuccessAnnouncement;
    private getDiffAnnouncements;
    /** Get the default announcement whenever a movement is not possible due to dashboard boundaries */
    private getMoveFailAnnouncement;
    /** Get the default announcement whenever a resize is not possible due to either widget constraints of dashboard bounds */
    private getResizeFailAnnouncement;
    /** Get the default announcement whenever we enter 'grab' mode */
    private getStartAnnouncement;
    /** Get the default announcement whenever grab mode is exited after a movement or resize */
    private getConfirmAnnouncement;
    /** Get the default announcement whenever grab mode is exited after being cancelled */
    private getCancellationAnnouncement;
    /** Get a description of all dashboard widgets, their positions and sizes */
    private getDashboardAriaLabel;
    /** Get a description of a given widget */
    private getWidgetAriaLabel;
    /** Get an object describing all the changes that have been made to all widgets since the last change */
    private getLayoutDiff;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardGrabHandleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DashboardGrabHandleDirective, "[uxDashboardGrabHandle]", ["ux-dashboard-grab-handle"], { "uxGrabAllowMove": { "alias": "uxGrabAllowMove"; "required": false; }; "uxGrabAllowResize": { "alias": "uxGrabAllowResize"; "required": false; }; "uxGrabAriaLabel": { "alias": "uxGrabAriaLabel"; "required": false; }; "uxGrabChangeSuccessAnnouncement": { "alias": "uxGrabChangeSuccessAnnouncement"; "required": false; }; "uxGrabStartAnnouncement": { "alias": "uxGrabStartAnnouncement"; "required": false; }; "uxGrabMoveFailAnnouncement": { "alias": "uxGrabMoveFailAnnouncement"; "required": false; }; "uxGrabResizeFailAnnouncement": { "alias": "uxGrabResizeFailAnnouncement"; "required": false; }; "uxGrabConfirmAnnouncement": { "alias": "uxGrabConfirmAnnouncement"; "required": false; }; "uxGrabCancelAnnouncement": { "alias": "uxGrabCancelAnnouncement"; "required": false; }; }, {}, never, never, true, never>;
}
interface DashboardLayoutDiff {
    widget: DashboardWidgetComponent;
    previousColumn: number;
    currentColumn: number;
    previousRow: number;
    currentRow: number;
    previousColumnSpan: number;
    currentColumnSpan: number;
    previousRowSpan: number;
    currentRowSpan: number;
    isMovedLeft: boolean;
    isMovedRight: boolean;
    isMovedUp: boolean;
    isMovedDown: boolean;
    isMovedHorizontally: boolean;
    isMovedVertically: boolean;
    isResized: boolean;
    isMoved: boolean;
}

declare class DashboardComponent implements AfterViewInit, AfterContentInit, OnDestroy, OnChanges {
    readonly dashboardService: DashboardService;
    private readonly _changeDetector;
    isGrabbing: boolean;
    customAriaLabel: (widgets: DashboardWidgetComponent[], options: DashboardOptions) => string | string;
    /** If defined or changed this will set the positions of the widgets within the dashboard. This is a two way binding that will be updated with the current layout when it changes. */
    set layout(layout: DashboardLayoutData[]);
    /** Configures the options for the dashboard, if an option is not specified the default value will be used. */
    set options(options: DashboardOptions);
    /** Emits when layout has been changed. */
    layoutChange: EventEmitter<DashboardLayoutData[]>;
    ariaLabel: string;
    role: string;
    dashboardElement: ElementRef;
    /** Find all grab handles used in the dashboard */
    handles: QueryList<DashboardGrabHandleDirective>;
    /** Ensure we unsubscribe from all observables */
    private readonly _onDestroy;
    constructor();
    /**
     * Set the initial dimensions
     */
    ngAfterViewInit(): void;
    ngAfterContentInit(): void;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    onResize(event: ResizeDimensions): void;
    getAriaLabel(): string;
    /** Shift widgets up where possible to fill any available space to optimize the dashboard layout */
    refreshLayout(): void;
    private getDefaultAriaLabel;
    private getWidgetAriaLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DashboardComponent, "ux-dashboard", never, { "customAriaLabel": { "alias": "aria-label"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "options": { "alias": "options"; "required": false; }; "role": { "alias": "role"; "required": false; }; }, { "layoutChange": "layoutChange"; }, ["handles"], ["*"], true, never>;
}
interface DashboardOptions {
    columns?: number;
    padding?: number;
    minWidth?: number;
    minHeight?: number;
    rowHeight?: number;
    emptyRow?: boolean;
}

declare class DashboardDragHandleDirective extends DragDirective {
    readonly widget: DashboardWidgetComponent;
    readonly dashboardService: DashboardService;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardDragHandleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DashboardDragHandleDirective, "[uxDashboardWidgetDragHandle], [ux-dashboard-widget-drag-handle]", never, {}, {}, never, never, true, never>;
}

declare class DashboardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DashboardModule, never, [typeof i1.A11yModule, typeof i2.CommonModule, typeof ResizeModule, typeof DragModule, typeof DashboardComponent, typeof DashboardWidgetComponent, typeof DashboardDragHandleDirective, typeof DashboardGrabHandleDirective], [typeof DashboardComponent, typeof DashboardWidgetComponent, typeof DashboardDragHandleDirective, typeof DashboardGrabHandleDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DashboardModule>;
}

type DateFormatter = (date: Date) => string;

/**
 * Convert a single dimension array to a double dimension array
 * @param items the single dimension array to convert
 * @param columns the number of items each array should have
 */
declare function gridify<T>(items: T[], columns: number): T[][];
/**
 * Create an array of numbers between two limits
 * @param start the lower limit
 * @param end the upper limit
 */
declare function range(start: number, end: number): number[];
/**
 * Create an array of dates between two points
 * @param start the date to start the array
 * @param end the date to end the array
 */
declare function dateRange(start: Date, end: Date): Date[];
/**
 * Compare two dates to see if they are on the same day
 * @param day1 the first date to compare
 * @param day2 the second date to compare
 */
declare function compareDays(day1: Date, day2: Date): boolean;
/**
 * Date comparison for use primarily with distinctUntilChanged
 */
declare function dateComparator(dateOne: Date, dateTwo: Date): boolean;
/**
 * Calculate the number of days between two dates
 * @param start The start date
 * @param end The end date
 * @param fullDay Whether or not we should take from 00:00 on the start date and 23:59 on the end date
 */
declare function differenceBetweenDates(start: Date, end: Date, fullDay?: boolean): number | null;
/**
 * Timezone comparison for use primarily with distinctUntilChanged
 */
declare function timezoneComparator(zoneOne: DateTimePickerTimezone, zoneTwo: DateTimePickerTimezone): boolean;
/**
 * Get a date object with the time of the start of the given day
 * @param date The date to get the start of day
 */
declare function getStartOfDay(date: Date): Date;
declare function isDateAfter(date: Date, after: Date, isEqual?: boolean): boolean;
declare function isDateBefore(date: Date, before: Date, isEqual?: boolean): boolean;
/**
 * Export an array of all the available months
 */
declare const months: string[];
declare const monthsShort: string[];
/**
 * Export an array of all the available days of the week
 */
declare const weekdays: string[];
declare const weekdaysShort: string[];
declare const meridians: string[];
/** Export the default set of time zone */
declare const timezones: DateTimePickerTimezone[];
interface DateTimePickerTimezone {
    name: string;
    offset: number;
}

declare class DateRangeService {
    /** Indicate whether we want to show a date range */
    isRange: boolean;
    /** Specify the direction of the selection */
    direction: DateRangePicker;
    /** Specify the start of the range */
    start: Date;
    /** Specify the end of the range */
    end: Date;
    /** Specify the date we are hovering over */
    hover: Date;
    /** Emit whenever the start date changes */
    onStartChange: Subject<Date>;
    /** Emit whenever the end date changes */
    onEndChange: Subject<Date>;
    /** Emit whenever the range has changed */
    onRangeChange: Subject<void>;
    /** Emit whenever the hover date changes */
    onHoverChange: Subject<void>;
    /** Emit whenever the range is cleared */
    onClear: Subject<void>;
    /** Indicate if we should show time */
    showTime: boolean;
    /** Defines the aria label for the range start picker */
    startPickerAriaLabel: string;
    /** Defines the aria label for the range end picker */
    endPickerAriaLabel: string;
    /** Indicate if we are currently changing the time */
    isChangingTime: boolean;
    /** Store the current start time */
    startTime: DateRangeTime;
    /** Store the current end time */
    endTime: DateRangeTime;
    setStartDate(date: Date | null): void;
    setEndDate(date: Date | null): void;
    clear(): void;
    setDateMouseEnter(date: Date | null): void;
    setDateMouseLeave(date: Date): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateRangeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DateRangeService>;
}
declare enum DateRangePicker {
    Start = "start",
    End = "end"
}
interface DateRangeTime {
    hours: number;
    minutes: number;
    seconds: number;
}

declare class DateRangePickerComponent implements OnDestroy {
    readonly rangeService: DateRangeService;
    private readonly _destroyRef;
    /** Expose enum to the view */
    DateRangePicker: typeof DateRangePicker;
    /** The selected start date to be displayed in the component. */
    set start(start: Date);
    /** The selected end date to be displayed in the component. */
    set end(end: Date);
    /** Define the date localization that should be used can be either a string on a function */
    dateFormat: string | DateFormatter;
    /** Define the time localization that should be used can be either a string on a function */
    timeFormat: string | DateFormatter;
    /** The earliest selectable date. */
    min: Date;
    /** The latest selectable date. */
    max: Date;
    /** Defines whether or not the time picker should allow the user to choose a timezone. */
    showTimezone: boolean;
    /** Defines whether or not the time picker should allow the user to specify seconds. */
    showSeconds: boolean;
    /** Defines whether or not the time picker should show an AM/PM button, or time should be represented in 24hr format instead. */
    showMeridian: boolean;
    /** Defines whether or not the time picker should allow the user to select the time using spinners. */
    showSpinners: boolean;
    /** If defined will override the weekday names displayed. */
    weekdays: string[];
    /** Defines the names of the months. */
    months: string[];
    /** Defines the short names of each month. */
    monthsShort: string[];
    /** Defines the labels to show in the meridian (AM/PM) selector. */
    meridians: string[];
    /** Defines the text to be displayed in the button used to set the selected time to the current time. */
    nowBtnText: string;
    /** Specify whether or not the show now button should be visible */
    showNowBtn: boolean;
    /** Defines the title to display above the start picker. */
    selectStartTitle: string;
    /** Defines the title to display above the end picker. */
    selectEndTitle: string;
    /** Define the aria label for the now button */
    nowBtnAriaLabel: string;
    /** Defines the aria label for the range start picker */
    set startPickerAriaLabel(label: string);
    /** Defines the aria label for the range end picker */
    set endPickerAriaLabel(label: string);
    /** Defines whether or not the time picker should be visible. */
    set showTime(showTime: boolean);
    get showTime(): boolean;
    /**
     * Defines the list of available timezones. The `DateTimePickerTimezone` interface specifies that each timezone should
     * be an object with a `name` property that represents the timezone, eg. `GMT+2`, and an `offset` property that represents
     * the number of minutes relative to GMT the timezone is.
     */
    timezones: DateTimePickerTimezone[];
    /** Will set the selected start timezone. */
    startTimezone: DateTimePickerTimezone;
    /** Will set the selected end timezone. */
    endTimezone: DateTimePickerTimezone;
    /** Defines the day of the week that should appear in the first column. `WeekDay` is an enumeration available in `@angular/common`. */
    startOfWeek: WeekDay;
    /** Define a function to return the number of days within the selected range */
    durationTitle: (days: number) => string;
    /** Emit when the start date changes */
    startChange: EventEmitter<Date>;
    /** Emit when the end date changes */
    endChange: EventEmitter<Date>;
    /** Emit when the start timezone changes. */
    startTimezoneChange: EventEmitter<DateTimePickerTimezone>;
    /** Emit when the end timezone changes. */
    endTimezoneChange: EventEmitter<DateTimePickerTimezone>;
    /** Calculate the number of days between the start and end date */
    get _duration(): number | null;
    /** Use an observable to debounce rapid start changes */
    startChange$: Subject<Date>;
    /** Use an observable to debounce rapid end changes */
    endChange$: Subject<Date>;
    /** Unsubscribe from all observables private  */
    private readonly _onDestroy;
    constructor();
    ngOnDestroy(): void;
    /** Clear the selected date range */
    clear(): void;
    /** Get the timezone based on the machine timezone */
    private getCurrentTimezone;
    private onStartChange;
    private onEndChange;
    /** Get the text to display to indicate the duration */
    private getDurationTitle;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateRangePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateRangePickerComponent, "ux-date-range-picker", never, { "start": { "alias": "start"; "required": false; }; "end": { "alias": "end"; "required": false; }; "dateFormat": { "alias": "dateFormat"; "required": false; }; "timeFormat": { "alias": "timeFormat"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "showTimezone": { "alias": "showTimezone"; "required": false; }; "showSeconds": { "alias": "showSeconds"; "required": false; }; "showMeridian": { "alias": "showMeridian"; "required": false; }; "showSpinners": { "alias": "showSpinners"; "required": false; }; "weekdays": { "alias": "weekdays"; "required": false; }; "months": { "alias": "months"; "required": false; }; "monthsShort": { "alias": "monthsShort"; "required": false; }; "meridians": { "alias": "meridians"; "required": false; }; "nowBtnText": { "alias": "nowBtnText"; "required": false; }; "showNowBtn": { "alias": "showNowBtn"; "required": false; }; "selectStartTitle": { "alias": "selectStartTitle"; "required": false; }; "selectEndTitle": { "alias": "selectEndTitle"; "required": false; }; "nowBtnAriaLabel": { "alias": "nowBtnAriaLabel"; "required": false; }; "startPickerAriaLabel": { "alias": "startPickerAriaLabel"; "required": false; }; "endPickerAriaLabel": { "alias": "endPickerAriaLabel"; "required": false; }; "showTime": { "alias": "showTime"; "required": false; }; "timezones": { "alias": "timezones"; "required": false; }; "startTimezone": { "alias": "startTimezone"; "required": false; }; "endTimezone": { "alias": "endTimezone"; "required": false; }; "startOfWeek": { "alias": "startOfWeek"; "required": false; }; "durationTitle": { "alias": "durationTitle"; "required": false; }; }, { "startChange": "startChange"; "endChange": "endChange"; "startTimezoneChange": "startTimezoneChange"; "endTimezoneChange": "endTimezoneChange"; }, never, never, true, never>;
}

declare class DateRangeOptions {
    picker: DateRangePicker;
}
declare class DateRangePickerDirective {
    private readonly _options;
    /** Specify whether this is the start or end picker */
    set picker(picker: DateRangePicker);
    static ɵfac: i0.ɵɵFactoryDeclaration<DateRangePickerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DateRangePickerDirective, "[uxDateRangePicker]", never, { "picker": { "alias": "picker"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FocusIfDirective implements OnDestroy {
    private readonly _elementRef;
    /** The delay that should ellapse before focussing the element */
    focusIfDelay: number;
    /** Determine if we should scroll the element into view when focused */
    focusIfScroll: boolean;
    /** Focus when the boolean value is true */
    set focusIf(focus: boolean);
    private _timeout;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusIfDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FocusIfDirective, "[focusIf]", never, { "focusIfDelay": { "alias": "focusIfDelay"; "required": false; }; "focusIfScroll": { "alias": "focusIfScroll"; "required": false; }; "focusIf": { "alias": "focusIf"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FocusIfModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusIfModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FocusIfModule, never, [typeof FocusIfDirective], [typeof FocusIfDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FocusIfModule>;
}

declare const SPIN_BUTTON_VALUE_ACCESSOR: {
    provide: i0.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: i0.Type<any>;
    multi: boolean;
};
declare class SpinButtonComponent implements ControlValueAccessor {
    private readonly _changeDetector;
    set value(value: string | number);
    get value(): string | number;
    type: string;
    min: number;
    max: number;
    placeholder: string;
    disabled: boolean;
    spinners: boolean;
    readOnly: boolean;
    scrolling: boolean;
    arrowkeys: boolean;
    maxLength: number;
    incrementAriaLabel: string;
    inputAriaLabel: string;
    decrementAriaLabel: string;
    valueChange: EventEmitter<string | number>;
    increment: EventEmitter<void>;
    decrement: EventEmitter<void>;
    onTouchedCallback: () => void;
    onChangeCallback: (_: string | number) => void;
    private _value;
    private readonly _regexKeypress;
    private readonly _regexPaste;
    scroll(event: WheelEvent): void;
    triggerIncrement(): void;
    triggerDecrement(): void;
    writeValue(value: string | number): void;
    registerOnChange(fn: (_: string | number) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onKeypress(event: KeyboardEvent): boolean;
    onPaste(event: ClipboardEvent): void;
    onValueChange(input: HTMLInputElement, value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SpinButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SpinButtonComponent, "ux-spin-button", never, { "value": { "alias": "value"; "required": false; }; "type": { "alias": "type"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "spinners": { "alias": "spinners"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "scrolling": { "alias": "scrolling"; "required": false; }; "arrowkeys": { "alias": "arrowkeys"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "incrementAriaLabel": { "alias": "incrementAriaLabel"; "required": false; }; "inputAriaLabel": { "alias": "inputAriaLabel"; "required": false; }; "decrementAriaLabel": { "alias": "decrementAriaLabel"; "required": false; }; }, { "valueChange": "valueChange"; "increment": "increment"; "decrement": "decrement"; }, never, never, true, never>;
}

declare class SpinButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SpinButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SpinButtonModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof i3$2.FormsModule, typeof IconModule, typeof SpinButtonComponent], [typeof SpinButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SpinButtonModule>;
}

declare const TIME_PICKER_VALUE_ACCESSOR: {
    provide: i0.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: i0.Type<any>;
    multi: boolean;
};
declare class TimePickerComponent implements ControlValueAccessor {
    private readonly _changeDetector;
    /** Whether the arrow keys can be used to increment or decrement the selected time component. */
    arrowkeys: boolean;
    /** Whether the mouse scroll wheel can be used to increment or decrement the selected time component. */
    mousewheel: boolean;
    /** Whether the control is disabled. */
    disabled: boolean;
    /** Whether the control is readonly. */
    readOnly: boolean;
    /** Whether to show the meridian (AM/PM) selector. If this is false, the 24-hour clock will be used. */
    showMeridian: boolean;
    /** Whether to show the hour selector. */
    showHours: boolean;
    /** Whether to show the minute selector. */
    showMinutes: boolean;
    /** Whether to show the second selector. */
    showSeconds: boolean;
    /** Whether to show increment and decrement buttons in the time picker. */
    showSpinners: boolean;
    /** The number of hours to increment or decrement by when using the spinner buttons, arrow keys, or mouse scroll wheel. */
    hourStep: number;
    /** The number of minutes to increment or decrement by when using the spinner buttons, arrow keys, or mouse scroll wheel. */
    minuteStep: number;
    /** The number of seconds to increment or decrement by when using the spinner buttons, arrow keys, or mouse scroll wheel. */
    secondStep: number;
    /** The minimum value that the component will allow. */
    min: Date;
    /** The maximum value that the component will allow. */
    max: Date;
    /** An array containing the labels to show in the meridian selector. */
    meridians: string[];
    /** The value to display. */
    set value(value: Date);
    get value(): Date;
    get _meridian(): string;
    get _valid(): boolean;
    /** Emitted when the `value` changes. */
    valueChange: EventEmitter<Date>;
    /** Emitted when the validity of the control changes. */
    isValid: EventEmitter<boolean>;
    onTouchedCallback: () => void;
    onChangeCallback: (_: Date) => void;
    private _value;
    private _isValid;
    protected get isValidDate(): boolean;
    writeValue(value: Date): void;
    registerOnChange(fn: (_: Date) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    getMeridianTime(hour: number): number;
    setHour(hour: number): void;
    setMinute(minute: number): void;
    setSeconds(seconds: number): void;
    incrementHour(arrowkey?: boolean): void;
    decrementHour(arrowkey?: boolean): void;
    incrementMinute(arrowkey?: boolean): void;
    decrementMinute(arrowkey?: boolean): void;
    incrementSecond(arrowkey?: boolean): void;
    decrementSecond(arrowkey?: boolean): void;
    selectMeridian(meridian: string): void;
    checkValidity(date: Date): boolean;
    hourChange(value: string | number): void;
    minuteChange(value: string | number): void;
    secondChange(value: string | number): void;
    /** Normalise a date's year/month/date components. */
    private normalizeDate;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimePickerComponent, "ux-time-picker", never, { "arrowkeys": { "alias": "arrowkeys"; "required": false; }; "mousewheel": { "alias": "mousewheel"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "showMeridian": { "alias": "showMeridian"; "required": false; }; "showHours": { "alias": "showHours"; "required": false; }; "showMinutes": { "alias": "showMinutes"; "required": false; }; "showSeconds": { "alias": "showSeconds"; "required": false; }; "showSpinners": { "alias": "showSpinners"; "required": false; }; "hourStep": { "alias": "hourStep"; "required": false; }; "minuteStep": { "alias": "minuteStep"; "required": false; }; "secondStep": { "alias": "secondStep"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "meridians": { "alias": "meridians"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "valueChange": "valueChange"; "isValid": "isValid"; }, never, never, true, never>;
}

declare class TimePickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimePickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TimePickerModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof i3$2.FormsModule, typeof SpinButtonModule, typeof TimePickerComponent], [typeof TimePickerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TimePickerModule>;
}

declare class DateTimePickerService implements OnDestroy {
    private readonly _config;
    readonly rangeService: DateRangeService;
    readonly rangeOptions: DateRangeOptions;
    mode$: BehaviorSubject<DatePickerMode>;
    date$: BehaviorSubject<Date>;
    timezone$: BehaviorSubject<DateTimePickerTimezone>;
    selected$: BehaviorSubject<Date>;
    month$: BehaviorSubject<number>;
    year$: BehaviorSubject<number>;
    showDate$: BehaviorSubject<boolean>;
    showTime$: BehaviorSubject<boolean>;
    showTimezone$: BehaviorSubject<boolean>;
    showSeconds$: BehaviorSubject<boolean>;
    showMeridian$: BehaviorSubject<boolean>;
    showSpinners$: BehaviorSubject<boolean>;
    showNowBtn$: BehaviorSubject<boolean>;
    weekdays$: BehaviorSubject<string[]>;
    nowBtnText$: BehaviorSubject<string>;
    timezones$: BehaviorSubject<DateTimePickerTimezone[]>;
    min$: BehaviorSubject<Date>;
    max$: BehaviorSubject<Date>;
    header$: BehaviorSubject<string>;
    headerEvent$: Subject<DatePickerHeaderEvent>;
    modeDirection: ModeDirection;
    startOfWeek$: BehaviorSubject<WeekDay>;
    months: string[];
    monthsShort: string[];
    meridians: string[];
    hours: number;
    minutes: number;
    seconds: number;
    yearRange: YearRange;
    /**
     * Store whether or not the component has fully initialised or not. We use this to prevent initial
     * focus on the end date range picker when the popover is first opened
     */
    initialised: boolean;
    private readonly _subscription;
    constructor();
    ngOnDestroy(): void;
    setViewportMonth(month: number): void;
    setViewportYear(year: number): void;
    setDate(day: number, month: number, year: number, hours?: number, minutes?: number, seconds?: number): void;
    setDateToNow(): void;
    setViewportMode(mode: DatePickerMode): void;
    goToChildMode(): void;
    goToParentMode(): void;
    goToNext(): void;
    goToPrevious(): void;
    setHeader(header: string): void;
    isTimezoneAvailable(timezone: DateTimePickerTimezone): boolean;
    getDefaultTimezone(): DateTimePickerTimezone;
    isInRange(date: Date): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateTimePickerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DateTimePickerService>;
}
declare enum DatePickerMode {
    Day = 0,
    Month = 1,
    Year = 2
}
declare enum ModeDirection {
    None = 0,
    Ascend = 1,
    Descend = 2
}
declare enum DatePickerHeaderEvent {
    Previous = 0,
    Next = 1
}
interface YearRange {
    start: number;
    end: number;
    range: number[];
}

declare class DateTimePickerComponent implements OnInit, AfterViewInit, OnDestroy {
    readonly datepicker: DateTimePickerService;
    private readonly _rangeService;
    private readonly _rangeOptions;
    /** Defines whether or not the date picker should be visible. */
    set showDate(value: boolean);
    /** Defines whether or not the time picker should be visible. */
    set showTime(value: boolean);
    /** Defines whether or not the time picker should allow the user to choose a timezone. */
    set showTimezone(value: boolean);
    /** Defines whether or not the time picker should allow the user to specify seconds. */
    set showSeconds(value: boolean);
    /** Defines whether or not the time picker should show an AM/PM button, or time should be represented in 24hr format instead. */
    set showMeridian(value: boolean);
    /** Defines whether or not the time picker should allow the user to select the time using spinners. */
    set showSpinners(value: boolean);
    /** If defined will override the weekday names displayed. */
    set weekdays(value: string[]);
    /** Defines the names of the months. */
    set months(months: string[]);
    /** Defines the short names of each month. */
    set monthsShort(months: string[]);
    /** Defines the labels to show in the meridian (AM/PM) selector. */
    set meridians(meridians: string[]);
    /** Defines the text to be displayed in the button used to set the selected time to the current time. */
    set nowBtnText(value: string);
    /** Specify whether or not to show the show now button */
    set showNowBtn(value: boolean);
    /**
     * Defines the list of available timezones. The `DateTimePickerTimezone` interface specifies that each timezone should
     * be an object with a `name` property that represents the timezone, eg. `GMT+2`, and an `offset` property that represents
     * the number of minutes relative to GMT the timezone is.
     */
    set timezones(value: DateTimePickerTimezone[]);
    /** Defines the day of the week that should appear in the first column. `WeekDay` is an enumeration available in `@angular/common`. */
    set startOfWeek(startOfWeek: WeekDay);
    /** Define the aria label for the now button */
    nowBtnAriaLabel: string;
    /** Emits an event when the date is changed using the component. */
    dateChange: EventEmitter<Date>;
    /** If not defined the picker will try to use the user's timezone. If that is not available, it will revert to GMT. */
    timezoneChange: EventEmitter<DateTimePickerTimezone>;
    /** The selected date to be displayed in the component. */
    set date(value: Date);
    /** Will set the selected timezone. */
    set timezone(value: DateTimePickerTimezone);
    /** The earliest selectable date. */
    set min(value: Date);
    /** The latest selectable date. */
    set max(value: Date);
    /** Determine if we are in range selection mode */
    get _isRangeMode(): boolean;
    /** Determine if this picker is the start picker */
    get _isRangeStart(): boolean;
    /** Determine if this picker is the end picker */
    get _isRangeEnd(): boolean;
    /** Determine if the today button is disabled */
    get _isTodayDisabled(): boolean;
    DatePickerMode: typeof DatePickerMode;
    private readonly _onDestroy;
    constructor();
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * Change the date to the current date and time
     */
    setToNow(): void;
    _onTimezoneChange(timezone: DateTimePickerTimezone): void;
    /**
     * Update the service with the new timezone value, falling back on the default if it is undefined or
     * not present in `timezones`.
     */
    private setTimezone;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateTimePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateTimePickerComponent, "ux-date-time-picker", never, { "showDate": { "alias": "showDate"; "required": false; }; "showTime": { "alias": "showTime"; "required": false; }; "showTimezone": { "alias": "showTimezone"; "required": false; }; "showSeconds": { "alias": "showSeconds"; "required": false; }; "showMeridian": { "alias": "showMeridian"; "required": false; }; "showSpinners": { "alias": "showSpinners"; "required": false; }; "weekdays": { "alias": "weekdays"; "required": false; }; "months": { "alias": "months"; "required": false; }; "monthsShort": { "alias": "monthsShort"; "required": false; }; "meridians": { "alias": "meridians"; "required": false; }; "nowBtnText": { "alias": "nowBtnText"; "required": false; }; "showNowBtn": { "alias": "showNowBtn"; "required": false; }; "timezones": { "alias": "timezones"; "required": false; }; "startOfWeek": { "alias": "startOfWeek"; "required": false; }; "nowBtnAriaLabel": { "alias": "nowBtnAriaLabel"; "required": false; }; "date": { "alias": "date"; "required": false; }; "timezone": { "alias": "timezone"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; }, { "dateChange": "dateChange"; "timezoneChange": "timezoneChange"; }, never, never, true, never>;
}

declare class HeaderComponent implements AfterViewInit, OnDestroy {
    readonly datepicker: DateTimePickerService;
    private readonly _changeDetector;
    private readonly _rangeService;
    private readonly _rangeOptions;
    canAscend$: Observable<boolean>;
    mode$: Observable<string>;
    headerAria$: Observable<string>;
    previousAria$: Observable<string>;
    nextAria$: Observable<string>;
    /** Determine if we are in range selection mode */
    get _isRangeMode(): boolean;
    /** Determine if this picker is the start picker */
    get _isRangeStart(): boolean;
    /** Determine if this picker is the end picker */
    get _isRangeEnd(): boolean;
    get _rangeStart(): Date | null;
    get _rangeEnd(): Date | null;
    /** Unsubscribe from all observables */
    private readonly _onDestroy;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /** Navigate to the previous day, month or year */
    previous(): void;
    /** Navigate to the larger scale, eg. Days -> Months, Months -> Years */
    ascend(): void;
    /** Navigate to the previous day, month or year */
    next(): void;
    /** Determine if the previous button is enabled */
    isPreviousDisabled(): boolean;
    /** Determine if the previous button is enabled */
    isNextDisabled(): boolean;
    private _isBeforeView;
    private _isAfterView;
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HeaderComponent, "ux-date-time-picker-header", never, {}, {}, never, never, true, never>;
}

declare class DayViewService implements OnDestroy {
    private readonly _datepicker;
    grid$: BehaviorSubject<DayViewItem[][]>;
    focused$: BehaviorSubject<FocusedDayItem>;
    private readonly _subscription;
    constructor();
    ngOnDestroy(): void;
    setFocus(day: number, month: number, year: number): void;
    private createDayGrid;
    /**
     * Determine whether or not a specific date is today
     * @param date The date to check
     */
    private isToday;
    /**
     * Determines whether or not a specific date is the selected one
     * @param date the date to check
     */
    private isActive;
    static ɵfac: i0.ɵɵFactoryDeclaration<DayViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DayViewService>;
}
interface DayViewItem {
    day: number;
    month: number;
    year: number;
    date: Date;
    isToday: boolean;
    isActive: boolean;
    isCurrentMonth: boolean;
}
interface FocusedDayItem {
    day: number;
    month: number;
    year: number;
}

declare class DayViewComponent implements AfterViewInit, OnDestroy {
    readonly datePicker: DateTimePickerService;
    readonly dayService: DayViewService;
    private readonly _changeDetector;
    private readonly _focusOrigin;
    private readonly _liveAnnouncer;
    private readonly _rangeService;
    private readonly _rangeOptions;
    /** Determine if we are in range selection mode */
    get _isRangeMode(): boolean;
    /** Determine if this picker is the start picker */
    get _isRangeStart(): boolean;
    /** Determine if this picker is the end picker */
    get _isRangeEnd(): boolean;
    get _rangeStart(): Date | null;
    get _rangeEnd(): Date | null;
    private readonly _onDestroy;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * Navigate to the previous page of dates
     */
    previous(): void;
    /**
     * Navigate to the next page of dates
     */
    next(): void;
    /**
     * Select a particular date
     * @param date the date to select
     */
    select(date: Date): void;
    trackWeekByFn(index: number): number;
    trackDayByFn(_index: number, item: DayViewItem): string;
    focusDate(item: DayViewItem, dayOffset: number): void;
    getTabbable(item: DayViewItem): boolean;
    getDisabled(date: Date): boolean;
    isRangeStartDate(date: Date): boolean;
    isRangeEndDate(date: Date): boolean;
    isWithinRange(date: Date): boolean;
    isDateHovered(date: Date): boolean;
    isItemActive(date: Date, isActive: boolean): boolean;
    onRangeMouseEnter(date: Date): void;
    onRangeMouseLeave(date: Date): void;
    /** Announce the date when we focus on a date */
    announceRangeMode(): void;
    /** Determine if we should focus a date */
    shouldFocus(item: DayViewItem): boolean;
    /** Update the viewport when the range changes to ensure focus is present on a valid item */
    private onRangeChange;
    static ɵfac: i0.ɵɵFactoryDeclaration<DayViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DayViewComponent, "ux-date-time-picker-day-view", never, {}, {}, never, never, true, never>;
}

declare class MonthViewService implements OnDestroy {
    private readonly _datepicker;
    grid$: BehaviorSubject<MonthViewItem[][]>;
    focused$: BehaviorSubject<FocusedMonthItem>;
    private readonly _subscription;
    constructor();
    ngOnDestroy(): void;
    setFocus(month: number, year: number): void;
    private createMonthGrid;
    static ɵfac: i0.ɵɵFactoryDeclaration<MonthViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MonthViewService>;
}
interface MonthViewItem {
    name: string;
    month: number;
    year: number;
    isCurrentMonth: boolean;
    isActiveMonth: boolean;
}
interface FocusedMonthItem {
    month: number;
    year: number;
}

declare class MonthViewComponent implements AfterViewInit, OnDestroy {
    readonly monthService: MonthViewService;
    private readonly _datePicker;
    private readonly _liveAnnouncer;
    private readonly _changeDetector;
    private readonly _rangeService;
    private readonly _rangeOptions;
    /** Determine if we are in range selection mode */
    get _isRangeMode(): boolean;
    /** Determine if this picker is the start picker */
    get _isRangeStart(): boolean;
    /** Determine if this picker is the end picker */
    get _isRangeEnd(): boolean;
    get _rangeStart(): Date | null;
    get _rangeEnd(): Date | null;
    get _minMonth(): Date | null;
    get _maxMonth(): Date | null;
    private readonly _onDestroy;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /** Get the disabled state of a month */
    getDisabled(item: MonthViewItem | FocusedMonthItem): boolean;
    /**
     * Go to the previous year
     */
    previous(): void;
    /**
     * Go to the next year
     */
    next(): void;
    /**
     * Select a month in the calendar
     * @param month the index of the month to select
     */
    select(month: number): void;
    focusMonth(item: MonthViewItem, monthOffset: number): void;
    trackRowByFn(index: number): number;
    trackMonthByFn(_index: number, item: MonthViewItem): string;
    getTabbable(item: MonthViewItem): boolean;
    /** Announce the date when we focus on a date */
    announceRangeMode(): void;
    shouldFocus(item: MonthViewItem): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<MonthViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MonthViewComponent, "ux-date-time-picker-month-view", never, {}, {}, never, never, true, never>;
}

declare class YearViewService implements OnDestroy {
    private readonly _datepicker;
    grid$: BehaviorSubject<YearViewItem[][]>;
    focused$: BehaviorSubject<number>;
    private _year;
    private readonly _subscription;
    constructor();
    ngOnDestroy(): void;
    setFocus(year: number): void;
    goToPreviousDecade(): void;
    goToNextDecade(): void;
    private createYearGrid;
    /**
     * Get the years in the current decade to display
     */
    private getDecade;
    static ɵfac: i0.ɵɵFactoryDeclaration<YearViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<YearViewService>;
}
interface YearViewItem {
    year: number;
    isCurrentYear: boolean;
    isActiveYear: boolean;
}

declare class YearViewComponent implements AfterViewInit, OnDestroy {
    readonly yearService: YearViewService;
    private readonly _datePicker;
    private readonly _liveAnnouncer;
    private readonly _changeDetector;
    private readonly _rangeService;
    private readonly _rangeOptions;
    /** Determine if we are in range selection mode */
    get _isRangeMode(): boolean;
    /** Determine if this picker is the start picker */
    get _isRangeStart(): boolean;
    /** Determine if this picker is the end picker */
    get _isRangeEnd(): boolean;
    get _rangeStart(): Date | null;
    get _rangeEnd(): Date | null;
    get _minYear(): Date | null;
    get _maxYear(): Date | null;
    private readonly _onDestroy;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    select(year: number): void;
    /** Get the disabled state of a month */
    getDisabled(item: YearViewItem): boolean;
    focusYear(item: YearViewItem, yearOffset: number): void;
    trackRowByFn(index: number): number;
    trackYearByFn(_index: number, item: YearViewItem): number;
    getTabbable(item: YearViewItem): boolean;
    /** Announce the date when we focus on a date */
    announceRangeMode(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<YearViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<YearViewComponent, "ux-date-time-picker-year-view", never, {}, {}, never, never, true, never>;
}

declare class TimeViewComponent implements OnInit, OnDestroy {
    readonly datepicker: DateTimePickerService;
    private readonly _changeDetector;
    private readonly _rangeService;
    private readonly _rangeOptions;
    /** Dont bind directly to the selected date as if it's null we can end up in 1970! */
    value: Date;
    /** Earliest time permitted on the time picker. */
    min: Date;
    /** Latest time permitted on the time picker. */
    max: Date;
    /** Determine if we are in range selection mode */
    get _isRangeMode(): boolean;
    /** Determine if this picker is the start picker */
    get _isRangeStart(): boolean;
    /** Determine if this picker is the end picker */
    get _isRangeEnd(): boolean;
    get _rangeStart(): Date | null;
    get _rangeEnd(): Date | null;
    /** Emit when the timezone changes. */
    timezoneChange: EventEmitter<DateTimePickerTimezone>;
    private readonly _onDestroy;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    onTimeChange(time: Date): void;
    selectTimezone(name: string): void;
    incrementTimezone(): void;
    decrementTimezone(): void;
    onFocusWithin(): void;
    onFocusOut(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimeViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimeViewComponent, "ux-date-time-picker-time-view", never, {}, { "timezoneChange": "timezoneChange"; }, never, never, true, never>;
}

declare class WeekDaySortPipe implements PipeTransform {
    transform(value: string[], startOfWeek: WeekDay): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<WeekDaySortPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<WeekDaySortPipe, "weekDaySort", true>;
}

declare class DateTimePickerModule {
    static forRoot(): ModuleWithProviders<DateTimePickerModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateTimePickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DateTimePickerModule, never, [typeof i1.A11yModule, typeof AccessibilityModule, typeof i2.CommonModule, typeof FocusIfModule, typeof i3$2.FormsModule, typeof IconModule, typeof SpinButtonModule, typeof TimePickerModule, typeof DateTimePickerComponent, typeof HeaderComponent, typeof DayViewComponent, typeof MonthViewComponent, typeof YearViewComponent, typeof TimeViewComponent, typeof WeekDaySortPipe], [typeof DateTimePickerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DateTimePickerModule>;
}

declare class DateFormatterPipe implements PipeTransform {
    private readonly _locale;
    transform(value: Date, formatter: string | DateFormatter): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateFormatterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DateFormatterPipe, "formatDate", true>;
}

declare class DateFormatterPipeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DateFormatterPipeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DateFormatterPipeModule, never, [typeof DateFormatterPipe], [typeof DateFormatterPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DateFormatterPipeModule>;
}

declare class DateRangePickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DateRangePickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DateRangePickerModule, never, [typeof i2.CommonModule, typeof DateTimePickerModule, typeof IconModule, typeof DateFormatterPipeModule, typeof DateRangePickerComponent, typeof DateRangePickerDirective], [typeof DateRangePickerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DateRangePickerModule>;
}

declare class DateTimePickerConfig {
    showDate: boolean;
    showTime: boolean;
    showTimezone: boolean;
    showSeconds: boolean;
    showMeridian: boolean;
    showSpinners: boolean;
    showNowBtn: boolean;
    weekdays: string[];
    nowBtnText: string;
    timezones: DateTimePickerTimezone[];
    months: string[];
    monthsShort: string[];
    meridians: string[];
    min: Date;
    max: Date;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateTimePickerConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DateTimePickerConfig>;
}

declare class EboxComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<EboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EboxComponent, "ux-ebox", never, {}, {}, never, ["ux-ebox-header", "ux-ebox-content"], true, never>;
}
declare class EboxHeaderDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<EboxHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EboxHeaderDirective, "ux-ebox-header", never, {}, {}, never, never, true, never>;
}
declare class EboxContentDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<EboxContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EboxContentDirective, "ux-ebox-content", never, {}, {}, never, never, true, never>;
}

declare class EboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EboxModule, never, [typeof EboxComponent, typeof EboxContentDirective, typeof EboxHeaderDirective], [typeof EboxComponent, typeof EboxContentDirective, typeof EboxHeaderDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EboxModule>;
}

declare class FacetHeaderComponent implements OnDestroy {
    readonly focusIndicatorService: FocusIndicatorService;
    readonly elementRef: ElementRef<any>;
    /** Defines the text to display in the header. */
    header: string;
    /** Defines whether or not clicking on the header will toggle the expanded state. */
    canExpand: boolean;
    /** Can be used to set the initial expanded state. */
    expanded: boolean;
    /** If two-way binding is used it will be updated when the expanded state changes. */
    expandedChange: EventEmitter<boolean>;
    /** Store Focus Indicator instance */
    private readonly _focusIndicator;
    constructor();
    ngOnDestroy(): void;
    toggleExpand(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FacetHeaderComponent, "ux-facet-header", never, { "header": { "alias": "header"; "required": false; }; "canExpand": { "alias": "canExpand"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "expandedChange": "expandedChange"; }, never, never, true, never>;
}

declare class Facet {
    title: string;
    data: any;
    count?: number;
    disabled: boolean;
    id?: string | number;
    constructor(title: string, data?: any, count?: number, disabled?: boolean, id?: string | number);
}

declare class FacetSelect {
    facet: Facet;
    constructor(facet: Facet);
}
declare class FacetDeselect {
    facet: Facet;
    constructor(facet: Facet);
}
declare class FacetDeselectAll {
}
type FacetEvent = FacetSelect | FacetDeselect | FacetDeselectAll;

declare class FacetService {
    /** The list of active facets */
    facets$: BehaviorSubject<Facet[]>;
    /** Emit all the events when they occur */
    events$: Subject<FacetEvent>;
    select(facet: Facet): void;
    deselect(facet: Facet): void;
    deselectAll(): void;
    toggle(facet: Facet): void;
    isSelected(facet: Facet): boolean;
    private isFacetMatch;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FacetService>;
}

declare class FacetCheckListItemComponent implements FocusableOption {
    id: string;
    facet: Facet;
    selected: boolean;
    tabbable: boolean;
    simplified: boolean;
    selectedChange: EventEmitter<Facet>;
    itemFocus: EventEmitter<void>;
    itemBlur: EventEmitter<void>;
    option: ElementRef;
    get disabled(): boolean;
    getLabel(): string;
    focus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetCheckListItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FacetCheckListItemComponent, "ux-facet-check-list-item", never, { "id": { "alias": "id"; "required": false; }; "facet": { "alias": "facet"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "tabbable": { "alias": "tabbable"; "required": false; }; "simplified": { "alias": "simplified"; "required": false; }; }, { "selectedChange": "selectedChange"; "itemFocus": "itemFocus"; "itemBlur": "itemBlur"; }, never, never, true, never>;
}

declare class FacetCheckListComponent implements AfterViewInit, OnDestroy {
    readonly facetService: FacetService;
    id: string;
    /** This will allow you to define an initial set of selected facets. */
    set selected(selection: Facet[]);
    /** Defines the complete list of facets that can be selected. */
    facets: Facet[];
    /** Defines the text displayed at the top of the Facet Check List. */
    header: string;
    /** If `false` the list will grow to display all possible facets. If `true` a scrollbar will appear to prevent the list from growing too large. */
    scrollbar: boolean;
    /** Defines whether or not the checkboxes will appear in simplified form. */
    simplified: boolean;
    /** Defines whether or not the Facet Check List should be initially expanded or not. */
    expanded: boolean;
    /**
     * This will be triggered when a facet is selected, deselected or all facets are deselected.
     * The event will be an instance of either `FacetSelect`, `FacetDeselect` or `FacetDeselectAll` and
     * will contain the facet being selected or deselected in a `facet` property (deselect all will not contain affected facets).
     */
    events: Subject<FacetEvent>;
    /** If two-way binding is used this array will get updated any time the selected facets change. */
    selectedChange: EventEmitter<Facet[]>;
    options: QueryList<FacetCheckListItemComponent>;
    isFocused: boolean;
    activeIndex: number;
    private readonly _onDestroy;
    private _focusKeyManager;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    onFocus(index: number): void;
    onKeydown(event: KeyboardEvent): void;
    toggleFacet(index: number, facet: Facet): void;
    private getSelectedFacets;
    private isOwnFacet;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetCheckListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FacetCheckListComponent, "ux-facet-check-list", never, { "id": { "alias": "id"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "facets": { "alias": "facets"; "required": false; }; "header": { "alias": "header"; "required": false; }; "scrollbar": { "alias": "scrollbar"; "required": false; }; "simplified": { "alias": "simplified"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "events": "events"; "selectedChange": "selectedChange"; }, never, never, true, never>;
}

declare class FacetClearButtonDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetClearButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FacetClearButtonDirective, "[uxFacetClearButton]", never, {}, {}, never, never, true, never>;
}

declare class ReorderableHandleDirective extends CdkDragHandle {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReorderableHandleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ReorderableHandleDirective, "[uxReorderableHandle]", never, {}, {}, never, never, true, never>;
}

declare class ReorderableModelDirective<T> extends CdkDrag implements OnInit, OnDestroy {
    set uxReorderableModel(model: T);
    /** Apply the dragula preview class to avoid backwards compatibility issues */
    previewClass: string;
    /** Preserve the column widths */
    private readonly _widths;
    /** Unsubscribe on destroy */
    private readonly _destroy$;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /**
     * When table elements are being dragged they are hoisted to the document level
     * when dragged they lose the sizing and spacing provided when they are used inside a table.
     *
     * This function will capture the styles so we can inline them to preseve the styling.
     */
    private captureTableCellStyles;
    private setTableCellWidths;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReorderableModelDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ReorderableModelDirective<any>, "[uxReorderableModel]", never, { "uxReorderableModel": { "alias": "uxReorderableModel"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ReorderableDirective<T> extends CdkDropList<T> implements OnInit, OnDestroy {
    /**
     * This property can be used to provide the `uxReorderable` directive with a dataset that represents the items that can be reordered.
     * This can used as a two way binding which will ensure the dataset always reflects the current order of items in the list.
     * Each list item should have a `uxReorderableModel` directive applied, with a value indicating which item in the dataset it represents.
     *
     * If the list is generated using `ngFor` this property should be bound to the same dataset.
     * If there is no dataset representing the items then this property is not required.
     */
    reorderableModel: Array<T>;
    /**
     * The name of the reorderable group which this container belongs to `uxReorderable` elements which belong to
     * the same group can have items dragged between them. Only required if multiple drop containers are being created.
     */
    set reorderableGroup(group: string);
    get reorderableGroup(): string;
    private _reorderableGroup;
    /** Determines if reordering is disabled. */
    set reorderingDisabled(isDisabled: boolean);
    /**
     * This event will be triggered when the order changes and will contain an updated dataset containing the items
     * in their current order. This should be used when the list of items is generated using ngFor to ensure the
     * data remains in the same order for both the `uxReorderable` and `ngFor` directives.
     */
    reorderableModelChange: EventEmitter<T[]>;
    /** This event is triggered when a user begins dragging an item. The event will contain the element being moved. */
    reorderStart: EventEmitter<ReorderEvent<T>>;
    /** This event is triggered when the item being dragged is returned to the same location as it began. The event will contain the element that was being moved. */
    reorderCancel: EventEmitter<ReorderEvent<T>>;
    /** This event is triggered when a user has relocated an item. The event will contain the element that was moved. */
    reorderEnd: EventEmitter<ReorderEvent<T>>;
    /** Store all the group ids so we can identify which lists can interact */
    private static readonly _groups$;
    private readonly _destroy$;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReorderableDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ReorderableDirective<any>, "[uxReorderable]", never, { "reorderableModel": { "alias": "reorderableModel"; "required": false; }; "reorderableGroup": { "alias": "reorderableGroup"; "required": false; }; "reorderingDisabled": { "alias": "reorderingDisabled"; "required": false; }; }, { "reorderableModelChange": "reorderableModelChange"; "reorderStart": "reorderStart"; "reorderCancel": "reorderCancel"; "reorderEnd": "reorderEnd"; }, never, never, true, never>;
}
interface ReorderEvent<T = unknown> {
    element: Element;
    model: T;
}

declare class ReorderableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReorderableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReorderableModule, never, [typeof i2.CommonModule, typeof i2$2.DragDropModule, typeof ReorderableDirective, typeof ReorderableHandleDirective, typeof ReorderableModelDirective], [typeof ReorderableDirective, typeof ReorderableHandleDirective, typeof ReorderableModelDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReorderableModule>;
}

declare class FacetContainerComponent implements OnDestroy, AfterViewInit {
    readonly facetService: FacetService;
    private readonly _announcer;
    /** Defines the text displayed at the top of the Facet Container. */
    header: string;
    /** Defines the text to display in the tooltip when hovering over the clear all button. */
    clearTooltip: string;
    /** Defines the text to display when there are no selected facets. */
    emptyText: string;
    /** Determines if the facets can be reordered. */
    facetsReorderable: boolean;
    /** Allows a predefined set of Facets to be displayed. */
    set facets(facets: Facet[]);
    get facets(): Facet[];
    /** Defines the aria-label for the clear all button. */
    clearAriaLabel: string;
    /** Defines the aria-label for the deselect facet button.. */
    deselectFacetAriaLabel: string;
    /** If using two-way binding this array will update when the selected facets change. */
    facetsChange: EventEmitter<Facet[]>;
    /**
     * This will be triggered when a facet is selected, deselected or all facets are deselected.
     * The event will be an instance of either `FacetSelect`, `FacetDeselect` or `FacetDeselectAll` and
     * will contain the facet being selected or deselected in a `facet` property
     * (deselect all will not contain affected facets). */
    events: EventEmitter<FacetEvent>;
    /** Allow a custom clear button */
    clearButton: TemplateRef<FacetClearButtonDirective>;
    placeholder: CdkDropList;
    private target;
    private targetIndex;
    private source;
    private sourceIndex;
    private dragRef;
    private readonly _onDestroy;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    onDropListDropped(): void;
    onDropListEntered({ item, container }: CdkDragEnter): void;
    selectFacet(facet: Facet): void;
    deselectFacet(facet: Facet, tag?: HTMLElement): void;
    deselectAllFacets(): void;
    trackBy(_index: number, facet: Facet): string | number;
    shiftRight(facet: Facet, element: HTMLElement): void;
    shiftLeft(facet: Facet, element: HTMLElement): void;
    private shiftFacet;
    private triggerEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FacetContainerComponent, "ux-facet-container", never, { "header": { "alias": "header"; "required": false; }; "clearTooltip": { "alias": "clearTooltip"; "required": false; }; "emptyText": { "alias": "emptyText"; "required": false; }; "facetsReorderable": { "alias": "facetsReorderable"; "required": false; }; "facets": { "alias": "facets"; "required": false; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; }; "deselectFacetAriaLabel": { "alias": "deselectFacetAriaLabel"; "required": false; }; }, { "facetsChange": "facetsChange"; "events": "events"; }, ["clearButton"], ["*"], true, never>;
}
interface FacetReorderEvent extends ReorderEvent {
    index: number;
}

declare class TypeaheadOptionEvent<T = any> {
    option: T;
    origin?: FocusOrigin;
    constructor(option: T, origin?: FocusOrigin);
}

declare class InfiniteScrollDirective<T = unknown> implements OnInit, AfterContentInit, OnChanges, OnDestroy {
    private readonly _element;
    load: InfiniteScrollLoadFunction<T>;
    _collection: T[];
    get collection(): T[];
    set collection(value: T[]);
    set scrollElement(element: ElementRef | HTMLElement);
    enabled: boolean;
    filter: any;
    loadOnInit: boolean;
    loadOnScroll: boolean;
    pageSize: number;
    collectionChange: EventEmitter<T[]>;
    loadingEvent: EventEmitter<InfiniteScrollLoadingEvent<any>>;
    loadedEvent: EventEmitter<InfiniteScrollLoadedEvent<any, any>>;
    loadErrorEvent: EventEmitter<InfiniteScrollLoadErrorEvent<any>>;
    private readonly _loadButtonQuery;
    private readonly _loadingIndicatorQuery;
    private _pages;
    private _nextPageNum;
    private _domObserver;
    private _scrollEventSub;
    private readonly _updateRequests;
    private readonly _isLoading;
    private readonly _isExhausted;
    private readonly _loadButtonEnabled;
    private readonly _canLoadManually;
    private _scrollElement;
    private _subscriptions;
    private _loadButtonSubscriptions;
    private readonly _onDestroy;
    constructor();
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    /**
     * Request an additional page of data.
     */
    loadNextPage(): void;
    /**
     * Request a check for whether an additional page of data is required. This is throttled.
     */
    check(): void;
    /**
     * Clear the collection. Future requests will load from page 0.
     */
    reset(clearSubscriptions?: boolean): void;
    /**
     * Reload the data without clearing the view.
     */
    reload(): void;
    /**
     * Reload the data in a specific page without clearing the view.
     * @param pageNum Page number
     */
    reloadPage(pageNum: number): void;
    /** A filter value of null or undefined should be considered the same as an empty string */
    private coerceFilter;
    /**
     * Attach scroll event handler and DOM observer.
     */
    private attachEventHandlers;
    /**
     * Detach scroll event handler and DOM observer.
     */
    private detachEventHandlers;
    /**
     * Remove any existing event subscriptions for the load button `loading` event, then attach
     * subscriptions
     * for any in the query.
     */
    private attachLoadButtonEvents;
    /**
     * Conditionally loads a page into the collection based on directive state and request parameters.
     */
    private doRequest;
    /**
     * Returns true if the request should be fulfilled.
     */
    private needsData;
    /**
     * Updates state for the beginning of a load. Returns false if the `loading` event was cancelled.
     */
    private beginLoading;
    private setPageItems;
    /**
     * Updates state from a successful load. Raises the `loaded` event.
     */
    private endLoading;
    /**
     * Updates state from a failed load. Raises the `loadError` event.
     */
    private endLoadingWithError;
    static ɵfac: i0.ɵɵFactoryDeclaration<InfiniteScrollDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InfiniteScrollDirective<any>, "[uxInfiniteScroll]", ["uxInfiniteScroll"], { "load": { "alias": "uxInfiniteScroll"; "required": false; }; "_collection": { "alias": "collection"; "required": false; }; "scrollElement": { "alias": "scrollElement"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; "loadOnInit": { "alias": "loadOnInit"; "required": false; }; "loadOnScroll": { "alias": "loadOnScroll"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, { "collectionChange": "collectionChange"; "loadingEvent": "loading"; "loadedEvent": "loaded"; "loadErrorEvent": "loadError"; }, ["_loadButtonQuery", "_loadingIndicatorQuery"], never, true, never>;
}
type InfiniteScrollLoadFunction<T = any, S = any> = (pageNum: number, pageSize: number, filter: S) => T[] | Promise<T[]>;
/**
 * Event raised before the `loading` function is called.
 */
declare class InfiniteScrollLoadingEvent<S = any> {
    /**
     * The index of the requested page, starting from 0.
     */
    pageNumber: number;
    /**
     * The number of items requested.
     */
    pageSize: number;
    /**
     * The filter details as provided via the `filter` binding.
     */
    filter: S;
    private _defaultPrevented;
    constructor(
    /**
     * The index of the requested page, starting from 0.
     */
    pageNumber: number, 
    /**
     * The number of items requested.
     */
    pageSize: number, 
    /**
     * The filter details as provided via the `filter` binding.
     */
    filter: S);
    /**
     * Prevents the default behaviour of the `loading` event (loading function will not be called).
     */
    preventDefault(): void;
    defaultPrevented(): boolean;
}
/**
 * Event raised when the loading function result has been resolved and added to the collection.
 */
declare class InfiniteScrollLoadedEvent<T = any, S = any> {
    /**
     * The index of the requested page, starting from 0.
     */
    pageNumber: number;
    /**
     * The number of items requested.
     */
    pageSize: number;
    /**
     * The filter details as provided via the `filter` binding.
     */
    filter: S;
    /**
     * The result of the promise returned from the loading function.
     */
    data: T[];
    /**
     * True if the data is considered exhausted (number of items returned less than `pageSize`).
     */
    exhausted: boolean;
    constructor(
    /**
     * The index of the requested page, starting from 0.
     */
    pageNumber: number, 
    /**
     * The number of items requested.
     */
    pageSize: number, 
    /**
     * The filter details as provided via the `filter` binding.
     */
    filter: S, 
    /**
     * The result of the promise returned from the loading function.
     */
    data: T[], 
    /**
     * True if the data is considered exhausted (number of items returned less than `pageSize`).
     */
    exhausted: boolean);
}
/**
 * Event raised if the loading function returns a rejected promise.
 */
declare class InfiniteScrollLoadErrorEvent<S = any> {
    /**
     * The index of the requested page, starting from 0.
     */
    pageNumber: number;
    /**
     * The number of items requested.
     */
    pageSize: number;
    /**
     * The filter details as provided via the `filter` binding.
     */
    filter: S;
    /**
     * The object provided when rejecting the promise.
     */
    error: any;
    constructor(
    /**
     * The index of the requested page, starting from 0.
     */
    pageNumber: number, 
    /**
     * The number of items requested.
     */
    pageSize: number, 
    /**
     * The filter details as provided via the `filter` binding.
     */
    filter: S, 
    /**
     * The object provided when rejecting the promise.
     */
    error: any);
}

declare class InfiniteScrollLoadButtonDirective {
    private readonly _template;
    private readonly _viewContainer;
    private readonly _renderer;
    get visible(): boolean;
    set visible(value: boolean);
    loading: Observable<Event>;
    private _visible;
    private readonly _load;
    constructor();
    private onClick;
    static ɵfac: i0.ɵɵFactoryDeclaration<InfiniteScrollLoadButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InfiniteScrollLoadButtonDirective, "[uxInfiniteScrollLoadButton]", never, { "visible": { "alias": "uxInfiniteScrollLoadButton"; "required": false; }; }, { "loading": "loading"; }, never, never, true, never>;
}

declare class InfiniteScrollLoadingDirective {
    private readonly _templateRef;
    private readonly _viewContainer;
    get visible(): boolean | string;
    set visible(value: boolean | string);
    private _visible;
    static ɵfac: i0.ɵɵFactoryDeclaration<InfiniteScrollLoadingDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InfiniteScrollLoadingDirective, "[uxInfiniteScrollLoading]", never, { "visible": { "alias": "uxInfiniteScrollLoading"; "required": false; }; }, {}, never, never, true, never>;
}

declare class InfiniteScrollModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<InfiniteScrollModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<InfiniteScrollModule, never, [typeof InfiniteScrollDirective, typeof InfiniteScrollLoadButtonDirective, typeof InfiniteScrollLoadingDirective], [typeof InfiniteScrollDirective, typeof InfiniteScrollLoadButtonDirective, typeof InfiniteScrollLoadingDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<InfiniteScrollModule>;
}

declare class PopoverOrientationService {
    private readonly _resizeService;
    private readonly _viewportRuler;
    createPopoverOrientationListener(element: ElementRef | HTMLElement, parentElement?: ElementRef | HTMLElement): PopoverOrientationListener;
    static ɵfac: i0.ɵɵFactoryDeclaration<PopoverOrientationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PopoverOrientationService>;
}
declare class PopoverOrientationListener {
    private readonly _element;
    private readonly _elementParent;
    private readonly _resizeService;
    private readonly _viewportRuler;
    /** Allow subscribing to state changes */
    orientation$: BehaviorSubject<PopoverOrientation>;
    /** Max value the height of the dropdown can be */
    maxHeight: number;
    /** Store the last known position and size */
    private _rect;
    private readonly _onDestroy;
    constructor(_element: HTMLElement, _elementParent: HTMLElement, _resizeService: ResizeService, _viewportRuler: ViewportRuler);
    destroy(): void;
    private onScrollOrResize;
}
declare const enum PopoverOrientation {
    Up = 0,
    Down = 1
}

/**
 * The API available to option templates.
 */
interface TypeaheadOptionApi<T = unknown> {
    /**
     * Returns the unique key value of the given option.
     */
    getKey(option: T): string;
    /**
     * Returns the display value of the given option.
     */
    getDisplay(option: T): string;
    /**
     * Returns the display value of the given option with HTML markup added to highlight the part which matches the current filter value. Override the ux-filter-match class in CSS to modify the default appearance.
     */
    getDisplayHtml(option: T): string;
    /**
     * Returns the disabled state of a given option.
     */
    getDisabled(option: T): boolean;
}

interface TypeaheadOptionContext<T> {
    option: T;
    api: TypeaheadOptionApi<T>;
}

interface TypeaheadVisibleOption<T = unknown> {
    value: T;
    key: string;
    isRecentOption?: boolean;
}

declare class TypeaheadComponent<T = any> implements OnChanges, OnDestroy {
    readonly typeaheadElement: ElementRef<any>;
    readonly popoverOrientation: PopoverOrientationService;
    private readonly _changeDetector;
    private readonly _service;
    infiniteScroll: InfiniteScrollDirective;
    /** Define a unique id for the typeahead */
    id: string;
    /** Define the options or infinite load function */
    options: T[] | InfiniteScrollLoadFunction;
    /** Define the filter text */
    filter: string;
    /** Specify if the typeahead is open */
    get open(): boolean;
    set open(value: boolean);
    /** Extract the test to display from an option */
    display: ((option: T) => string) | string;
    /** Extract the key from an option */
    key: ((option: T) => string) | string;
    /** Specify which options are disabled */
    set disabledOptions(options: T | T[]);
    get disabledOptions(): T | T[];
    _disabledOptions: T[];
    /** Specify the drop direction */
    dropDirection: 'auto' | 'up' | 'down';
    /** Specify the max height of the dropdown */
    get maxHeight(): string;
    set maxHeight(maxHeight: string);
    /** Specify the aria multi selectable attribute value */
    multiselectable: boolean;
    /** Specify the aria label for the listbox */
    ariaLabel: string;
    /** Specify if the dropdown should appear when the filter appears */
    openOnFilterChange: boolean;
    /** Specify the page size */
    pageSize: number;
    /** Specify if we should select the first item by default */
    selectFirst: boolean;
    /** Specify if we should select an item on enter key press */
    selectOnEnter: boolean;
    /** Specify the loading state */
    loading: boolean;
    /** Specify a custom loading template */
    loadingTemplate: TemplateRef<void>;
    /** Specify a custom option template */
    optionTemplate: TemplateRef<TypeaheadOptionContext<T>>;
    /** Specify a custom template to display when there are no options */
    noOptionsTemplate: TemplateRef<void>;
    /** Specify the currently active item */
    set active(item: T);
    /**
     * An initial list of recently selected options, to be presented above the full list of options.
     * Bind an empty array to `recentOptions` to enable this feature without providing an initial set.
     */
    recentOptions: ReadonlyArray<T>;
    /** Maximum number of displayed recently selected options. */
    recentOptionsMaxCount: number;
    recentOptionsHeadingTemplate: TemplateRef<void>;
    optionsHeadingTemplate: TemplateRef<void>;
    /** Emit when the open state changes */
    openChange: EventEmitter<boolean>;
    /** Emit when an option is selected */
    optionSelected: EventEmitter<TypeaheadOptionEvent<T>>;
    /** Emit whenever a highlighted item changes */
    highlightedChange: EventEmitter<T>;
    /** Emit the highlighted element when it changes */
    highlightedElementChange: EventEmitter<HTMLElement>;
    /** Emits when recently selected options change.*/
    recentOptionsChange: EventEmitter<readonly T[]>;
    activeKey: string;
    clicking: boolean;
    hasBeenOpened: boolean;
    highlighted$: BehaviorSubject<TypeaheadVisibleOption<T>>;
    loadOptionsCallback: InfiniteScrollLoadFunction;
    visibleOptions$: BehaviorSubject<TypeaheadVisibleOption<T>[]>;
    visibleRecentOptions$: BehaviorSubject<TypeaheadVisibleOption<T>[]>;
    allVisibleOptions: TypeaheadVisibleOption<T>[];
    get highlighted(): T;
    /** Store the list of recent items */
    private _recentOptions;
    private readonly _onDestroy;
    private readonly _popoverOrientationListener;
    private _maxHeight;
    dropUp: boolean;
    optionApi: TypeaheadOptionApi<T>;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    mousedownHandler(event: MouseEvent, target: HTMLElement): void;
    mouseupHandler(): void;
    optionMousedownHandler(event: MouseEvent): void;
    optionClickHandler(_event: MouseEvent, option: TypeaheadVisibleOption<T>): void;
    /**
     * Returns the unique key value of the given option.
     */
    getKey(option: T): string;
    /**
     * Returns the display value of the given option.
     */
    getDisplay(option: T): string | undefined;
    /**
     * Returns the display value of the given option with HTML markup added to highlight the part which matches the current filter value.
     * @param option
     */
    getDisplayHtml(option: T): string;
    /**
     * Returns true if the infinite scroll component should load
     */
    isInfiniteScroll(): boolean;
    /**
     * Selects the given option, emitting the optionSelected event and closing the dropdown.
     */
    select(option: TypeaheadVisibleOption<T>, origin?: FocusOrigin): void;
    addToRecentOptions(value: T): void;
    /**
     * Returns true if the given option is part of the disabledOptions array.
     */
    isDisabled(option: T): boolean;
    /**
     * Set the given option as the current highlighted option, available in the highlightedOption parameter.
     */
    highlight(option: TypeaheadVisibleOption<T>): void;
    /**
     * Increment or decrement the highlighted option in the list. Disabled options are skipped.
     * @param d Value to be added to the index of the highlighted option, i.e. -1 to move backwards, +1 to move forwards.
     */
    moveHighlight(d: -1 | 1): T;
    selectHighlighted(): void;
    /**
     * Set up the options before the dropdown is displayed.
     */
    initOptions(): void;
    /**
     * Display the first item as highlighted when there are several pages
     */
    onLoadedHighlight(event: InfiniteScrollLoadedEvent): void;
    /**
     * Update the visibleOptions and visibleRecentOptions arrays with the current filter.
     */
    updateOptions(): void;
    /**
     * Convert a set of raw options into a filtered list of `TypeaheadVisibleOption` objects.
     * @param options Set of raw options
     * @param filter The filter expression
     * @param isRecentOptions Whether `options` is a set of recent options
     */
    private getVisibleOptions;
    /**
     * Return the index of the given option in the allVisibleOptions array.
     * Returns -1 if the option is not currently visible.
     */
    private indexOfVisibleOption;
    static ɵfac: i0.ɵɵFactoryDeclaration<TypeaheadComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TypeaheadComponent<any>, "ux-typeahead", never, { "id": { "alias": "id"; "required": false; }; "options": { "alias": "options"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; "open": { "alias": "open"; "required": false; }; "display": { "alias": "display"; "required": false; }; "key": { "alias": "key"; "required": false; }; "disabledOptions": { "alias": "disabledOptions"; "required": false; }; "dropDirection": { "alias": "dropDirection"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "multiselectable": { "alias": "multiselectable"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "openOnFilterChange": { "alias": "openOnFilterChange"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "selectFirst": { "alias": "selectFirst"; "required": false; }; "selectOnEnter": { "alias": "selectOnEnter"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "loadingTemplate": { "alias": "loadingTemplate"; "required": false; }; "optionTemplate": { "alias": "optionTemplate"; "required": false; }; "noOptionsTemplate": { "alias": "noOptionsTemplate"; "required": false; }; "active": { "alias": "active"; "required": false; }; "recentOptions": { "alias": "recentOptions"; "required": false; }; "recentOptionsMaxCount": { "alias": "recentOptionsMaxCount"; "required": false; }; "recentOptionsHeadingTemplate": { "alias": "recentOptionsHeadingTemplate"; "required": false; }; "optionsHeadingTemplate": { "alias": "optionsHeadingTemplate"; "required": false; }; }, { "openChange": "openChange"; "optionSelected": "optionSelected"; "highlightedChange": "highlightedChange"; "highlightedElementChange": "highlightedElementChange"; "recentOptionsChange": "recentOptionsChange"; }, never, never, true, never>;
}

declare class TypeaheadKeyService<T = unknown> {
    handleKey(event: KeyboardEvent, typeahead: TypeaheadComponent<T>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TypeaheadKeyService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TypeaheadKeyService<any>>;
}

declare class ScrollIntoViewIfDirective implements OnChanges {
    private readonly _element;
    private readonly _scrollIntoViewService;
    condition: boolean;
    scrollParent: HTMLElement;
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollIntoViewIfDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ScrollIntoViewIfDirective, "[uxScrollIntoViewIf]", never, { "condition": { "alias": "uxScrollIntoViewIf"; "required": false; }; "scrollParent": { "alias": "scrollParent"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ScrollIntoViewDirective implements AfterViewInit {
    readonly _elementRef: ElementRef<any>;
    /** Allow a condition around whether or not this should scroll into view */
    uxScrollIntoView: boolean;
    /** Allow user to provide the browser supported options */
    scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollIntoViewDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ScrollIntoViewDirective, "[uxScrollIntoView]", never, { "uxScrollIntoView": { "alias": "uxScrollIntoView"; "required": false; }; "scrollIntoViewOptions": { "alias": "scrollIntoViewOptions"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ScrollModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ScrollModule, never, [typeof ScrollIntoViewIfDirective, typeof ScrollIntoViewDirective], [typeof ScrollIntoViewIfDirective, typeof ScrollIntoViewDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ScrollModule>;
}

declare class SafeInnerHtmlDirective {
    private readonly _sanitizer;
    protected safeHtml?: SafeHtml;
    set safeInnerHtml(value: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<SafeInnerHtmlDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SafeInnerHtmlDirective, "[uxSafeInnerHtml]", never, { "safeInnerHtml": { "alias": "uxSafeInnerHtml"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TypeaheadHighlightDirective {
    private readonly _service;
    private readonly _elementRef;
    set highlight(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<TypeaheadHighlightDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TypeaheadHighlightDirective, "[uxTypeaheadHighlight]", never, { "highlight": { "alias": "uxTypeaheadHighlight"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TypeaheadOptionsListComponent<T> {
    id: string;
    startIndex: number;
    options: TypeaheadVisibleOption<T>[];
    highlighted: TypeaheadVisibleOption<T>;
    activeKey: string;
    disabledOptions: T[];
    isMultiselectable: boolean;
    optionTemplate: TemplateRef<TypeaheadOptionContext<T>>;
    optionApi: TypeaheadOptionApi;
    typeaheadElement: ElementRef<HTMLElement>;
    ariaLabel: string;
    optionMouseover: EventEmitter<TypeaheadOptionDomEvent<T, MouseEvent>>;
    optionMousedown: EventEmitter<TypeaheadOptionDomEvent<T, MouseEvent>>;
    optionClick: EventEmitter<TypeaheadOptionDomEvent<T, MouseEvent>>;
    trackByFn(_: number, option: TypeaheadVisibleOption<T>): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TypeaheadOptionsListComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TypeaheadOptionsListComponent<any>, "ux-typeahead-options-list", never, { "id": { "alias": "id"; "required": false; }; "startIndex": { "alias": "startIndex"; "required": false; }; "options": { "alias": "options"; "required": false; }; "highlighted": { "alias": "highlighted"; "required": false; }; "activeKey": { "alias": "activeKey"; "required": false; }; "disabledOptions": { "alias": "disabledOptions"; "required": false; }; "isMultiselectable": { "alias": "isMultiselectable"; "required": false; }; "optionTemplate": { "alias": "optionTemplate"; "required": false; }; "optionApi": { "alias": "optionApi"; "required": false; }; "typeaheadElement": { "alias": "typeaheadElement"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, { "optionMouseover": "optionMouseover"; "optionMousedown": "optionMousedown"; "optionClick": "optionClick"; }, never, never, true, never>;
}
interface TypeaheadOptionDomEvent<T, E extends Event> {
    option: TypeaheadVisibleOption<T>;
    event: E;
}

declare class TypeaheadModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TypeaheadModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TypeaheadModule, never, [typeof i2.CommonModule, typeof InfiniteScrollModule, typeof ResizeModule, typeof ScrollModule, typeof SafeInnerHtmlDirective, typeof TypeaheadComponent, typeof TypeaheadHighlightDirective, typeof TypeaheadOptionsListComponent], [typeof TypeaheadComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TypeaheadModule>;
}

declare class FacetTypeaheadListItemComponent implements FocusableOption {
    facet: Facet;
    selected: boolean;
    simplified: boolean;
    tabbable: boolean;
    itemFocus: EventEmitter<void>;
    selectedChange: EventEmitter<Facet>;
    option: ElementRef;
    get disabled(): boolean;
    getLabel(): string;
    focus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetTypeaheadListItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FacetTypeaheadListItemComponent, "ux-facet-typeahead-list-item", never, { "facet": { "alias": "facet"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "simplified": { "alias": "simplified"; "required": false; }; "tabbable": { "alias": "tabbable"; "required": false; }; }, { "itemFocus": "itemFocus"; "selectedChange": "selectedChange"; }, never, never, true, never>;
}

declare class FacetTypeaheadListComponent implements AfterViewInit, OnInit, OnDestroy {
    readonly typeaheadKeyService: TypeaheadKeyService<any>;
    readonly facetService: FacetService;
    private readonly _announcer;
    /** This will allow you to define an initial set of selected facets. */
    set selected(selection: Facet[]);
    /** Defines the complete list of facets that can be selected. Alternatively an observable can be used to allow values to be fetched dynamically. */
    facets: Facet[] | Observable<Facet[]>;
    /** Defines the text displayed at the top of the Facet Typeahead List. */
    header: string;
    /** Defines whether or not the Facet Typeahead List should be initially expanded or not. */
    expanded: boolean;
    /** Defines a list of facets which will be displayed above the typeahead to allow the user to quickly select some facets. */
    suggestions: Facet[];
    /** Defines whether or not the checkboxes displayed alongside suggestions will appear in simplified form. */
    simplified: boolean;
    /** Defines the query displayed in the input field. */
    set query(query: string);
    /** Emits the current query when the value of the input field changes. */
    queryChange: EventEmitter<string>;
    /**
     * This will be triggered when a facet is selected, deselected or all facets are deselected.
     * The event will be an instance of either `FacetSelect`, `FacetDeselect` or `FacetDeselectAll` and
     * will contain the facet being selected or deselected in a `facet` property (deselect all will not contain affected facets).
     */
    events: Subject<FacetEvent>;
    /** If two-way binding is used this array will get updated any time the selected facets change. */
    selectedChange: EventEmitter<Facet[]>;
    /**
     * Allows configuration of the typeahead control. The possible values are:
     * - `placeholder` - **string** - Sets the placeholder of the typeahead.
     * - `minCharacters` - **number** - Defines the minimum number of characters that are required before results will be shown. **Default**: `1`.
     * - `maxResults` - **number** - Sets the maximum number of results to display. **Default**: `50`.
     * - `delay` - **number** - Defines the number of milliseconds to wait before the results are filtered. **Default**: `0`.
     */
    set typeaheadConfig(config: FacetTypeaheadListConfig);
    get typeaheadConfig(): FacetTypeaheadListConfig;
    options: QueryList<FacetTypeaheadListItemComponent>;
    query$: BehaviorSubject<string>;
    loading: boolean;
    activeIndex: number;
    typeaheadId: string;
    typeaheadOpen: boolean;
    typeaheadOptions: Facet[];
    highlightedElement: HTMLElement;
    private _facets;
    private _selected;
    private readonly _onDestroy;
    private _config;
    private _focusKeyManager;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    onKeydown(event: KeyboardEvent): void;
    onFocus(index: number): void;
    toggleFacet(index: number, facet: Facet): void;
    /** Only show typeahead if we have enough characters */
    updateTypeahead(query?: string): void;
    getFacetObservable(): Observable<Facet[]>;
    select(event: TypeaheadOptionEvent): void;
    private isOwnFacet;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetTypeaheadListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FacetTypeaheadListComponent, "ux-facet-typeahead-list", never, { "selected": { "alias": "selected"; "required": false; }; "facets": { "alias": "facets"; "required": false; }; "header": { "alias": "header"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "suggestions": { "alias": "suggestions"; "required": false; }; "simplified": { "alias": "simplified"; "required": false; }; "query": { "alias": "query"; "required": false; }; "typeaheadConfig": { "alias": "typeaheadConfig"; "required": false; }; }, { "queryChange": "queryChange"; "events": "events"; "selectedChange": "selectedChange"; }, never, never, true, never>;
}
interface FacetTypeaheadListConfig {
    placeholder?: string;
    minCharacters?: number;
    maxResults?: number;
    delay?: number;
}
declare class FacetTypeaheadHighlight implements PipeTransform {
    transform(value: string, searchQuery: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetTypeaheadHighlight, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FacetTypeaheadHighlight, "facetTypeaheadHighlight", true>;
}

declare class FacetsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FacetsModule, never, [typeof i1.A11yModule, typeof AccessibilityModule, typeof CheckboxModule, typeof i2.CommonModule, typeof i3$2.FormsModule, typeof IconModule, typeof ReorderableModule, typeof TooltipModule, typeof TypeaheadModule, typeof i2$2.DragDropModule, typeof SafeInnerHtmlDirective, typeof FacetContainerComponent, typeof FacetHeaderComponent, typeof FacetCheckListComponent, typeof FacetCheckListItemComponent, typeof FacetTypeaheadListComponent, typeof FacetTypeaheadListItemComponent, typeof FacetTypeaheadHighlight, typeof FacetClearButtonDirective], [typeof FacetContainerComponent, typeof FacetHeaderComponent, typeof FacetCheckListComponent, typeof FacetCheckListItemComponent, typeof FacetTypeaheadListComponent, typeof FacetTypeaheadListItemComponent, typeof FacetTypeaheadHighlight, typeof FacetClearButtonDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FacetsModule>;
}

interface Filter {
    id?: string;
    group: string;
    title: string;
    name: string;
    initial?: boolean;
}

declare class FilterAddEvent {
    filter: Filter;
    constructor(filter: Filter);
}

declare class FilterRemoveAllEvent {
}

declare class FilterRemoveEvent {
    filter: Filter;
    constructor(filter: Filter);
}

type FilterEvent = FilterAddEvent | FilterRemoveEvent | FilterRemoveAllEvent;

declare class FilterService {
    /** The list of active filters */
    filters$: BehaviorSubject<Filter[]>;
    /** Emit all the events when they occur */
    events$: Subject<FilterEvent>;
    add(filter: Filter): void;
    remove(filter: Filter): void;
    removeAll(): void;
    isSelected(filter: Filter): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FilterService>;
}

declare class FilterContainerComponent implements OnDestroy {
    readonly filterService: FilterService;
    /** Allow filters to set from outside the component */
    set filters(filters: Filter[]);
    /** Define the tooltip text */
    clearTooltip: string;
    /** Defines the aria-label for the clear all button */
    clearAriaLabel: string;
    /** Emit when the active filters chance */
    filtersChange: EventEmitter<Filter[]>;
    /** Emit when a specific event occurs */
    events: EventEmitter<FilterEvent>;
    /** Allow the content of the clear all button to be customized */
    clearAllTemplate: TemplateRef<void>;
    /** Unsubscribe from the subscriptions on destroy */
    private readonly _onDestroy;
    constructor();
    /** Destroy all subscriptions */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterContainerComponent, "ux-filter-container", never, { "filters": { "alias": "filters"; "required": false; }; "clearTooltip": { "alias": "clearTooltip"; "required": false; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; }; }, { "filtersChange": "filtersChange"; "events": "events"; }, ["clearAllTemplate"], ["*"], true, never>;
}

declare class FilterDropdownComponent implements OnInit, OnDestroy {
    private readonly _filterService;
    private readonly _changeDetector;
    /** Store the unique id so we only increment the counter once per instance */
    private readonly _uniqueId;
    /** Define the input for the component */
    id: string;
    /** The list of items to display in the dropdown */
    filters: Filter[];
    /** Define an initial item to select */
    initial: Filter;
    /** Defined the closeOnBlur state for the ux-menu trigger */
    set closeOnBlur(value: boolean);
    get closeOnBlur(): boolean;
    /** Emit when the filter menu is closed */
    readonly closed: EventEmitter<void>;
    selected: Filter;
    get filterId(): string;
    private readonly _onDestroy;
    private _closeOnBlur;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    selectFilter(filter: Filter, event: Event): void;
    removeFilter(): void;
    static ngAcceptInputType_closeOnBlur: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterDropdownComponent, "ux-filter-dropdown", never, { "id": { "alias": "id"; "required": false; }; "filters": { "alias": "filters"; "required": false; }; "initial": { "alias": "initial"; "required": false; }; "closeOnBlur": { "alias": "closeOnBlur"; "required": false; }; }, { "closed": "closed"; }, never, never, true, never>;
}

interface FilterDynamicListConfig {
    placeholder?: string;
    minCharacters?: number;
    maxResults?: number;
    maxIndividualItems?: number;
}

declare class FilterDynamicComponent implements OnInit, OnDestroy {
    readonly typeaheadKeyService: TypeaheadKeyService<any>;
    private readonly _filterService;
    private readonly _changeDetector;
    /** The unique id is used multiple times - this is to ensure we only increment it once per instance */
    private readonly _uniqueId;
    /** Define the input for the component */
    id: string;
    /** The list of possible filter options */
    filters: Filter[];
    /** Specify if there should be an initially selected filter */
    initial: Filter;
    /** Defined the closeOnBlur state for the ux-menu trigger */
    set closeOnBlur(value: boolean);
    get closeOnBlur(): boolean;
    /** Specify the typeahead options */
    set options(options: FilterDynamicListConfig);
    /** Get the options with the defaults for any missing options */
    get options(): FilterDynamicListConfig;
    /** Emit when the filter menu is closed */
    readonly closed: EventEmitter<void>;
    /** Generate a unique id for the typeahead */
    typeaheadId: string;
    /** Store the current search query */
    query$: BehaviorSubject<string>;
    /** Store the selected filter */
    selected: Filter;
    /** Indicate whether or not the typeahead should be shown */
    showTypeahead: boolean;
    /** Store the items that should be displayed in the typeahead */
    typeaheadItems: string[];
    /** Store the currently highlighted element */
    highlightedElement: HTMLElement;
    /** Store the open state of the typeahead */
    typeaheadOpen: boolean;
    /** Get the user provided id or fallback to a default ID */
    get filterId(): string;
    /** The default options */
    private readonly _defaultOptions;
    /** Store the user specified typeahead options */
    private _options;
    /** Unsubscribe from all subscriptions */
    private readonly _onDestroy;
    private _closeOnBlur;
    constructor();
    /** Set up the initial conditions */
    ngOnInit(): void;
    /** Cleanup all subscriptions */
    ngOnDestroy(): void;
    /** Get the items to display in the typeahead based on the search query */
    getItems(): string[];
    /** When the dropdown is closed clear the query */
    onClose(): void;
    /** If a filter needs removed, and is not the initial filter then remove it */
    removeFilter(): void;
    /** Select a specific filter */
    selectFilter(filter: Filter): void;
    /** Update typeahead items and visibility */
    updateTypeahead(query: string): void;
    /** Select a filter from a typeahead item */
    select(event: TypeaheadOptionEvent): void;
    static ngAcceptInputType_closeOnBlur: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterDynamicComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterDynamicComponent, "ux-filter-dynamic", never, { "id": { "alias": "id"; "required": false; }; "filters": { "alias": "filters"; "required": false; }; "initial": { "alias": "initial"; "required": false; }; "closeOnBlur": { "alias": "closeOnBlur"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, { "closed": "closed"; }, never, never, true, never>;
}

declare class FilterTypeaheadHighlight implements PipeTransform {
    transform(value: string, searchQuery: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterTypeaheadHighlight, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FilterTypeaheadHighlight, "filterTypeaheadHighlight", true>;
}

interface MenuModuleOptions {
    animate?: boolean;
}

/**
 * This is used to avoid having to do an `instanceof` check
 * which would cause a circular dependency between the
 * `MenuComponent` and `MenuItemComponent`
 */
declare enum MenuItemType {
    Default = 0,
    Custom = 1
}

declare class MenuItemComponent implements OnInit, OnDestroy, FocusableOption {
    private readonly _menu;
    private readonly _elementRef;
    private readonly _focusIndicatorService;
    private readonly _renderer;
    /** Define if this item is disabled or not */
    set disabled(disabled: boolean);
    get disabled(): boolean;
    /** Determine if the menu should close on item click/enter.*/
    set closeOnSelect(value: boolean);
    get closeOnSelect(): boolean;
    /** Define the role of the element */
    role: 'menuitem' | 'menuitemradio' | 'menuitemcheckbox';
    /** Emits when the menu item is clicked or the enter key is pressed. */
    activate: EventEmitter<MouseEvent | KeyboardEvent>;
    /** Access the open state */
    get isOpen(): boolean;
    /** Indicate the type of the menu item */
    readonly type: MenuItemType;
    /** Store the current hover state */
    readonly isHovered$: BehaviorSubject<boolean>;
    /** Store the current focus state */
    readonly isFocused$: BehaviorSubject<boolean>;
    /** Store the current expanded state */
    readonly isExpanded$: BehaviorSubject<boolean>;
    /** Emit when an item is clicked */
    readonly onClick$: Subject<FocusOrigin>;
    /** Store the focus indicator instance */
    private _focusIndicator;
    /** Automatically unsubscribe from observables on destroy */
    private readonly _onDestroy$;
    private _disabled;
    private _closeOnSelect;
    ngOnInit(): void;
    ngOnDestroy(): void;
    focus(origin: FocusOrigin): void;
    /** This function is built into the CDK manager to allow jumping to items based on text content */
    getLabel(): string;
    _onMouseEnter(): void;
    _onMouseLeave(): void;
    _onFocus(): void;
    _onBlur(): void;
    _onClick(event: MouseEvent | KeyboardEvent): void;
    /** Forward any keyboard events to the MenuComponent for accessibility */
    _onKeydown(event: KeyboardEvent): void;
    /** Update the tab index on this item */
    private setTabIndex;
    static ngAcceptInputType_disabled: boolean | string;
    static ngAcceptInputType_closeOnSelect: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MenuItemComponent, "[uxMenuItem]", never, { "disabled": { "alias": "disabled"; "required": false; }; "closeOnSelect": { "alias": "closeOnSelect"; "required": false; }; "role": { "alias": "role"; "required": false; }; }, { "activate": "activate"; }, never, ["*"], true, never>;
}

declare class MenuTabbableItemDirective implements OnInit, OnDestroy, FocusableOption {
    protected readonly _menu: MenuComponent;
    protected readonly _elementRef: ElementRef<HTMLElement>;
    protected readonly _focusIndicatorService: FocusIndicatorService;
    protected readonly _renderer: Renderer2;
    /** Define if this item is disabled or not */
    disabled: boolean;
    /** Indicate the type of the menu item */
    readonly type: MenuItemType;
    /** Store the focus indicator instance */
    protected focusIndicator: FocusIndicator;
    /** Automatically unsubscribe when directive is destroyed */
    protected _onDestroy$: Subject<void>;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Focus this item with a given origin */
    focus(origin: FocusOrigin): void;
    /** This function is built into the CDK manager to allow jumping to items based on text content */
    getLabel(): string;
    /** Forward any keyboard events to the MenuComponent for accessibility */
    _onKeydown(event: KeyboardEvent): void;
    /** Update the tab index on this item */
    protected setTabIndex(isTabbable: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuTabbableItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MenuTabbableItemDirective, "[uxMenuTabbableItem]", never, { "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MenuComponent implements AfterContentInit, OnDestroy, OnChanges {
    private readonly _options;
    private readonly _changeDetector;
    /** A unique id for the component. */
    id: string;
    /** Define the position of the menu */
    placement: AnchorPlacement;
    /** Define the alignment of the menu */
    alignment: AnchorAlignment;
    /** Define if we should animate the menu */
    animate: boolean;
    /** Forward any classes to the actual menu element */
    menuClass: string;
    /** Emit when the opening has begun (the opened EventEmitter waits until the animation has finished) */
    readonly opening: EventEmitter<void>;
    /** Emit when the menu is opened */
    readonly opened: EventEmitter<void>;
    /** Emit whenever closing has begun (the closed EventEmitter waits until animation has finished) */
    readonly closing: EventEmitter<void>;
    /** Emit when the menu is closed */
    readonly closed: EventEmitter<void>;
    /** Access the menu content template */
    templateRef: TemplateRef<void>;
    /** Store the menu open state */
    isMenuOpen: boolean;
    /** Store the animation state */
    _isAnimating: boolean;
    /** Determine if this is a submenu */
    _isSubMenu: boolean;
    /** Handle keyboard interactions */
    _keyManager: FocusKeyManager<MenuItemComponent | MenuTabbableItemDirective>;
    /** Whether this menu should close when it loses focus */
    _closeOnBlur: boolean;
    /** Emit when the focused item changes (we use this as the key manager is not instantiated until a late lifecycle hook) */
    readonly _activeItem$: BehaviorSubject<MenuItemComponent | MenuTabbableItemDirective>;
    /** Access allow a close event to propagate all the way up the submenus */
    readonly _closeAll$: Subject<FocusOrigin | "tabout">;
    /** Emit keyboard events */
    readonly _onKeydown$: Subject<KeyboardEvent>;
    /** Emit hover events */
    readonly _isHovering$: BehaviorSubject<boolean>;
    /** Emit focus events */
    readonly _isFocused$: BehaviorSubject<boolean>;
    /** Emit placement change */
    readonly _placement$: BehaviorSubject<AnchorPlacement>;
    readonly _alignment$: BehaviorSubject<AnchorAlignment>;
    /** Access all child menu items for accessibility purposes */
    private readonly _items$;
    /** Automatically unsubscribe when the component is destroyed */
    private readonly _onDestroy$;
    private _isTabPressed;
    /** Get innerId for use for accessibility  */
    get innerId(): string;
    get _isExpanded(): Observable<boolean>;
    get _menuItemClick(): Observable<FocusOrigin>;
    /** Return only menu items an not custom tabbable items */
    private get _menuItems();
    /** Create an internal querylist to store the menu items */
    private readonly _itemsList;
    ngAfterContentInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    /** Register a menu item - we do this do avoid `@ContentChildren` detecting submenu items */
    _addItem(item: MenuItemComponent | MenuTabbableItemDirective): void;
    /** Remove an item */
    _removeItem(item: MenuItemComponent | MenuTabbableItemDirective): void;
    /** Determine if an item exists */
    private hasItem;
    /** Internal function to set the open state and run change detection */
    _setMenuOpen(menuOpen: boolean): void;
    /** Close the menu if the focus event is null */
    _focusChange(event: any): void;
    /** Track the animation state */
    _onAnimationStart(): void;
    /** Track animation state and emit event when opening or closing */
    _onAnimationDone(): void;
    _closeMenu(): void;
    /** Forward any keyboard events to the key manage for accessibility */
    _onKeydown(event: KeyboardEvent): void;
    _onHoverStart(): void;
    _onHoverEnd(): void;
    _onFocus(): void;
    _onBlur(): void;
    _onKeyDown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MenuComponent, "ux-menu", never, { "id": { "alias": "id"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; "animate": { "alias": "animate"; "required": false; }; "menuClass": { "alias": "menuClass"; "required": false; }; }, { "opening": "opening"; "opened": "opened"; "closing": "closing"; "closed": "closed"; }, never, ["*"], true, never>;
}

declare class MenuTriggerDirective implements OnInit, OnDestroy {
    private readonly _overlay;
    private readonly _elementRef;
    private readonly _viewContainerRef;
    private readonly _focusOrigin;
    private readonly _focusIndicatorService;
    private readonly _overlayPlacement;
    private readonly _parentMenu;
    private readonly _menuItem;
    /** Access the menu we should show */
    menu: MenuComponent;
    /** Determine if we should disable the trigger */
    disabled: boolean;
    /** Optionally specify the menu's parent element */
    parent: ElementRef;
    /** Determine if the menu should close when it loses focus */
    set closeOnBlur(value: boolean);
    get closeOnBlur(): boolean;
    /** Emit when the menu is closed */
    readonly closed: EventEmitter<void>;
    /** Reference to the portal based off the MenuCompont templateRef */
    private _portal;
    /** Store the reference to the overlay */
    private _overlayRef?;
    /** Get the aria controls for accessibility */
    get ariaControls(): string | null;
    /** Store the instance of the focus indicator */
    private _focusIndicator;
    /** Automatically unsubscribe on directive destroy */
    private readonly _onDestroy$;
    /** Reference to the menu should close when it loses focus */
    private _closeOnBlur;
    /** Determine if this triggers a submenu */
    private get _isSubmenuTrigger();
    /** Determine if this is the root trigger */
    private get _isRootTrigger();
    private readonly _debounceTime;
    menuTriggers: QueryList<MenuTriggerDirective>;
    /** If this is a submenu we want to know when the mouse leaves the items or parent item */
    private get _menuShouldClose();
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Focus the next focusable element */
    focusNextElement(): void;
    /** Open the menu */
    openMenu(): void;
    /** Close a menu or submenu */
    closeMenu(origin?: FocusOrigin, closeParents?: boolean, focusTrigger?: boolean, focusNextElement?: boolean): Observable<void>;
    /** Toggle the open state of a menu */
    toggleMenu(event?: MouseEvent | KeyboardEvent): void;
    /** Submenus should be opened by hovering on the menu item */
    _onMouseEnter(): void;
    _onMouseMove(): void;
    /** Pressing the escape key should close all menus */
    _onEscape(): void;
    /** Handle keyboard events for opening submenus */
    _onKeydown(event: KeyboardEvent): void;
    /** Blurring the trigger should check if the menu has focus and close it if not */
    _onBlur(): void;
    /** Remove the menu from the DOM */
    private destroyMenu;
    /** Create an overlay or return an existing instance */
    private getOverlay;
    /** Create a Template portal if one does not already exist (or the template has changed) */
    private getPortal;
    /** Get an observable that emits on any of the triggers that close a menu */
    private didMenuClose;
    /** When the menu opens we want to focus the first item in the list */
    private menuDidOpen;
    /** Handle keypresses in submenus where we may want to close them */
    private onMenuKeydown;
    /** Check whether the overlay has focus */
    private hasFocus;
    /** Close the menu if there is no element focused */
    private closeOnFocusout;
    private getSubMenuPlacement;
    static ngAcceptInputType_closeOnBlur: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuTriggerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MenuTriggerDirective, "[uxMenuTriggerFor]", ["ux-menu-trigger"], { "menu": { "alias": "uxMenuTriggerFor"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "parent": { "alias": "uxMenuParent"; "required": false; }; "closeOnBlur": { "alias": "closeOnBlur"; "required": false; }; }, { "closed": "closed"; }, ["menuTriggers"], never, true, never>;
}

declare class MenuDividerComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuDividerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MenuDividerComponent, "ux-menu-divider", never, {}, {}, never, never, true, never>;
}

declare class MenuInitialFocusDirective implements OnInit, OnDestroy {
    private readonly _menu;
    private readonly _elementRef;
    private readonly _renderer;
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Apply tabindex="0" to the element if it's not already focusable. */
    private ensureFocusable;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuInitialFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MenuInitialFocusDirective, "[uxMenuInitialFocus]", never, {}, {}, never, never, true, never>;
}

declare const FocusableItemToken: InjectionToken<FocusableControl>;
declare class MenuItemCustomControlDirective extends MenuTabbableItemDirective implements FocusableOption, OnInit, OnDestroy {
    private readonly _focusableControl;
    /** Indicate the type of the menu item */
    readonly type: MenuItemType;
    constructor();
    ngOnInit(): void;
    /** Focus this item with a given origin */
    focus(origin: FocusOrigin): void;
    /** We want to remove the ability to shift+tab back into the parent element */
    protected setTabIndex(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuItemCustomControlDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MenuItemCustomControlDirective, "[uxMenuItemCustomControl]", never, {}, {}, never, never, true, never>;
}

declare class MenuModule {
    static forRoot(options: MenuModuleOptions): ModuleWithProviders<MenuModule>;
    /** Support options at a child module level (implementation is the same as `forRoot`) */
    static forChild(options: MenuModuleOptions): ModuleWithProviders<MenuModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MenuModule, never, [typeof i1.A11yModule, typeof AccessibilityModule, typeof i2.CommonModule, typeof i2$1.OverlayModule, typeof MenuComponent, typeof MenuTriggerDirective, typeof MenuItemComponent, typeof MenuDividerComponent, typeof MenuTabbableItemDirective, typeof MenuInitialFocusDirective, typeof MenuItemCustomControlDirective], [typeof MenuComponent, typeof MenuTriggerDirective, typeof MenuItemComponent, typeof MenuDividerComponent, typeof MenuTabbableItemDirective, typeof MenuInitialFocusDirective, typeof MenuItemCustomControlDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MenuModule>;
}

declare class FilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FilterModule, never, [typeof i1.A11yModule, typeof AccessibilityModule, typeof i2.CommonModule, typeof i3$2.FormsModule, typeof IconModule, typeof MenuModule, typeof TooltipModule, typeof TypeaheadModule, typeof SafeInnerHtmlDirective, typeof FilterContainerComponent, typeof FilterDropdownComponent, typeof FilterDynamicComponent, typeof FilterTypeaheadHighlight], [typeof FilterContainerComponent, typeof FilterDropdownComponent, typeof FilterDynamicComponent, typeof FilterTypeaheadHighlight]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FilterModule>;
}

declare class FlippableCardComponent implements OnDestroy {
    readonly focusIndicatorService: FocusIndicatorService;
    readonly elementRef: ElementRef<any>;
    /** Determines whether the card should flip horizontally or vertically. */
    direction: 'horizontal' | 'vertical';
    /**
     * Determines when the card should flip. Possible options are `click`, `hover` and `manual`.
     * The manual option should be used if you want complete control over when the card should flip.
     */
    trigger: 'click' | 'hover' | 'manual';
    /** Sets the width (in pixels) of the card. */
    width: number;
    /** Sets the height (in pixels) of the card. */
    height: number;
    /** Determines whether or not the card is flipped. */
    flipped: boolean;
    /** If two way binding is used this value will be updated when the state of the card changes. */
    flippedChange: EventEmitter<boolean>;
    /** Focus Indicator instance */
    private readonly _focusIndicator;
    constructor();
    ngOnDestroy(): void;
    setFlipped(state: boolean): void;
    toggleFlipped(): void;
    clickTrigger(): void;
    hoverEnter(): void;
    hoverExit(): void;
    onKeyDown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FlippableCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlippableCardComponent, "ux-flippable-card", ["ux-flippable-card"], { "direction": { "alias": "direction"; "required": false; }; "trigger": { "alias": "trigger"; "required": false; }; "width": { "alias": "width"; "required": false; }; "height": { "alias": "height"; "required": false; }; "flipped": { "alias": "flipped"; "required": false; }; }, { "flippedChange": "flippedChange"; }, never, ["ux-flippable-card-front", "ux-flippable-card-back"], true, never>;
}
declare class FlippableCardFrontDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<FlippableCardFrontDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FlippableCardFrontDirective, "ux-flippable-card-front", never, {}, {}, never, never, true, never>;
}
declare class FlippableCardBackDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<FlippableCardBackDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FlippableCardBackDirective, "ux-flippable-card-back", never, {}, {}, never, never, true, never>;
}

declare class FlippableCardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FlippableCardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FlippableCardModule, never, [typeof AccessibilityModule, typeof FlippableCardComponent, typeof FlippableCardBackDirective, typeof FlippableCardFrontDirective], [typeof FlippableCardComponent, typeof FlippableCardBackDirective, typeof FlippableCardFrontDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FlippableCardModule>;
}

type FloatingActionButtonDirection = AnchorPlacement;
declare class FloatingActionButtonsService {
    open$: BehaviorSubject<boolean>;
    direction$: BehaviorSubject<AnchorPlacement>;
    private _buttons;
    open(): void;
    toggle(): void;
    close(): void;
    isHorizontal(): boolean;
    isVertical(): boolean;
    setButtons(buttons: QueryList<FloatingActionButtonComponent>): void;
    /** Make only the first button tabbable */
    setPrimaryButtonFocusable(): void;
    focusPrimaryButton(): void;
    focus(button: FloatingActionButtonComponent): void;
    focusSibling(next: boolean): void;
    private getFocusedButton;
    private getButtonIndex;
    static ɵfac: i0.ɵɵFactoryDeclaration<FloatingActionButtonsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FloatingActionButtonsService>;
}

declare class FloatingActionButtonComponent implements AfterViewInit, OnDestroy {
    readonly fab: FloatingActionButtonsService;
    private readonly _tooltip;
    /** Define the aria label for the button */
    ariaLabel: string;
    /** Access the element ref of the button element */
    button: ElementRef;
    /** Determine if this is the primary button in the set */
    primary: boolean;
    /** Store the tabindex */
    tabindex$: BehaviorSubject<number>;
    /** Unsubscribe from all observables on component destroy */
    private readonly _onDestroy;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    focus(): void;
    onFocus(): void;
    onBlur(): void;
    close(): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FloatingActionButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FloatingActionButtonComponent, "ux-floating-action-button", never, { "ariaLabel": { "alias": "aria-label"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class FloatingActionButtonsComponent implements AfterViewInit, OnDestroy {
    readonly fab: FloatingActionButtonsService;
    private readonly _elementRef;
    /** Specify the direction that the FAB should display */
    set direction(direction: FloatingActionButtonDirection);
    /** Emit whenever the open state changes */
    openChange: EventEmitter<boolean>;
    /** Get all child FAB buttons */
    buttons: QueryList<FloatingActionButtonComponent>;
    private readonly _subscription;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    close(target: HTMLElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FloatingActionButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FloatingActionButtonsComponent, "ux-floating-action-buttons", never, { "direction": { "alias": "direction"; "required": false; }; }, { "openChange": "openChange"; }, ["buttons"], ["[fab-primary]", "*"], true, never>;
}

declare class FloatingActionButtonsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FloatingActionButtonsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FloatingActionButtonsModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof IconModule, typeof FloatingActionButtonsComponent, typeof FloatingActionButtonComponent], [typeof FloatingActionButtonsComponent, typeof FloatingActionButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FloatingActionButtonsModule>;
}

declare class TooltipService {
    shown$: Subject<TooltipComponent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TooltipService>;
}

interface HierarchyBarNode {
    icon?: string;
    title: string;
    selected?: boolean;
    parent?: HierarchyBarNode;
    children?: HierarchyBarNode[] | Observable<HierarchyBarNode[]>;
}

interface HierarchyBarIconContext {
    node: HierarchyBarNode;
}

/**
 * This is an interface to ensure that there are
 * no breaking changes to the existing public API
 * of the hierachy bar component
 */
interface IHierachyBarComponent {
    mode: HierarchyBarMode;
    root: HierarchyBarNode;
    selected: HierarchyBarNode;
    loadingIndicator: TemplateRef<void>;
    overflowTemplate: TemplateRef<void>;
    selectedChange: EventEmitter<HierarchyBarNode>;
    popoverShowTriggers: OverlayTrigger[];
    popoverHideTriggers: OverlayTrigger[];
}
type HierarchyBarMode = 'standard' | 'collapsed' | 'dropdown';

declare class HierarchyBarComponent implements IHierachyBarComponent, OnDestroy {
    private readonly _hierarchyBar;
    /** Define which presentational mode we should display */
    mode: HierarchyBarMode;
    /** hierarchy bar as being readonly - default false */
    readonly: boolean;
    /** Define the root node of the hierarchy bar */
    set root(node: HierarchyBarNode);
    /** Define the selected node in the hierarchy bar */
    set selected(node: HierarchyBarNode);
    /** Provide a custom loading indicator */
    set loadingIndicator(loadingIndicator: TemplateRef<void>);
    /** Provide a custom overflow template */
    set overflowTemplate(overflowTemplate: TemplateRef<void>);
    /** Define the events that show the popover when interacting with the arrows */
    set popoverShowTriggers(popoverShowTriggers: OverlayTrigger[]);
    /** Define the events that hide the popover when interacting with the arrows */
    set popoverHideTriggers(popoverHideTriggers: OverlayTrigger[]);
    /** Define the aria label for the show siblings popover button */
    set showSiblingsAriaLabel(label: string);
    /** Emit when the selected node changes */
    selectedChange: EventEmitter<HierarchyBarNode>;
    /** Allow a custom icon to be specified */
    set icon(icon: TemplateRef<HierarchyBarIconContext>);
    /** Unsubscribe from all subscriptions when component is destroyed */
    private readonly _onDestroy;
    constructor();
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HierarchyBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HierarchyBarComponent, "ux-hierarchy-bar", never, { "mode": { "alias": "mode"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "root": { "alias": "root"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "loadingIndicator": { "alias": "loadingIndicator"; "required": false; }; "overflowTemplate": { "alias": "overflowTemplate"; "required": false; }; "popoverShowTriggers": { "alias": "popoverShowTriggers"; "required": false; }; "popoverHideTriggers": { "alias": "popoverHideTriggers"; "required": false; }; "showSiblingsAriaLabel": { "alias": "showSiblingsAriaLabel"; "required": false; }; }, { "selectedChange": "selectedChange"; }, ["icon"], ["[uxHierarchyBarLeftAddon]", "[uxHierarchyBarTrailingAddon]", "[uxHierarchyBarRightAddon]"], true, never>;
}

declare class ClickOutsideDirective {
    private readonly _elementRef;
    uxClickOutside: EventEmitter<MouseEvent>;
    /** Often a click event makes the element appear - if so we can end up closing it immediately */
    private _initialised;
    constructor();
    click(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClickOutsideDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ClickOutsideDirective, "[uxClickOutside]", never, {}, { "uxClickOutside": "uxClickOutside"; }, never, never, true, never>;
}

declare class ClickOutsideModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ClickOutsideModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ClickOutsideModule, never, [typeof ClickOutsideDirective], [typeof ClickOutsideDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ClickOutsideModule>;
}

declare class PopoverComponent extends TooltipComponent {
    /** Define a unique id for each popover */
    id: string;
    /** If specified allows the popover to show a title */
    title: string;
    /** This will emit an event any time the user clicks outside the popover */
    clickOutside$: Subject<MouseEvent>;
    constructor();
    /** This will update the title of the popover and trigger change detection */
    setTitle(title: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PopoverComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PopoverComponent, "ux-popover", never, {}, {}, never, never, true, never>;
}

declare class PopoverDirective extends TooltipDirective implements OnInit, OnChanges {
    /** Contains the content of the popover or a TemplateRef for more detailed content */
    content: string | TemplateRef<void>;
    /** Optionally display a title in the popover */
    title: string;
    /** Allow the popover to be conditionally disabled */
    disabled: boolean;
    /** All the user to add a custom class to the popover */
    customClass: string;
    /** All the user to add a role to the popover - default is tooltip */
    role: string;
    /** Provide the TemplateRef a context object */
    context: any;
    /** Delay the showing of the popover by a number of miliseconds */
    delay: number;
    /** Specify which events should show the popover */
    showTriggers: OverlayTrigger[];
    /** Specify which events should hide the popover */
    hideTriggers: OverlayTrigger[];
    /** Keep track of the tooltip visibility and update aria-expanded attribute */
    isVisible: boolean;
    /** Define the overlay class */
    protected _overlayClass: string;
    /** A reference to the CDK portal containing the overlay */
    protected _portal: ComponentPortal<PopoverComponent>;
    /** A reference to the instance of the popover component when created */
    protected _instance: PopoverComponent;
    /** Determine whether or not an aria-describedby property originally existed on the element */
    private _ariaDescribedBy;
    /** Internally store the type of this component - usual for distinctions when extending the tooltip class */
    protected _type: string;
    constructor();
    /** Set up the triggers and bind to the show/hide events to keep visibility in sync */
    ngOnInit(): void;
    /**
     * We need to send input changes to the popover component
     * We can't use setters as they may trigger before popover initialised and can't resend once initialised
     **/
    ngOnChanges(changes: SimpleChanges): void;
    protected createInstance(overlayRef: OverlayRef): PopoverComponent;
    protected createPortal(): ComponentPortal<PopoverComponent>;
    private onKeyDown;
    private onClickOutside;
    /** Programmatically update the aria-describedby property */
    protected setAriaDescribedBy(id: string | null): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PopoverDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PopoverDirective, "[uxPopover]", ["ux-popover"], { "content": { "alias": "uxPopover"; "required": false; }; "title": { "alias": "popoverTitle"; "required": false; }; "disabled": { "alias": "popoverDisabled"; "required": false; }; "customClass": { "alias": "popoverClass"; "required": false; }; "role": { "alias": "popoverRole"; "required": false; }; "context": { "alias": "popoverContext"; "required": false; }; "delay": { "alias": "popoverDelay"; "required": false; }; "showTriggers": { "alias": "showTriggers"; "required": false; }; "hideTriggers": { "alias": "hideTriggers"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PopoverModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PopoverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PopoverModule, never, [typeof i2.CommonModule, typeof i2$1.OverlayModule, typeof i3$3.ObserversModule, typeof ClickOutsideModule, typeof TooltipModule, typeof PopoverComponent, typeof PopoverDirective], [typeof PopoverDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PopoverModule>;
}

interface HierarchyBarNodeChildren {
    loading: boolean;
    children: HierarchyBarNode[];
}

declare class HierarchyBarService {
    /** Define the list of selected nodes */
    nodes$: BehaviorSubject<HierarchyBarNode[]>;
    /** Define a custom loading indicator */
    loadingIndicator: TemplateRef<void>;
    /** Define a custom overflow template */
    overflowTemplate: TemplateRef<void>;
    /** Define the events that show the popover when interacting with the arrows */
    popoverShowTriggers: OverlayTrigger[];
    /** Define the events that hide the popover when interacting with the arrows */
    popoverHideTriggers: OverlayTrigger[];
    /** Emit the selected node when it changes */
    selection$: Subject<HierarchyBarNode>;
    /** Define the aria label for the show siblings popover button */
    showSiblingsAriaLabel: string;
    /** Allow a custom icon template to be specified */
    icon: TemplateRef<HierarchyBarIconContext>;
    /** Store the root node */
    private _root;
    /** Store nodes as a flattened list */
    private _nodes;
    /**
     * Store the root node of the hierarchy tree
     */
    setRootNode(root: HierarchyBarNode): void;
    /**
     * Select a node. This causes all nodes to be
     * deselected and the path to the selected node
     * to be selected
     */
    selectNode(node: HierarchyBarNode): void;
    /**
     * Handles getting children with support for both arrays and observables
     */
    getChildren(node: HierarchyBarNode): Observable<HierarchyBarNodeChildren>;
    /**
     * Utility function to get the sibling nodes, taking into account that
     * a node may be a root node and may not have a parent.
     */
    getSiblings(node: HierarchyBarNode): Observable<HierarchyBarNodeChildren>;
    /**
     * Traverses all the parents to ensure they are selected
     */
    private select;
    /**
     * Deselects all nodes
     */
    private deselectAll;
    /**
     * Gets all the nodes in the tree as a flat array.
     * It also stores the parent node in a parent property
     * on the node for easy traversal in both directions
     */
    private getNodeList;
    /**
     * Gets all selected nodes from the parent node.
     */
    private getSelectedChildren;
    static ɵfac: i0.ɵɵFactoryDeclaration<HierarchyBarService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HierarchyBarService>;
}

declare class HierarchyBarNodeComponent {
    readonly hierarchyBar: HierarchyBarService;
    private readonly _elementRef;
    /** Specify the node data */
    node: HierarchyBarNode;
    /** Define the template for the popover */
    popoverTemplate: TemplateRef<void>;
    /** Determine the mode of the hierarchy bar */
    mode: string;
    /** Determine read only state */
    readonly: boolean;
    /** Optionally define the horizontal offset */
    offset: number;
    /** Emit when the node is selected */
    selected: EventEmitter<HierarchyBarNode>;
    /** Determine if this node should be hidden due to overflow */
    visible: boolean;
    /** Get the width of the element */
    get width(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<HierarchyBarNodeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HierarchyBarNodeComponent, "ux-hierarchy-bar-node", never, { "node": { "alias": "node"; "required": false; }; "popoverTemplate": { "alias": "popoverTemplate"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, { "selected": "selected"; }, never, never, true, never>;
}

declare class HierarchyBarStandardComponent implements OnDestroy {
    readonly hierarchyBar: HierarchyBarService;
    /** Determine the mode of the hierarchy bar */
    mode: string;
    /** Determine read only state */
    readonly: boolean;
    /** Get the elementRef of the node list */
    nodelist: ElementRef<HTMLDivElement>;
    /** Get elementRefs for all the nodes */
    nodes: QueryList<ElementRef>;
    /** Get instances for all the nodes */
    nodeInstances: QueryList<HierarchyBarNodeComponent>;
    barNodes: QueryList<ElementRef>;
    /** Value in pixels to translate the visible nodes by to fill the empty space occupied by hidden nodes */
    overflowTranslateOffset: number;
    /** Identify which nodes are overflowing */
    overflow$: BehaviorSubject<HierarchyBarNode[]>;
    /** Determine if there is any overflow */
    isOverflowing$: BehaviorSubject<boolean>;
    /** Unsubscribe from all subscriptions when component is destroyed */
    private readonly _onDestroy;
    constructor();
    ngOnDestroy(): void;
    /**
     * When there is overflow ensure that the rightmost
     * node remains in view at all times. The nodes no longer
     * visible should be displayed in a popover available on the
     * overflow indicator
     */
    scrollIntoView(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HierarchyBarStandardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HierarchyBarStandardComponent, "ux-hierarchy-bar-standard", never, { "mode": { "alias": "mode"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, ["left-addons", "trailing-addons", "right-addons"], true, never>;
}

declare class HierarchyBarCollapsedComponent implements AfterViewInit, OnDestroy {
    readonly hierarchyBar: HierarchyBarService;
    private readonly _renderer;
    private readonly _resizeService;
    private readonly _elementRef;
    private readonly _changeDetector;
    /** Determine read only state */
    readonly: boolean;
    /** Get the first node to display */
    _first: HierarchyBarNode;
    /** Get the last node to display */
    _last: HierarchyBarNode;
    /** Get all the sibling nodes */
    get _siblings(): Observable<HierarchyBarNodeChildren>;
    /** Get all the nodes between the first and last nodes */
    get _parents(): HierarchyBarNode[];
    /** Get the nodes as an array */
    private get _nodes();
    /** Unsubscribe from all observables on destroy */
    private readonly _onDestroy;
    /** Access the node container */
    nodeContainer: ElementRef;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private update;
    updateOverflow(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HierarchyBarCollapsedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HierarchyBarCollapsedComponent, "ux-hierarchy-bar-collapsed", never, { "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, ["left-addons", "trailing-addons", "right-addons"], true, never>;
}

declare class HierarchyBarPopoverComponent {
    readonly hierarchyBar: HierarchyBarService;
    /** Define the nodes to display */
    nodes: HierarchyBarNode[];
    /** Define the loading state */
    loading: boolean;
    /** Defines if dropdown items should have separators between them to distinguish if nodes are siblings or ancestors */
    separator: boolean;
    /** Emit a select event when an item ahs been clicked or enter key pressed */
    selected: EventEmitter<HierarchyBarNode>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HierarchyBarPopoverComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HierarchyBarPopoverComponent, "ux-hierarchy-bar-popover", never, { "nodes": { "alias": "nodes"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "separator": { "alias": "separator"; "required": false; }; }, { "selected": "selected"; }, never, never, true, never>;
}

declare class HierarchyBarPopoverItemComponent implements OnDestroy {
    readonly focusOriginService: FocusIndicatorOriginService;
    readonly elementRef: ElementRef<any>;
    readonly renderer: Renderer2;
    readonly hierarchyBar: HierarchyBarService;
    /** Specify the node to display */
    node: HierarchyBarNode;
    /**
     * Emit when a click or enter key press occurs.
     * Note this is an `async` EventEmitter to ensure that
     * the event handlers in the `FocusIndicatorOrigin` set
     * the origin before we emit the select event, otherwise
     * the item may not get a focus ring when the keyboard is used.
     */
    selected: EventEmitter<HierarchyBarNode>;
    /** Allow this to control the focus origin */
    private readonly _focusOrigin;
    constructor();
    ngOnDestroy(): void;
    onSelect(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HierarchyBarPopoverItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HierarchyBarPopoverItemComponent, "ux-hierarchy-bar-popover-item", never, { "node": { "alias": "node"; "required": false; }; }, { "selected": "selected"; }, never, never, true, never>;
}

declare class HierarchyBarNodeIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<HierarchyBarNodeIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HierarchyBarNodeIconDirective, "[uxHierarchyBarNodeIcon]", never, {}, {}, never, never, true, never>;
}

declare class HierarchyBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HierarchyBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HierarchyBarModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof FocusIfModule, typeof IconModule, typeof PopoverModule, typeof ResizeModule, typeof HierarchyBarComponent, typeof HierarchyBarStandardComponent, typeof HierarchyBarCollapsedComponent, typeof HierarchyBarNodeComponent, typeof HierarchyBarPopoverComponent, typeof HierarchyBarPopoverItemComponent, typeof HierarchyBarNodeIconDirective], [typeof HierarchyBarComponent, typeof HierarchyBarStandardComponent, typeof HierarchyBarCollapsedComponent, typeof HierarchyBarNodeIconDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HierarchyBarModule>;
}

declare const ICON_OPTIONS_TOKEN: InjectionToken<IconModuleOptions>;

declare class IconService {
    readonly options: _ux_aspects_ux_aspects.IconModuleOptions;
    private readonly _iconService;
    /** Emit whenever the iconset changes */
    iconsChanged$: Subject<IconChangeEvent>;
    /** Store a list of all icon */
    private _icons;
    /** Inject a parent service if one exists */
    constructor();
    /** Define multiple icon definitions. This will override icon definitions if a name and size collision occurs */
    setIcons(icons: ReadonlyArray<IconDefinition>): void;
    /** Provide an icon definition which will override if necessary */
    setIcon({ name, icon, iconset, size }: IconDefinition): void;
    /** Find an icon based on the given name and size if provided */
    getIcon(name: string, size?: string): SingleIconDefinition;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IconService>;
}
interface IconChangeEvent {
    name: string;
    size?: string;
}

/** We generate the iconset definition as hardcoding it increases bundle size by ~40kb per iconset */
declare const uxIconset: ReadonlyArray<SingleIconDefinition>;

declare class InputDropdownComponent<T> implements ControlValueAccessor, AfterViewInit, OnChanges, OnDestroy {
    private readonly _changeDetector;
    /** Define the selected item */
    selected: T;
    /** Filter text */
    filter: string;
    /** Hide the filter input */
    hideFilter: boolean;
    /** Define the max height of the dropdown */
    set maxHeight(value: string | number);
    /** Controls the disabled state of the input-dropdown. */
    disabled: boolean;
    /** Define if null values are allowed */
    allowNull: boolean;
    /** Define the placeholder for the filter input */
    placeholder: string;
    /** Aria label of the filter field. If not specified, the placeholder will be used. */
    ariaLabel: string;
    /** ID of the element which serves as a label for the filter field. */
    ariaLabelledby: string;
    /** Aria label of the search button icon. */
    searchFilterButtonAriaLabel: string;
    /** Aria label of the clear button icon. */
    clearFilterButtonAriaLabel: string;
    /** Emit when the selected item is changed */
    selectedChange: EventEmitter<T>;
    /** Emit when the filter text is changed */
    filterChange: EventEmitter<string>;
    /** Emits when `dropdownOpen` changes. */
    dropdownOpenChange: EventEmitter<boolean>;
    /** The status of the dropdown. */
    dropdownOpen: boolean;
    /** Access the display content template if specified */
    displayContentRef: TemplateRef<void>;
    /** Access the dropdown menu trigger directive */
    menuTrigger: MenuTriggerDirective;
    /** Access the filter text input element */
    filterInputElement: ElementRef<HTMLInputElement>;
    /** Store the max height */
    _maxHeight: string;
    /** Store the filter button aria label */
    _filterButtonAriaLabel: string;
    /** Store the change callback provided by Angular Forms */
    onChange: (_: T) => void;
    /** Store the touched callback provided by Angular Forms */
    onTouched: () => void;
    /** Unsubscribe from all observables on component destroy */
    private readonly _onDestroy$;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    resetFilter(): void;
    registerOnChange(onChange: (value: T) => void): void;
    registerOnTouched(onTouched: () => void): void;
    writeValue(value: T): void;
    resetValue(event: Event): void;
    setDisabledState(isDisabled: boolean): void;
    onMenuOpen(): void;
    onMenuClose(): void;
    _focusFilter(): void;
    inputFocusHandler(): void;
    toggleMenu(): void;
    setFilterButtonAriaLabel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputDropdownComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputDropdownComponent<any>, "ux-input-dropdown", never, { "selected": { "alias": "selected"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; "hideFilter": { "alias": "hideFilter"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "allowNull": { "alias": "allowNull"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "ariaLabelledby"; "required": false; }; "searchFilterButtonAriaLabel": { "alias": "searchFilterButtonAriaLabel"; "required": false; }; "clearFilterButtonAriaLabel": { "alias": "clearFilterButtonAriaLabel"; "required": false; }; "dropdownOpen": { "alias": "dropdownOpen"; "required": false; }; }, { "selectedChange": "selectedChange"; "filterChange": "filterChange"; "dropdownOpenChange": "dropdownOpenChange"; }, ["displayContentRef"], ["*"], true, never>;
}

declare class InputDropdownModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<InputDropdownModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<InputDropdownModule, never, [typeof i2.CommonModule, typeof i3$2.FormsModule, typeof IconModule, typeof MenuModule, typeof AccessibilityModule, typeof InputDropdownComponent], [typeof InputDropdownComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<InputDropdownModule>;
}

declare enum SidePanelAnimationState {
    Closed = "closed",
    Open = "open",
    OpenImmediate = "openImmediate"
}

declare class SidePanelService {
    /** Emit the open state when it changes */
    open$: BehaviorSubject<boolean>;
    open(): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidePanelService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SidePanelService>;
}

declare class SidePanelComponent implements OnInit, OnDestroy {
    protected readonly service: SidePanelService;
    private readonly _elementRef;
    private readonly _focusOrigin;
    get open(): boolean;
    set open(value: boolean);
    inline: boolean;
    attachTo: 'window' | 'container';
    width: string | number;
    minWidth: string | number;
    maxWidth: string | number;
    top: string | number;
    modal: boolean;
    animate: boolean;
    closeOnExternalClick: boolean;
    focusOnShow: boolean;
    openChange: EventEmitter<boolean>;
    closeOnEscape: boolean;
    get position(): string;
    get cssWidth(): string;
    get cssTop(): string;
    get cssMinWidth(): string;
    get cssMaxWidth(): string;
    get componentWidth(): string;
    get hostWidth(): string;
    get hostMinWidth(): string;
    get hostMaxWidth(): string;
    animationPanelState: SidePanelAnimationState;
    protected _onDestroy: Subject<void>;
    ngOnInit(): void;
    ngOnDestroy(): void;
    openPanel(): void;
    closePanel(): void;
    _onDocumentEscape(): void;
    _onDocumentClick(target: HTMLElement): void;
    private getCssValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidePanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidePanelComponent, "ux-side-panel", ["ux-side-panel"], { "open": { "alias": "open"; "required": false; }; "inline": { "alias": "inline"; "required": false; }; "attachTo": { "alias": "attachTo"; "required": false; }; "width": { "alias": "width"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "top": { "alias": "top"; "required": false; }; "modal": { "alias": "modal"; "required": false; }; "animate": { "alias": "animate"; "required": false; }; "closeOnExternalClick": { "alias": "closeOnExternalClick"; "required": false; }; "focusOnShow": { "alias": "focusOnShow"; "required": false; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; }; }, { "openChange": "openChange"; }, never, ["*"], true, never>;
}

declare class ItemDisplayPanelContentDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemDisplayPanelContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ItemDisplayPanelContentDirective, "[uxItemDisplayPanelContent]", never, {}, {}, never, never, true, never>;
}
declare class ItemDisplayPanelFooterDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemDisplayPanelFooterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ItemDisplayPanelFooterDirective, "[uxItemDisplayPanelFooter]", never, {}, {}, never, never, true, never>;
}
declare class ItemDisplayPanelComponent extends SidePanelComponent implements OnInit {
    header: string;
    boxShadow: boolean;
    closeVisible: boolean;
    get preventClose(): boolean;
    set preventClose(value: boolean);
    /** Defines the aria-label for the close button */
    closeAriaLabel: string;
    shadow: boolean;
    visibleChange: EventEmitter<boolean>;
    footer: ItemDisplayPanelFooterDirective;
    panel: ElementRef;
    set visible(visible: boolean);
    get visible(): boolean;
    constructor();
    ngOnInit(): void;
    focus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemDisplayPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ItemDisplayPanelComponent, "ux-item-display-panel", never, { "header": { "alias": "header"; "required": false; }; "boxShadow": { "alias": "boxShadow"; "required": false; }; "closeVisible": { "alias": "closeVisible"; "required": false; }; "preventClose": { "alias": "preventClose"; "required": false; }; "closeAriaLabel": { "alias": "closeAriaLabel"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, { "visibleChange": "visibleChange"; }, ["footer"], ["[uxItemDisplayPanelContent]", "[uxItemDisplayPanelFooter]"], true, never>;
}

declare class ItemDisplayPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemDisplayPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ItemDisplayPanelModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof FocusIfModule, typeof IconModule, typeof ItemDisplayPanelComponent, typeof ItemDisplayPanelContentDirective, typeof ItemDisplayPanelFooterDirective], [typeof ItemDisplayPanelComponent, typeof ItemDisplayPanelContentDirective, typeof ItemDisplayPanelFooterDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ItemDisplayPanelModule>;
}

declare class MarqueeWizardStepIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<MarqueeWizardStepIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MarqueeWizardStepIconDirective, "[uxMarqueeWizardStepIcon]", never, {}, {}, never, never, true, never>;
}

declare class WizardStepComponent {
    private readonly _wizardService;
    private readonly _changeDetector;
    /** The text to be displayed in the wizard step tab. */
    header: string;
    /**
     * If set to `true` the 'Next' or 'Finish' button will become disabled when the current step is invalid.
     * This will override the value set on the `ux-wizard`.
     */
    disableNextWhenInvalid: boolean | undefined;
    /**
     * Defines whether a step is valid. The user will not be able to proceed to the next step if this property has a value of false.
     * If the new value is false is will also set the visited value to false.
     */
    _valid: boolean;
    set valid(value: boolean);
    get valid(): boolean;
    /**
     * A custom function which returns the validation status for the step. This function will be called when 'Next' or
     * 'Finish' is clicked. A promise may be returned if asynchronous validation is required. If using this property,
     * ensure that `disableNextWhenInvalid` is false.
     */
    validator: () => boolean | Promise<boolean>;
    /**
     * Defines whether or not this step has previously been visited.
     * A visited step can be clicked on and jumped to at any time.
     * By default, steps will become 'visited' when the user navigates to a step for the first time.
     */
    visited: boolean;
    /** Emits when visited changes. */
    visitedChange: EventEmitter<boolean>;
    set active(value: boolean);
    get active(): boolean;
    /**
     * Defines the currently visible step.
     */
    _active: boolean;
    setVisitedAndEmitChangeEvent(value: boolean): void;
    protected setValid(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WizardStepComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WizardStepComponent, "ux-wizard-step", never, { "header": { "alias": "header"; "required": false; }; "disableNextWhenInvalid": { "alias": "disableNextWhenInvalid"; "required": false; }; "valid": { "alias": "valid"; "required": false; }; "validator": { "alias": "validator"; "required": false; }; "visited": { "alias": "visited"; "required": false; }; }, { "visitedChange": "visitedChange"; }, never, ["*"], true, never>;
}

/**
 * This service is required to provide a form of communication
 * between the marquee wizard steps and the containing marquee wizard.
 * We cannot inject the Host due to the steps being content children
 * rather than view children.
 */
declare class WizardService<TWizardStep> {
    validChange$: Subject<WizardValidEvent<TWizardStep>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<WizardService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WizardService<any>>;
}
interface WizardValidEvent<TWizardStep> {
    step: TWizardStep;
    valid: boolean;
}

declare class WizardComponent implements OnInit, AfterContentInit, OnDestroy {
    protected readonly _wizardService: WizardService<WizardStepComponent>;
    /** Defines whether or not the wizard should be displayed in a `horizontal` or `vertical` layout. */
    orientation: 'horizontal' | 'vertical';
    /** Defines the text displayed in the 'Next' button. */
    nextText: string;
    /** Defines the text displayed in the 'Previous' button. */
    previousText: string;
    /** Defines the text displayed in the 'Cancel' button. */
    cancelText: string;
    /** Defines the text displayed in the 'Finish' button. */
    finishText: string;
    /** Defines the text displayed in the tooltip when the 'Next' button is hovered. */
    nextTooltip: string;
    /** Defines the text displayed in the tooltip when the 'Previous' button is hovered. */
    previousTooltip: string;
    /** Defines the text displayed in the tooltip when the 'Cancel' button is hovered. */
    cancelTooltip: string;
    /** Defines the text displayed in the tooltip when the 'Finish' button is hovered. */
    finishTooltip: string;
    /** Defines the text for the aria label on the 'Next' button. */
    nextAriaLabel: string;
    /** Defines the text for the aria label on the 'Previous' button. */
    previousAriaLabel: string;
    /** Defines the text for the aria label on the 'Cancel' button. */
    cancelAriaLabel: string;
    /** Defines the text for the aria label on the 'Finish' button. */
    finishAriaLabel: string;
    /** If set to `true` the 'Next' button will appear disabled and will not respond to clicks. */
    nextDisabled: boolean;
    /** If set to `true` the 'Previous' button will appear disabled and will not respond to clicks. */
    previousDisabled: boolean;
    /** If set to `true` the 'Cancel' button will appear disabled and will not respond to clicks. */
    cancelDisabled: boolean;
    /** If set to `true` the 'Finish' button will appear disabled and will not respond to clicks. */
    finishDisabled: boolean;
    /** If set to `false` the 'Next' button will be hidden. */
    nextVisible: boolean;
    /** If set to `false` the 'Previous' button will be hidden. */
    previousVisible: boolean;
    /** If set to `false` the 'Cancel' button will be hidden. */
    cancelVisible: boolean;
    /** If set to false the 'Finish' button will be hidden. */
    finishVisible: boolean;
    /** If set to `true` the 'Cancel' button will be visible even on the last step. By default it will be hidden on the final step. */
    cancelAlwaysVisible: boolean;
    /** If set to `true` the 'Finish' button will be visible on all steps of the wizard. By default this button will only be visible on the final step of the wizard. */
    finishAlwaysVisible: boolean;
    /** If set to `true` the 'Next' or 'Finish' button will become disabled when the current step is invalid. */
    disableNextWhenInvalid: boolean;
    /** Whether to set `visited` to false on subsequent steps after a validation fault. */
    resetVisitedOnValidationError: boolean;
    /** If set to false it will allow users to navigate to every step */
    sequential: boolean;
    /** Emits when the wizard has moved to the next step. It will receive the current step index as a parameter. */
    onNext: EventEmitter<number>;
    /** Emits when the wizard has moved to the previous step. It will receive the current step index as a parameter. */
    onPrevious: EventEmitter<number>;
    /** Emits when the 'Cancel' button has been pressed. */
    onCancel: EventEmitter<void>;
    /** Emits when the 'Finish' button is clicked, but before the finish event fires. This fires regardless of the validity of the final step. */
    onFinishing: EventEmitter<void>;
    /** Emits when the 'Finish' button has been pressed and the final step is valid. */
    onFinish: EventEmitter<void>;
    /** Emits before the current step changes. The event contains the current step index in the `from` property, and the requested step index in the `to` property. */
    stepChanging: EventEmitter<StepChangingEvent>;
    /** Emits when the current step has changed. */
    stepChange: EventEmitter<number>;
    /** Emits when the user tries to continue but the current step is invalid. */
    stepError: EventEmitter<number>;
    steps: QueryList<WizardStepComponent>;
    footerTemplate: TemplateRef<WizardFooterContext>;
    id: string;
    invalidIndicator: boolean;
    /**
     * The current active step. When the step changes an event will be emitted containing the index of the newly active step.
     * If this is not specified the wizard will start on the first step.
     */
    get step(): number;
    set step(value: number);
    private _step;
    protected readonly _onDestroy: Subject<void>;
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /**
     * Navigate to the next step
     */
    next(): Promise<void>;
    /**
     * Whether the Next or Finish button should be disabled.
     */
    isNextDisabled(): boolean;
    /**
     * Navigate to the previous step
     */
    previous(): void;
    /**
     * Perform actions when the finish button is clicked
     */
    finish(): Promise<void>;
    /**
     * Perform actions when the cancel button is clicked
     */
    cancel(): void;
    /**
     * Update the active state of each step
     */
    update(): void;
    /**
     * Jump to a specific step only if the step has previously been visited
     */
    gotoStep(step: WizardStepComponent): void;
    /**
     * Determine if the current step is the last step
     */
    isLastStep(): boolean;
    /**
     * Reset the wizard - goes to first step and resets visited state
     */
    reset(): void;
    /**
     * Get the step at the current index
     */
    getCurrentStep(): WizardStepComponent;
    /**
     * Return a step at a specific index
     */
    getStepAtIndex(index: number): WizardStepComponent;
    /**
     * If a step in the wizard becomes invalid, all steps sequentially after
     * it should become unvisited
     */
    protected setFutureStepsUnvisited(currentStep: WizardStepComponent): void;
    /**
     * Get the currently active step and all steps beyond it
     */
    protected getFutureSteps(currentStep: WizardStepComponent): WizardStepComponent[];
    /**
     * Returns the valid status of the current step, including the `validation` function (if provided).
     */
    private isStepValid;
    static ɵfac: i0.ɵɵFactoryDeclaration<WizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WizardComponent, "ux-wizard", never, { "orientation": { "alias": "orientation"; "required": false; }; "nextText": { "alias": "nextText"; "required": false; }; "previousText": { "alias": "previousText"; "required": false; }; "cancelText": { "alias": "cancelText"; "required": false; }; "finishText": { "alias": "finishText"; "required": false; }; "nextTooltip": { "alias": "nextTooltip"; "required": false; }; "previousTooltip": { "alias": "previousTooltip"; "required": false; }; "cancelTooltip": { "alias": "cancelTooltip"; "required": false; }; "finishTooltip": { "alias": "finishTooltip"; "required": false; }; "nextAriaLabel": { "alias": "nextAriaLabel"; "required": false; }; "previousAriaLabel": { "alias": "previousAriaLabel"; "required": false; }; "cancelAriaLabel": { "alias": "cancelAriaLabel"; "required": false; }; "finishAriaLabel": { "alias": "finishAriaLabel"; "required": false; }; "nextDisabled": { "alias": "nextDisabled"; "required": false; }; "previousDisabled": { "alias": "previousDisabled"; "required": false; }; "cancelDisabled": { "alias": "cancelDisabled"; "required": false; }; "finishDisabled": { "alias": "finishDisabled"; "required": false; }; "nextVisible": { "alias": "nextVisible"; "required": false; }; "previousVisible": { "alias": "previousVisible"; "required": false; }; "cancelVisible": { "alias": "cancelVisible"; "required": false; }; "finishVisible": { "alias": "finishVisible"; "required": false; }; "cancelAlwaysVisible": { "alias": "cancelAlwaysVisible"; "required": false; }; "finishAlwaysVisible": { "alias": "finishAlwaysVisible"; "required": false; }; "disableNextWhenInvalid": { "alias": "disableNextWhenInvalid"; "required": false; }; "resetVisitedOnValidationError": { "alias": "resetVisitedOnValidationError"; "required": false; }; "sequential": { "alias": "sequential"; "required": false; }; "step": { "alias": "step"; "required": false; }; }, { "onNext": "onNext"; "onPrevious": "onPrevious"; "onCancel": "onCancel"; "onFinishing": "onFinishing"; "onFinish": "onFinish"; "stepChanging": "stepChanging"; "stepChange": "stepChange"; "stepError": "stepError"; }, ["footerTemplate", "steps"], ["*"], true, never>;
}
declare class StepChangingEvent {
    from: number;
    to: number;
    constructor(from: number, to: number);
}
interface WizardFooterContext {
    step: number;
}

declare class WizardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<WizardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WizardModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof IconModule, typeof TooltipModule, typeof WizardComponent, typeof WizardStepComponent], [typeof WizardComponent, typeof WizardStepComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WizardModule>;
}

declare class MarqueeWizardStepComponent<TContext = unknown> extends WizardStepComponent {
    /** Define additional data that will be available within the stepTemplate context */
    context: TContext;
    /** Determine the completed state of this step */
    completed: boolean;
    /** Emit when the completed step changes */
    completedChange: EventEmitter<boolean>;
    /** Detect if an icon has been defined using the directive */
    _iconTemplate: TemplateRef<void>;
    /**
     * Update the completed state and emit the latest value
     * @param completed whether or not the step is completed
     */
    setCompleted(completed: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MarqueeWizardStepComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MarqueeWizardStepComponent<any>, "ux-marquee-wizard-step", never, { "context": { "alias": "context"; "required": false; }; "completed": { "alias": "completed"; "required": false; }; }, { "completedChange": "completedChange"; }, ["_iconTemplate"], ["*"], true, never>;
}

declare class MarqueeWizardComponent<TStepContext = unknown> extends WizardComponent implements OnDestroy, AfterViewChecked {
    readonly wizardService: WizardService<MarqueeWizardStepComponent<unknown>>;
    private readonly _resizeService;
    private readonly _elementRef;
    tabbableList: TabbableListDirective;
    /** Provide a custom template for the description in the left panel */
    description: string | TemplateRef<void>;
    /** Provide a custom template for the step in the left panel */
    stepTemplate: TemplateRef<MarqueeWizardStepContext<TStepContext>>;
    /** Initial set to default width to match 240px on left but can be changed with a percentage value */
    sidePanelWidth: number;
    /** Width of the splitter - default is 10 */
    gutterSize: number;
    /** If set to true the resizable splitter will be enabled and set to the default width **/
    resizable: boolean;
    /** Emit the current width of the splitter*/
    sidePanelWidthChange: EventEmitter<number>;
    /** Access each step content component */
    steps: QueryList<MarqueeWizardStepComponent<unknown>>;
    /**
     * If the wizard is in a modal it may initially have a size of 0 until the modal displays
     * in which case if we are using the splitter it will not render correctly. We use this
     * variable to only initialise the splitter when the content has a width.
     */
    _isInitialised: boolean;
    get isTemplate(): boolean;
    constructor();
    ngAfterViewChecked(): void;
    ngOnDestroy(): void;
    /**
     * If the current step is valid, mark it as
     * complete and go to the next step
     */
    next(): Promise<void>;
    /**
     * Emit the onFinishing event and if valid the onFinish event.
     * Also mark the final step as completed if it is valid
     */
    finish(): Promise<void>;
    onResize(event: ResizeDimensions): void;
    /** Whenever the drag event ends, update the internal value and emit the new size */
    onDragEnd({ sizes }: SplitDragEndEvent): void;
    gotoStep(step: WizardStepComponent): void;
    protected setFutureStepsUnvisited(currentStep: MarqueeWizardStepComponent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MarqueeWizardComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MarqueeWizardComponent<any>, "ux-marquee-wizard", never, { "description": { "alias": "description"; "required": false; }; "stepTemplate": { "alias": "stepTemplate"; "required": false; }; "sidePanelWidth": { "alias": "sidePanelWidth"; "required": false; }; "gutterSize": { "alias": "gutterSize"; "required": false; }; "resizable": { "alias": "resizable"; "required": false; }; }, { "sidePanelWidthChange": "sidePanelWidthChange"; }, ["steps"], ["*"], true, never>;
}
/** Angular Split does not export a type for this so we created our own */
interface SplitDragEndEvent {
    gutterNum: number;
    sizes: (number | '*')[];
}
interface MarqueeWizardStepContext<T> {
    $implicit: MarqueeWizardStepComponent<T>;
    index: number;
    context: T;
}

declare class MarqueeWizardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MarqueeWizardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MarqueeWizardModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof IconModule, typeof TooltipModule, typeof WizardModule, typeof i6.AngularSplitModule, typeof ResizeModule, typeof MarqueeWizardComponent, typeof MarqueeWizardStepComponent, typeof MarqueeWizardStepIconDirective], [typeof MarqueeWizardComponent, typeof MarqueeWizardStepComponent, typeof MarqueeWizardStepIconDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MarqueeWizardModule>;
}

declare class FrameExtractionService {
    private createVideoPlayer;
    private createCanvas;
    private goToFrame;
    private getThumbnail;
    getFrameThumbnail(source: string, width: number, height: number, time: number): Observable<ExtractedFrame>;
    getFrameThumbnails(source: string, width: number, height: number, start: number, end: number, skip?: number): Observable<ExtractedFrame>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FrameExtractionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FrameExtractionService>;
}
interface ExtractedFrame {
    image: string;
    width: number;
    height: number;
    time: number;
}

declare class AudioServiceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AudioServiceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AudioServiceModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AudioServiceModule>;
}

declare class AudioService {
    private readonly _http;
    private _audioBuffer;
    private _audioBufferSource;
    private _audioContext;
    private _gainNode;
    private _analyserNode;
    getAudioFileMetadata(mediaElement: HTMLMediaElement): Observable<AudioMetadata>;
    getWaveformFromUrl(url: string): Observable<Float32Array[]>;
    getWaveformPoints(channels?: Float32Array[], skip?: number): WaveformPoint[];
    private getAudioBuffer;
    private getOfflineAudioContext;
    private createBufferSource;
    private createVolumeNode;
    private createAnalyserNode;
    private disconnectSource;
    static ɵfac: i0.ɵɵFactoryDeclaration<AudioService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AudioService>;
}
interface WaveformPoint {
    min: number;
    max: number;
}
interface AudioMetadata {
    filename: string;
    extension: string;
    description: string;
    size: number;
}

declare class MediaPlayerComponent implements AfterViewInit, OnDestroy {
    readonly mediaPlayerService: MediaPlayerService;
    private readonly _audioService;
    private readonly _elementRef;
    private readonly _playerRef;
    hovering: boolean;
    focused: boolean;
    audioMetadata: Observable<AudioMetadata>;
    /** The `anonymous` keyword means that there will be no exchange of user credentials when the media source is fetched. */
    crossorigin: 'use-credentials' | 'anonymous';
    /** Overwrite the filename displayed in the audio media player */
    filename: string;
    get source(): string;
    /** The url to the media file to be loaded by the media player. */
    set source(value: string);
    get type(): MediaPlayerType;
    /**
     * Defines the appearance of the media player. The two possible values are `video` and `audio`.
     * The media player will adapt it's appearance to best suit the type specified.
     */
    set type(value: MediaPlayerType);
    get quietMode(): boolean;
    /**
     * If enabled, the controls in the media player will be hidden unless the mouse is over the player and will appear in a darker style.
     * Dark mode is automatically enabled in full screen mode. Quiet mode is only available for videos.
     */
    set quietMode(value: boolean);
    /**
     * If specified the function will be called passing the current volume as an argument.
     * It should return an appropriate aria-label for the mute/unmute button.
     */
    set muteAriaLabel(fn: (volume: number) => string);
    /**
     * If specified the function will be called passing the current playing state as an argument.
     * It should return an appropriate aria-label for the play/pause button.
     */
    set playAriaLabel(fn: (isPlaying: boolean) => string);
    /**
     * If specified the function will be called passing the current fullscreen state as an argument.
     * It should return an appropriate aria-label for the fullscreen toggle button.
     */
    set fullscreenAriaLabel(fn: (isFullscreen: boolean) => string);
    /**
     * If specified the function will be called passing the current track as an argument.
     * It should return an appropriate aria-label for the subtitle selection button.
     */
    set selectSubtitlesAriaLabel(fn: (track: string) => string);
    /** Defines an aria-label for the go to start button. */
    set goToStartAriaLabel(ariaLabel: string);
    /** Defines an aria-label for the go to end button. */
    set goToEndAriaLabel(ariaLabel: string);
    /** Defines an aria-label for the title displayed in the subtitle selection popover. */
    set subtitlesTitleAriaLabel(ariaLabel: string);
    /** Defines an aria-label to indicate subtitle are not currently enabled. */
    set subtitlesOffAriaLabel(ariaLabel: string);
    /** Define an aria-label to indicate there are no subtitles available. */
    set noSubtitlesAriaLabel(ariaLabel: string);
    /** Define an aria-label for the media player. */
    set mediaPlayerAriaLabel(ariaLabel: string);
    /** Define an aria-label for the the seek element. */
    set seekAriaLabel(ariaLabel: string);
    private readonly _onDestroy;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaPlayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MediaPlayerComponent, "ux-media-player", never, { "crossorigin": { "alias": "crossorigin"; "required": false; }; "filename": { "alias": "filename"; "required": false; }; "source": { "alias": "source"; "required": false; }; "type": { "alias": "type"; "required": false; }; "quietMode": { "alias": "quietMode"; "required": false; }; "muteAriaLabel": { "alias": "muteAriaLabel"; "required": false; }; "playAriaLabel": { "alias": "playAriaLabel"; "required": false; }; "fullscreenAriaLabel": { "alias": "fullscreenAriaLabel"; "required": false; }; "selectSubtitlesAriaLabel": { "alias": "selectSubtitlesAriaLabel"; "required": false; }; "goToStartAriaLabel": { "alias": "goToStartAriaLabel"; "required": false; }; "goToEndAriaLabel": { "alias": "goToEndAriaLabel"; "required": false; }; "subtitlesTitleAriaLabel": { "alias": "subtitlesTitleAriaLabel"; "required": false; }; "subtitlesOffAriaLabel": { "alias": "subtitlesOffAriaLabel"; "required": false; }; "noSubtitlesAriaLabel": { "alias": "noSubtitlesAriaLabel"; "required": false; }; "mediaPlayerAriaLabel": { "alias": "mediaPlayerAriaLabel"; "required": false; }; "seekAriaLabel": { "alias": "seekAriaLabel"; "required": false; }; }, {}, never, ["track", "[uxMediaPlayerCustomControl]"], true, never>;
}
type MediaPlayerType = 'video' | 'audio';
interface MediaPlayerBuffer {
    start: number;
    end: number;
}

declare class MediaPlayerService {
    private readonly _frameExtractionService;
    source: string;
    type: MediaPlayerType;
    loaded: boolean;
    /** Aria Labels */
    muteAriaLabel: (volume: number) => string;
    playAriaLabel: (isPlaying: boolean) => string;
    fullscreenAriaLabel: (isFullscreen: boolean) => string;
    selectSubtitlesAriaLabel: (track: string) => string;
    goToStartAriaLabel: string;
    goToEndAriaLabel: string;
    subtitlesTitleAriaLabel: string;
    subtitlesOffAriaLabel: string;
    noSubtitlesAriaLabel: string;
    mediaPlayerAriaLabel: string;
    seekAriaLabel: string;
    playing: BehaviorSubject<boolean>;
    initEvent: ReplaySubject<boolean>;
    abortEvent: Subject<void>;
    canPlayEvent: BehaviorSubject<boolean>;
    canPlayThroughEvent: BehaviorSubject<boolean>;
    durationChangeEvent: Subject<number>;
    endedEvent: Subject<void>;
    errorEvent: Subject<void>;
    loadedDataEvent: Subject<void>;
    loadedMetadataEvent: Subject<void>;
    loadStartEvent: Subject<void>;
    pauseEvent: Subject<void>;
    playEvent: Subject<void>;
    playingEvent: Subject<boolean>;
    rateChangeEvent: Subject<number>;
    seekedEvent: Subject<number>;
    seekingEvent: Subject<number>;
    stalledEvent: Subject<void>;
    suspendEvent: Subject<void>;
    timeUpdateEvent: Subject<number>;
    volumeChangeEvent: Subject<number>;
    waitingEvent: Subject<void>;
    mediaClickEvent: Subject<MouseEvent>;
    fullscreenEvent: BehaviorSubject<boolean>;
    quietModeEvent: BehaviorSubject<boolean>;
    progressEvent: Observable<TimeRanges>;
    private _mediaPlayer;
    private _hostElement;
    private _fullscreen;
    private _quietMode;
    get mediaPlayer(): HTMLMediaElement;
    get quietMode(): boolean;
    set quietMode(value: boolean);
    get mediaPlayerWidth(): number;
    get mediaPlayerHeight(): number;
    get autoplay(): boolean;
    set autoplay(value: boolean);
    get buffered(): TimeRanges;
    get crossOrigin(): string;
    set crossOrigin(value: string);
    get currentSrc(): string;
    get currentTime(): number;
    set currentTime(value: number);
    get defaultMuted(): boolean;
    set defaultMuted(value: boolean);
    get defaultPlaybackRate(): number;
    set defaultPlaybackRate(value: number);
    get duration(): number;
    get ended(): boolean;
    get loop(): boolean;
    set loop(value: boolean);
    get muted(): boolean;
    set muted(value: boolean);
    get networkState(): number;
    get paused(): boolean;
    get playbackRate(): number;
    set playbackRate(value: number);
    get played(): TimeRanges;
    get preload(): '' | 'auto' | 'metadata' | 'none';
    set preload(value: '' | 'auto' | 'metadata' | 'none');
    get readyState(): number;
    get seekable(): TimeRanges;
    get seeking(): boolean;
    get src(): string;
    set src(value: string);
    get textTracks(): Array<TextTrack>;
    get volume(): number;
    set volume(value: number);
    get fullscreen(): boolean;
    set fullscreen(value: boolean);
    setMediaPlayer(hostElement: HTMLElement, mediaPlayer: HTMLMediaElement): void;
    /**
     * Toggle playing state
     */
    togglePlay(): void;
    /**
     * Starts playing the audio/video
     */
    play(): void;
    /**
     * Pauses the currently playing audio/video
     */
    pause(): void;
    /**
     * Re-loads the audio/video element
     */
    load(): void;
    /**
     * Checks if the browser can play the specified audio/video type
     */
    canPlayType(type: string): string;
    /**
     * Adds a new text track to the audio/video
     */
    addTextTrack(kind: 'subtitles' | 'captions' | 'descriptions' | 'chapters' | 'metadata', label: string, language: string): TextTrack;
    /**
     * Attempt to display media in fullscreen mode
     */
    requestFullscreen(): void;
    /**
     * Exit full screen mode
     */
    exitFullscreen(): void;
    /**
     * Toggle Fullscreen State
     */
    toggleFullscreen(): void;
    fullscreenChange(): void;
    /**
     * Extract the frames from the video
     */
    getFrames(width: number, height: number): Observable<ExtractedFrame>;
    hideSubtitleTracks(): void;
    private getMuteAriaLabel;
    private getPlayAriaLabel;
    private getFullscreenAriaLabel;
    private getSubtitlesAriaLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaPlayerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MediaPlayerService>;
}

declare class MediaPlayerBaseExtensionDirective {
    readonly mediaPlayerService: MediaPlayerService;
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaPlayerBaseExtensionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MediaPlayerBaseExtensionDirective, "[mediaPlayerBaseExtension]", never, {}, {}, never, never, true, never>;
}

declare class SliderComponent implements OnInit, AfterViewInit, DoCheck {
    readonly colorService: ColorService;
    private readonly _changeDetectorRef;
    /** A single number or a SliderValue object, depending on the slider type specified. */
    value: SliderValue | number;
    /** A set of options to customize the appearance and behavior of the slider. */
    set options(options: SliderOptions);
    /** Whether the slider is disabled. */
    set disabled(disabled: boolean);
    get disabled(): boolean;
    get options(): SliderOptions;
    /** Emits when the `value` changes. */
    valueChange: EventEmitter<SliderValue | number>;
    lowerTooltip: ElementRef;
    upperTooltip: ElementRef;
    track: ElementRef;
    private _value;
    private _disabled;
    _options: SliderOptions;
    sliderType: typeof SliderType;
    sliderStyle: typeof SliderStyle;
    sliderSize: typeof SliderSize;
    sliderSnap: typeof SliderSnap;
    sliderThumb: typeof SliderThumb;
    sliderTickType: typeof SliderTickType;
    sliderThumbEvent: typeof SliderThumbEvent;
    sliderCalloutTrigger: typeof SliderCalloutTrigger;
    tracks: {
        lower: {
            size: number;
            color: string;
        };
        middle: {
            size: number;
            color: string;
        };
        upper: {
            size: number;
            color: string;
        };
    };
    tooltips: {
        lower: {
            visible: boolean;
            position: number;
            label: string;
        };
        upper: {
            visible: boolean;
            position: number;
            label: string;
        };
    };
    thumbs: {
        lower: {
            hover: boolean;
            drag: boolean;
            position: number;
            order: number;
            value: number;
        };
        upper: {
            hover: boolean;
            drag: boolean;
            position: number;
            order: number;
            value: number;
        };
    };
    ticks: SliderTick[];
    defaultOptions: SliderOptions;
    constructor();
    ngOnInit(): void;
    ngDoCheck(): void;
    ngAfterViewInit(): void;
    snapToNearestTick(thumb: SliderThumb, snapTarget: SliderSnap, forwards: boolean): void;
    snapToEnd(thumb: SliderThumb, forwards: boolean): void;
    getThumbValue(thumb: SliderThumb): number;
    getFormattedValue(thumb: SliderThumb): string | number;
    private getThumbState;
    private setThumbState;
    thumbEvent(thumb: SliderThumb, event: SliderThumbEvent): void;
    getAriaValueText(thumb: SliderThumb): string | number;
    private updateTooltips;
    private updateTooltipText;
    private getTooltipElement;
    private getTooltip;
    private updateTooltipPosition;
    private preventTooltipOverlap;
    private clamp;
    updateThumbPosition(event: MouseEvent | TouchEvent, thumb: SliderThumb): void;
    private updateOrderOnDrag;
    private updateOrder;
    private getTickDistances;
    private snapToTick;
    private validateValue;
    private updateOptions;
    private updateValues;
    private setValue;
    private setThumbValue;
    private updateTicks;
    private updateTrackColors;
    /** Map the color value to the correct CSS color value */
    private getTrackColorStyle;
    private getSteps;
    private getTicks;
    private unionTicks;
    private deepMerge;
    private detectValueChange;
    /**
     * Determines whether or not an object conforms to the
     * SliderValue interface.
     * @param value - The object to check - this must be type any
     */
    private isSliderValue;
    private clone;
    static ngAcceptInputType_disabled: boolean | string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SliderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SliderComponent, "ux-slider", never, { "value": { "alias": "value"; "required": false; }; "options": { "alias": "options"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
declare enum SliderType {
    Value = 0,
    Range = 1
}
declare enum SliderStyle {
    Button = 0,
    Line = 1
}
declare enum SliderSize {
    Narrow = 0,
    Wide = 1
}
declare enum SliderCalloutTrigger {
    None = 0,
    Hover = 1,
    Drag = 2,
    Persistent = 3,
    Dynamic = 4
}
interface SliderValue {
    low: number;
    high: number;
}
declare enum SliderSnap {
    None = 0,
    Minor = 1,
    Major = 2,
    All = 3
}
declare enum SliderTickType {
    Minor = 0,
    Major = 1
}
interface SliderOptions {
    type?: SliderType;
    handles?: SliderHandleOptions;
    track?: SliderTrackOptions;
}
interface SliderHandleOptions {
    style?: SliderStyle;
    callout?: SliderCallout;
    keyboard?: SliderKeyboardOptions;
    aria?: SliderAriaOptions;
}
interface SliderAriaOptions {
    thumb?: string;
    lowerThumb?: string;
    upperThumb?: string;
}
interface SliderKeyboardOptions {
    major?: number;
    minor?: number;
}
interface SliderTrackOptions {
    height?: SliderSize;
    min?: number;
    max?: number;
    ticks?: SliderTicksOptions;
    colors?: SliderTrackColors;
}
interface SliderTicksOptions {
    snap?: SliderSnap;
    major?: SliderTickOptions;
    minor?: SliderTickOptions;
}
interface SliderTickOptions {
    show?: boolean;
    steps?: number | number[];
    labels?: boolean;
    formatter?: (value: number) => string | number;
}
interface SliderTick {
    showTicks: boolean;
    showLabels: boolean;
    type: SliderTickType;
    position: number;
    value: number;
    label: string | number;
}
interface SliderTrackColors {
    lower?: string | string[];
    range?: string | string[];
    higher?: string | string[];
}
interface SliderCallout {
    trigger?: SliderCalloutTrigger;
    background?: string;
    color?: string;
    formatter?: (value: number) => string | number;
}
declare enum SliderThumbEvent {
    None = 0,
    MouseOver = 1,
    MouseLeave = 2,
    DragStart = 3,
    DragEnd = 4
}
declare enum SliderThumb {
    Lower = 0,
    Upper = 1
}

declare class SliderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SliderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SliderModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof ColorServiceModule, typeof DragModule, typeof SliderComponent], [typeof SliderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SliderModule>;
}

declare class MediaPlayerControlsExtensionComponent implements OnInit, OnDestroy {
    readonly mediaPlayerService: MediaPlayerService;
    volumeActive: boolean;
    volumeFocus: boolean;
    returnFocus: boolean;
    subtitlesId: string;
    subtitlesOpen: boolean;
    mouseEnterVolume: Subject<void>;
    mouseLeaveVolume: Subject<void>;
    options: SliderOptions;
    private _volume;
    private _previousVolume;
    private readonly _onDestroy;
    get volume(): number;
    set volume(value: number);
    ngOnInit(): void;
    ngOnDestroy(): void;
    toggleMute(): void;
    goToStart(): void;
    goToEnd(): void;
    isSubtitleActive(): boolean;
    setSubtitleTrack(track: TextTrack): void;
    getSubtitleTrack(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaPlayerControlsExtensionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MediaPlayerControlsExtensionComponent, "ux-media-player-controls", never, {}, {}, never, ["*"], true, never>;
}

declare class MediaPlayerCustomControlDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaPlayerCustomControlDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MediaPlayerCustomControlDirective, "[uxMediaPlayerCustomControl]", never, {}, {}, never, never, true, never>;
}

declare class MediaPlayerTimelineExtensionComponent implements OnInit, AfterViewInit, OnDestroy {
    readonly mediaPlayerService: MediaPlayerService;
    thumb: ElementRef;
    timelineRef: ElementRef;
    current: number;
    position: number;
    buffered: MediaPlayerBuffered[];
    mouseDown: boolean;
    scrub: {
        visible: boolean;
        position: number;
        time: number;
    };
    private readonly _onDestroy;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    updateScrub(event: MouseEvent): void;
    /** Skip a number of seconds in any direction */
    skip(seconds: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaPlayerTimelineExtensionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MediaPlayerTimelineExtensionComponent, "ux-media-player-timeline", never, {}, {}, never, never, true, never>;
}
interface MediaPlayerBuffered {
    start: number;
    end: number;
}

declare class DurationPipe implements PipeTransform {
    transform(seconds: number): string;
    pad(value: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DurationPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DurationPipe, "duration", true>;
}

declare class DurationPipeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DurationPipeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DurationPipeModule, never, [typeof DurationPipe], [typeof DurationPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DurationPipeModule>;
}

declare class FileSizePipe implements PipeTransform {
    transform(value: number): string | number;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileSizePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FileSizePipe, "fileSize", true>;
}

declare class FileSizePipeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FileSizePipeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FileSizePipeModule, never, [typeof FileSizePipe], [typeof FileSizePipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FileSizePipeModule>;
}

declare class MediaPlayerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaPlayerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MediaPlayerModule, never, [typeof i1.A11yModule, typeof AccessibilityModule, typeof AudioServiceModule, typeof ClickOutsideModule, typeof i2.CommonModule, typeof DurationPipeModule, typeof FileSizePipeModule, typeof IconModule, typeof SliderModule, typeof TooltipModule, typeof MediaPlayerComponent, typeof MediaPlayerTimelineExtensionComponent, typeof MediaPlayerBaseExtensionDirective, typeof MediaPlayerControlsExtensionComponent, typeof MediaPlayerCustomControlDirective], [typeof MediaPlayerComponent, typeof MediaPlayerTimelineExtensionComponent, typeof MediaPlayerBaseExtensionDirective, typeof MediaPlayerControlsExtensionComponent, typeof MediaPlayerCustomControlDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MediaPlayerModule>;
}

interface NavigationItem {
    title: string;
    icon?: string;
    iconUrl?: string;
    iconLabel?: string;
    routerLink?: string | unknown[];
    routerExtras?: NavigationExtras;
    routerOptions?: NavigationItemRouterOptions;
    click?: (event: Event, navigationItem: NavigationItem) => void;
    expanded?: boolean;
    children?: NavigationItem[];
    disabled?: boolean;
}
interface NavigationItemRouterOptions {
    exact?: boolean;
    ignoreQueryParams?: boolean;
}

declare class NavigationItemComponent implements AfterViewInit, AfterContentInit, OnDestroy {
    private readonly _elementRef;
    private readonly _renderer;
    private readonly _router;
    private readonly _parent;
    /** The text to display in the navigation menu item. */
    header: string;
    /** The name of an icon from the UX Aspects icon set, to be displayed to the left of the title. */
    icon: string;
    /** Whether the navigation item is expanded, displaying the items from the `children` array. */
    expanded: boolean;
    /** The link that will be navigated to if this item is selected */
    link: string;
    /** Get the active state of this item from the router */
    get active(): boolean;
    /** Indicate the depth of the item */
    _level: number;
    /** Indicate whether the indentation should include the arrow */
    _indentWithoutArrow: boolean;
    private readonly _children;
    get children(): NavigationItemComponent[];
    /** Automatically unsubscribe when the component is destroyed */
    private readonly _onDestroy;
    constructor();
    ngAfterViewInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /** Check if this item or any children are active */
    private hasActiveLink;
    private getLevelClass;
    private setIndentWithoutArrow;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavigationItemComponent, "[ux-navigation-item]", never, { "header": { "alias": "header"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "link": { "alias": "link"; "required": false; }; }, {}, ["_children"], ["*"], true, never>;
}

declare class NavigationLinkDirective implements OnInit, OnChanges, OnDestroy {
    private readonly _router;
    private readonly _locationStrategy;
    private readonly _navigationService;
    private readonly _changeDetector;
    private readonly _route;
    private readonly _options;
    /** The NavigationItem this element represents */
    navigationItem: NavigationItem;
    /** The expaned state of this item */
    set expanded(value: boolean);
    /** Determine if this item can be expanded */
    canExpand: boolean;
    /** Determine if this item should be indented */
    indent: boolean;
    /** Determine the href of this element */
    href: string;
    /** Determine the role of this element */
    role: string;
    /** Update the aria-expanded attribute of this element */
    ariaExpanded: boolean;
    /** Store the active state of the item */
    isActive: boolean;
    /** Store the indendation state of the children */
    indentChildren: boolean;
    /** Emit with the current expaned state */
    private readonly _expanded$;
    /** Unsubscribe from all observables when this directive is destroyed */
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    activated(event: Event): boolean;
    private updateNavigationState;
    private updateAttributes;
    private getHref;
    private isActiveItem;
    /** Get the router options with defaults for missing properties */
    private getRouterOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NavigationLinkDirective, "[uxNavigationLink]", ["uxNavigationLink"], { "navigationItem": { "alias": "navigationItem"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "canExpand": { "alias": "canExpand"; "required": false; }; "indent": { "alias": "indent"; "required": false; }; }, {}, never, never, true, never>;
}

interface NavigationModuleOptions {
    routerOptions: NavigationItemRouterOptions;
}
declare const NAVIGATION_MODULE_OPTIONS: InjectionToken<NavigationModuleOptions>;

declare class NavigationComponent {
    private readonly _navigationService;
    /** The navigation items to populate the menu with. */
    set items(items: NavigationItem[]);
    get items(): NavigationItem[];
    /** Whether to present the menu as a hierarchical tree. */
    tree: boolean;
    /** Whether to collapse other menu items when expanding a menu item. */
    set autoCollapse(autoCollapse: boolean);
    /** Access a custom navigation item template if provided */
    navigationItemTemplate: TemplateRef<void>;
    /** The classes to be added to each different level */
    _hierarchyClasses: string[];
    get _depthLimit(): number;
    /**
     * Returns true if the sets of items needs to be indented to make room for one or more expander.
     */
    _needsIndent(items: NavigationItem[]): boolean;
    /** Determine the type of icon to display. We support `ux-icon` or `component` */
    _getIconType(item: NavigationItem): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavigationComponent, "ux-navigation", never, { "items": { "alias": "items"; "required": false; }; "tree": { "alias": "tree"; "required": false; }; "autoCollapse": { "alias": "autoCollapse"; "required": false; }; }, {}, ["navigationItemTemplate"], ["*"], true, never>;
}

declare class NavigationModule {
    static forRoot(options: NavigationModuleOptions): ModuleWithProviders<NavigationModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NavigationModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof IconModule, typeof i3$1.RouterModule, typeof NavigationComponent, typeof NavigationItemComponent, typeof NavigationLinkDirective], [typeof NavigationComponent, typeof NavigationItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NavigationModule>;
}

declare class NavigationService implements OnDestroy {
    /** The navigation items to populate the menu with */
    items: NavigationItem[];
    /** Whether to collapse other menu items when expanding a menu item. */
    autoCollapse: boolean;
    /** Emit when the expanded state has changed */
    expanded$: Subject<void>;
    ngOnDestroy(): void;
    /** Set the expanded state of an item */
    setExpanded(source: NavigationItem, expanded: boolean): void;
    /** Collapse all siblings nodes */
    private collapseSiblings;
    /** Collapse an item and all its children */
    private collapseAll;
    /** Get a nodes parent if it has one */
    private getParent;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NavigationService>;
}

declare class NestedDonutChartComponent implements OnInit, OnChanges, OnDestroy {
    private readonly _colorService;
    private readonly _changeDetector;
    private readonly _elementRef;
    private readonly _resizeService;
    /** Define a the dataset to display */
    dataset: ReadonlyArray<NestedDonutChartData>;
    /** Define the maximum range of the arcs */
    max: number;
    /** Define the thickness of each arc */
    thickness: number;
    /** Define the spacing of each arc */
    spacing: number;
    /** Define the track color */
    trackColor: string | ThemeColor;
    /** Determine if we should show the hover effect */
    disableHover: boolean;
    /** Determine if we should show a tooltip on arc hover */
    disableTooltip: boolean;
    /** Determine the position of the tooltip */
    tooltipPlacement: AnchorPlacement;
    /** Set the duration of the animation */
    animationDuration: number;
    /** Emit whenever an arc is clicked */
    itemClick: EventEmitter<NestedDonutChartData>;
    /** Access the SVG element */
    _chartElement: ElementRef;
    /** Allow custom tooltip template */
    _customTooltip: TemplateRef<NestedDonutChartData>;
    /** Indicate if the tooltip should be visible */
    _tooltipVisible: boolean;
    /** Store the tooltip x position */
    _tooltipX: number;
    /** Store the tooltip y position */
    _tooltipY: number;
    /** Store the context to provide to the tooltip */
    _tooltipContext: NestedDonutChartData;
    /** Determine the radius of the chart based on the specified size */
    get _radius(): number;
    /**
     * Get the size of the chart. The chart will always be square to
     * the size will be the smaller of the width/height properties
     */
    get _size(): number;
    /** Store the selection when the arcs will be drawn */
    private _arcLayer;
    /** Store the selection when the tracks will be drawn */
    private _trackLayer;
    /** Store the arc selection */
    private _arcs;
    /** Store the tracks selection */
    private _tracks;
    /** Store the previously processed data */
    private _arcData;
    /** Determine if the intial render has taken place */
    private _isInitialized;
    /** Unsubscribe from all observables automatically */
    private readonly _onDestroy;
    /** Perform the initial render */
    ngOnInit(): void;
    /** Any time an input changes we must re-render the chart */
    ngOnChanges(): void;
    ngOnDestroy(): void;
    /** Inset the content so it never overlaps the arcs */
    _getContentInset(): number;
    /** Get the dimensions of the content area */
    _getContentSize(): number;
    /** Get the dataset formated in an accessible manner */
    _getAriaLabel(): string;
    /**
     * Display the tracks and arcs defined by the dataset.
     * We also provide the transition configuration so anytime the dataset
     * changes we will animate the update.
     */
    private render;
    /** Get the interpolation function based on the new and previous angle */
    private getArcTween;
    /** Get the arc layout for a specific item in the dataset */
    private getArc;
    /**
     * Get the track arc layout for a specific item in the dataset.
     * This will match the arc of that represents the actual data
     * however the endAngle will always be a complete circle
     */
    private getTrackArc;
    /**
     * Get the radius of an arc. This is calculated
     * based on the chart radius that has been defined,
     * minus the thickness defined, then taking into account
     * the depth of the arc and the spacing between each arc.
     */
    private getArcRadius;
    /**
     * Map the dataset to the NestedDonutChartArc interface
     */
    private getChartData;
    /** Convert the data value to radians */
    private getAngle;
    /**
     * Get the color of the arc, this may be a CSS color value, the name of a color
     * from the color set or a ThemeColor object. We return this as a rgba color to
     * support the alpha channel
     */
    private getColor;
    /** If no track color is specified then default to a specific color based on the active colorset */
    private getTrackColor;
    /** Define the on hover event */
    private onArcMouseEnter;
    /** Update the tooltip position on mouse move */
    private onArcMouseMove;
    /** Define the on hover out event */
    private onArcMouseLeave;
    static ɵfac: i0.ɵɵFactoryDeclaration<NestedDonutChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NestedDonutChartComponent, "ux-nested-donut-chart", never, { "dataset": { "alias": "dataset"; "required": false; }; "max": { "alias": "max"; "required": false; }; "thickness": { "alias": "thickness"; "required": false; }; "spacing": { "alias": "spacing"; "required": false; }; "trackColor": { "alias": "trackColor"; "required": false; }; "disableHover": { "alias": "disableHover"; "required": false; }; "disableTooltip": { "alias": "disableTooltip"; "required": false; }; "tooltipPlacement": { "alias": "tooltipPlacement"; "required": false; }; "animationDuration": { "alias": "animationDuration"; "required": false; }; }, { "itemClick": "itemClick"; }, ["_customTooltip"], ["*"], true, never>;
}
interface NestedDonutChartData {
    name: string;
    value: number;
    color: ThemeColor | string;
    data?: {
        [key: string]: unknown;
    };
}
interface NestedDonutChartArc extends NestedDonutChartData {
    index: number;
    startAngle: number;
    endAngle: number;
    previousEndAngle: number;
}

declare class NestedDonutChartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NestedDonutChartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NestedDonutChartModule, never, [typeof i2.CommonModule, typeof ColorServiceModule, typeof TooltipModule, typeof ResizeModule, typeof NestedDonutChartComponent], [typeof NestedDonutChartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NestedDonutChartModule>;
}

declare class NotificationService {
    private readonly _colorService;
    /**
       *  Sets the order in which notifications are displayed:
          `above` - newer notifications will appear above older ones.
          `below` - newer notifications will appear below older ones.
       */
    direction: NotificationListDirection;
    /**
     * The list of notifications including notifications that have been dismissed
     */
    notifications$: BehaviorSubject<NotificationRef[]>;
    /**
     * Access the list of notifications as an array
     */
    get notifications(): NotificationRef[];
    /**
     * Define the default set of notification options
     */
    options: NotificationOptions;
    /**
     * This function should be called to show a notification.
     * It should be given a TemplateRef containing the content to be displayed.
     * @param templateRef - A TemplateRef containing the content to be displayed
     * @param options - The properties to configure the notification.
     * @param context - The context passed to the notification TemplateRef. This can be accessed by adding a let-data="data" to the ng-template element.
     */
    show(templateRef: TemplateRef<void>, options?: NotificationOptions, context?: {
        [key: string]: unknown;
    }): NotificationRef;
    /**
     * This function will return a list of all the notifications that have been shown.
     */
    getHistory(): NotificationRef[];
    /**
     * This function can be called to dismiss a notification. It should be passed the object to dismiss.
     * @param notificationRef - The notification that should be dismissed
     */
    dismiss(notificationRef: NotificationRef): void;
    /**
     * This function will dismiss any currently visible notifications.
     */
    dismissAll(): void;
    /** Remove the notification from the screen and from the notification history */
    remove(notificationRef: NotificationRef): void;
    /** Remove all notifications from the screen and from the notification history */
    removeAll(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NotificationService>;
}
interface NotificationRef extends NotificationOptions {
    /** The content to display in the notification */
    templateRef: TemplateRef<void>;
    /** The datestamp to display in the notification */
    date: Date;
    /** Indicated whether or not the notification has been dismissed or not */
    visible?: boolean;
    /** Additional data passed as template context to the notification */
    data: {
        [key: string]: unknown;
    };
}
interface NotificationOptions {
    /** The duration the notification should display for before it is automatically dismissed */
    duration: number;
    /** The height of the notification */
    height?: number;
    /** The spacing between each notification */
    spacing?: number;
    /** The background color of the notification */
    backgroundColor?: string;
    /** The color of the notification icon */
    iconColor?: string;
}
type NotificationListDirection = 'above' | 'below';

declare class NotificationListComponent implements AfterViewInit, OnChanges, OnDestroy {
    private readonly _notificationService;
    private readonly _changeDetectorRef;
    private readonly _renderer;
    /**
       *  Sets the order in which notifications are displayed:
          `above` - newer notifications will appear above older ones.
          `below` - newer notifications will appear below older ones.
       */
    set direction(direction: NotificationListDirection);
    /** Sets the position of the list of notifications within the browser window. */
    position: NotificationListPostion;
    /** The list of notifications that have not been dismissed */
    notifications$: Observable<NotificationRef[]>;
    /** Store the bottom position of the notification list */
    _bottom: number;
    /** Store a list of all element refs */
    _elements: QueryList<ElementRef>;
    /** Filter out any hidden notifications */
    private get _notifications();
    /** Unsubscribe from all subscriptions on component destroy */
    private readonly _onDestroy;
    ngAfterViewInit(): void;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    private applyElementPositions;
    private updateListPosition;
    /** Get the height of the notification, including spacing if configured. */
    private getNotificationHeightInPixels;
    /** Get the total height of the element including margins. */
    private getElementOuterHeightInPixels;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationListComponent, "ux-notification-list", never, { "direction": { "alias": "direction"; "required": false; }; "position": { "alias": "position"; "required": false; }; }, {}, never, never, true, never>;
}
type NotificationListPostion = 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';

declare class NotificationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NotificationModule, never, [typeof i2.CommonModule, typeof ColorServiceModule, typeof NotificationListComponent], [typeof NotificationListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NotificationModule>;
}

declare class OrganizationChartComponent<T> implements AfterViewInit, OnChanges, OnDestroy {
    private readonly _resizeService;
    private readonly _injector;
    private readonly _elementRef;
    private readonly _appRef;
    private readonly _viewContainerRef;
    private readonly _renderer;
    private readonly _focusIndicator;
    private readonly _ngZone;
    /** Define the root node of the chart */
    dataset: OrganizationChartNode<T>;
    /** Define the presentation of the connectors */
    connector: OrganizationChartConnector;
    /** Define the width of a node */
    nodeWidth: number;
    /** Define the height of a node */
    nodeHeight: number;
    /** Define the duration of the transition animations */
    duration: number;
    /** Define the vertical space between nodes */
    verticalSpacing: number;
    /** Define whether or not we can reveal additional parents */
    showReveal: boolean;
    /** Define the aria label for the reveal button */
    revealAriaLabel: string;
    /** Defines whether nodes can be toggled or not */
    set toggleNodesOnClick(toggleNodesOnClick: boolean);
    get toggleNodesOnClick(): boolean;
    /** Programmatically select an item */
    set selected(selected: OrganizationChartNode<T>);
    /** Emit whenever a node is selected */
    selectedChange: EventEmitter<OrganizationChartNode<T>>;
    /** Emit whenever the reveal button is pressed */
    reveal: EventEmitter<void>;
    /** Emit when the transition ends */
    transitionEnd: EventEmitter<void>;
    /** Get the template for the node content */
    revealTemplate: TemplateRef<void>;
    /** Get the template for the node content */
    nodeTemplate: TemplateRef<OrganizationChartNodeContext<T>>;
    /** Access the reveal button element */
    revealElement: ElementRef;
    /** Access the container element for the links */
    linksContainer: ElementRef;
    /** Access the container element for the nodes */
    nodesContainer: ElementRef;
    private _toggleNodesOnClick;
    /** Store the internal selected node */
    private _selected;
    /** Store a flattened array of nodes */
    private _nodeLayout;
    /** Store a flattened array of links */
    private _linkLayout;
    /** Store the links selection */
    private _linksContainer;
    /** Store the links selection */
    private _nodesContainer;
    /** Store all the node elements */
    private _nodes;
    /** Store all the link paths */
    private _links;
    /** Store the zoom behavior */
    private _zoom;
    /** Store the current layout */
    private _layout;
    /** Store the current width of the chart */
    private _width;
    /** Store the current height of the chart */
    private _height;
    /** Store the portal/outlets associated with some data */
    private readonly _portals;
    /** Store the focus indicators associated with nodes */
    private readonly _indicators;
    /** Store whether or not a transition is in progress */
    private _isTransitioning;
    /** Store whether or not a camera pan is in progress */
    private _isPanning;
    /** Determine if the component is initialised */
    private _isInitialised;
    /** Determine if the connector type has changed since the last render */
    private _hasConnectorChanged;
    /** Store the currently focused node if there is one */
    private _focused;
    /** Store any selection made before the chart is initialised */
    private _pendingSelection;
    /** Automatically unsubscribe from all subscriptions on destroy */
    private readonly _onDestroy;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    /** Perform the actual rendering of the chart */
    render(): void;
    /** Select a specified node */
    select(node: OrganizationChartNode<T> | HierarchyPointNode<OrganizationChartNode<T>>): void;
    /** Deselect the currently selected node */
    private deselect;
    /** Toggle the collapsed state of a node */
    toggle(node: OrganizationChartNode<T> | HierarchyPointNode<OrganizationChartNode<T>>): void;
    /** Expand a node */
    expand(node: OrganizationChartNode<T> | HierarchyPointNode<OrganizationChartNode<T>>): void;
    /** Collapse a node */
    collapse(node: OrganizationChartNode<T> | HierarchyPointNode<OrganizationChartNode<T>>): void;
    /** Move a specific node to the center of the screen */
    centerNode(node: OrganizationChartNode<T> | HierarchyPointNode<OrganizationChartNode<T>>, axis?: OrganizationChartAxis, animate?: boolean): void;
    /** Explicity set the position of the camera */
    setCameraPosition(x: number, y: number, animate?: boolean): void;
    /** Move the camera an amount from its current position */
    moveCamera(x: number, y: number, animate?: boolean): void;
    /** Focus a given node */
    focus(node: OrganizationChartNode<T>): void;
    /** Focus the root node */
    _focusRootNode(): void;
    /** Destroy the outlet and portal associated with a node */
    private destroyNode;
    private updateLayout;
    /** Ensure the selections stay in sync with the view */
    private updateSelections;
    /** Render the content of the node based on the template provided */
    private renderNodeTemplate;
    /** Handle any zoom events (we use zoom for panning behaviour) */
    private applyCameraPosition;
    /** Get the data in with the required layout information */
    private getLayout;
    /** Determine how much horizontal spacing should be between nodes */
    private getNodeSpacing;
    /** Ensure we consistently use the HierarchyPoint data structure */
    private coercePointNode;
    private coerceDataNode;
    /** Handle chart resize events */
    private onResize;
    /** Deteremine if a node is expanded or collapsed */
    private isExpanded;
    /** Get the current position of the camera */
    private getCameraPosition;
    /** Get the SVG line definition for each link */
    private getLinkPath;
    /** Get the link path line defintion when the link is collapsing */
    private getCollapsedLinkPath;
    /** Create a dynamic region that Angular can insert into */
    private createPortalOutlet;
    /** Make the appropriate node tabbable and update aria attributes */
    private setNodeAttributes;
    /** Get the element that represents a given node */
    private getNodeElement;
    /** Get the element that represents a given node */
    private getNodeData;
    /** Handle click events */
    private onClick;
    /** Handle keyboard events */
    private onKeydown;
    /** When a node receives focus */
    private onFocus;
    /** Move focus to the parent node */
    private focusParent;
    /** Move focus to the child node */
    private focusChild;
    /** Move focus to the sibling on the left */
    private focusPreviousSibling;
    /** Move focus to the sibling on the right */
    private focusNextSibling;
    /** Focus a given node */
    private focusNode;
    /** Determine if a node is fully visible within the viewport */
    private isNodeInViewport;
    /** Determine if a node is fully outside of the viewport */
    private isNodeOutsideViewport;
    /** Determine how far a node is from being within the viewport */
    private getDistanceFromViewport;
    /** Begin monitoring the element focus so we only show styling when navigated by keyboard */
    private monitorFocus;
    private ensureNodesAreVisible;
    /** Expand all parent nodes */
    private expandParents;
    /** Get the parent of a given node */
    private getParent;
    /** Get a flat array of all the nodes childrent */
    private getAllChildren;
    static ngAcceptInputType_toggleNodesOnClick: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationChartComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrganizationChartComponent<any>, "ux-organization-chart", never, { "dataset": { "alias": "dataset"; "required": false; }; "connector": { "alias": "connector"; "required": false; }; "nodeWidth": { "alias": "nodeWidth"; "required": false; }; "nodeHeight": { "alias": "nodeHeight"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "verticalSpacing": { "alias": "verticalSpacing"; "required": false; }; "showReveal": { "alias": "showReveal"; "required": false; }; "revealAriaLabel": { "alias": "revealAriaLabel"; "required": false; }; "toggleNodesOnClick": { "alias": "toggleNodesOnClick"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; }, { "selectedChange": "selectedChange"; "reveal": "reveal"; "transitionEnd": "transitionEnd"; }, ["revealTemplate", "nodeTemplate"], never, true, never>;
}
interface OrganizationChartNode<T> {
    id: number | string;
    data?: T;
    children?: ReadonlyArray<OrganizationChartNode<T>>;
    expanded?: boolean;
}
interface OrganizationChartNodeContext<T> {
    data: T;
    node: OrganizationChartNode<T>;
    focused: boolean;
}
interface OrganizationChartPortalRef {
    outlet: DomPortalOutlet;
    portal: TemplatePortal;
}
type OrganizationChartConnector = 'elbow' | 'curved';
declare enum OrganizationChartAxis {
    Horizontal = 0,
    Vertical = 1,
    Both = 2
}

declare class OrganizationChartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationChartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrganizationChartModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof IconModule, typeof ResizeModule, typeof OrganizationChartComponent], [typeof OrganizationChartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrganizationChartModule>;
}

declare class TabComponent implements OnInit, OnDestroy, OnChanges {
    private readonly _tabsetService;
    private readonly _changeDetector;
    private readonly _tabset;
    /** Define the tab unique id */
    set id(id: string);
    get id(): string;
    /** Define the active state of this tab */
    set active(active: boolean);
    /** Define if this tab is disabled */
    disabled: boolean;
    /** Define the tab heading */
    heading: string;
    /** Define the tab router path */
    route: string | unknown[];
    /** Define the tab router additional parameters */
    routerLinkExtras: NavigationExtras;
    /** provide a custom class for the tab */
    customClass: string;
    /** Emits when the active state changes. */
    activeChange: EventEmitter<boolean>;
    /** Emit when this tab is selected */
    activated: EventEmitter<void>;
    /** Emit when this tab is deselected */
    deactivated: EventEmitter<void>;
    /** Store a custom header templateRef */
    headingRef: TemplateRef<void>;
    _active: boolean;
    _id: string;
    /** Unsubscribe from all subscriptions when component is destroyed */
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    activate(): void;
    deactivate(): void;
    /**
     * Update the internal active state and emit appropriate events.
     */
    private setActive;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabComponent, "ux-tab", never, { "id": { "alias": "id"; "required": false; }; "active": { "alias": "active"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "heading": { "alias": "heading"; "required": false; }; "route": { "alias": "route"; "required": false; }; "routerLinkExtras": { "alias": "routerLinkExtras"; "required": false; }; "customClass": { "alias": "customClass"; "required": false; }; }, { "activeChange": "activeChange"; "activated": "activated"; "deactivated": "deactivated"; }, ["headingRef"], ["*"], true, never>;
}

declare class TabsetService {
    /** Store the list of tabs */
    tabs: ReadonlyArray<TabComponent>;
    activeTab$: BehaviorSubject<TabComponent>;
    /** Store the manual state */
    manual: boolean;
    /** Update the array of tabs - required to preserve order */
    update(tabs: TabComponent[]): void;
    /** Select a tab (from user input) */
    select(tab: TabComponent): void;
    /** Set tab active state */
    setTabActive(tab: TabComponent): void;
    /** Determine if there is a selected tab */
    isTabActive(): boolean;
    /** Select the first non-disabled tab */
    selectFirstTab(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabsetService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TabsetService>;
}

declare class TabsetComponent implements AfterViewInit, OnDestroy {
    readonly _tabset: TabsetService;
    private readonly _changeDetector;
    /** Determine if the appearance of the tabset */
    minimal: boolean;
    /** Determine if the tabset should appear stacked */
    stacked: 'left' | 'right' | 'none';
    /** Determine if we want to manually update the active state */
    set manual(manual: boolean);
    /** Provide am aria label for the tabset */
    ariaLabel: string;
    /** Access all the children */
    _tabs: QueryList<TabComponent>;
    /** Remove subscriptions on destroy */
    private readonly _onDestroy$;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    selectTab(tab: number | TabComponent): void;
    handleKeyDown(event: KeyboardEvent, tab: HTMLElement): void;
    markForCheck(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabsetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabsetComponent, "ux-tabset", never, { "minimal": { "alias": "minimal"; "required": false; }; "stacked": { "alias": "stacked"; "required": false; }; "manual": { "alias": "manual"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; }, {}, ["_tabs"], ["*"], true, never>;
}

declare class TabHeadingDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabHeadingDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TabHeadingDirective, "[uxTabHeading]", never, {}, {}, never, never, true, never>;
}

declare class TabsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TabsetModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof i3$1.RouterModule, typeof TabsetComponent, typeof TabComponent, typeof TabHeadingDirective], [typeof TabsetComponent, typeof TabComponent, typeof TabHeadingDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TabsetModule>;
}

interface PageHeaderIconMenu {
    icon: string;
    label?: string;
    badge?: number | string;
    select?: (menu: PageHeaderIconMenu) => void;
    dropdown?: PageHeaderIconMenuDropdownItem[];
}
interface PageHeaderIconMenuDropdownItem {
    icon?: string;
    title: string;
    subtitle?: string;
    header?: boolean;
    divider?: boolean;
    select?: () => void;
}

type PageHeaderNavigation = PageHeaderNavigationItem | PageHeaderNavigationDropdownItem;

declare class PageHeaderNavigationItemComponent implements AfterViewInit, OnDestroy, FocusableOption {
    readonly elementRef: ElementRef<any>;
    private readonly _pageHeaderService;
    private readonly _navigationService;
    /** Access the data for this dropdown item */
    set item(item: PageHeaderNavigationItem);
    get item(): PageHeaderNavigationItem;
    /** Store the secondary state */
    secondary$: BehaviorSubject<boolean>;
    /** Store the open state of the item dropdown */
    isOpen: boolean;
    /** Store the item data */
    _item: PageHeaderNavigationItem;
    /** Store the icon type */
    _iconType: IconType;
    /** Update the tabindex based on keyboard input */
    _tabindex: Observable<number>;
    /** Access the navigation button element */
    navigationBtn: ElementRef;
    /** Unsubscribe when the component is destroyed */
    private readonly _onDestroy;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    focus(): void;
    select(): void;
    onKeydown(event: KeyboardEvent, target: HTMLElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderNavigationItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageHeaderNavigationItemComponent, "ux-page-header-horizontal-navigation-item", never, { "item": { "alias": "item"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PageHeaderNavigationComponent implements AfterViewInit, OnDestroy {
    readonly elementRef: ElementRef<HTMLElement>;
    readonly resizeService: ResizeService;
    private readonly _navigationService;
    private readonly _pageHeaderService;
    menuItems: QueryList<PageHeaderNavigationItemComponent>;
    items$: BehaviorSubject<PageHeaderNavigationItem[]>;
    indicatorVisible: boolean;
    indicatorX: number;
    indicatorWidth: number;
    private readonly _onDestroy;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    updateSelectedIndicator(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderNavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageHeaderNavigationComponent, "ux-page-header-horizontal-navigation", never, {}, {}, never, never, true, never>;
}
interface PageHeaderNavigationItem {
    icon?: string;
    title: string;
    selected?: boolean;
    routerLink?: string | unknown[];
    routerExtras?: NavigationExtras;
    select?: (item: PageHeaderNavigationItem) => void;
    children?: PageHeaderNavigationDropdownItem[];
    parent?: PageHeaderNavigation;
    disabled?: boolean;
    id?: string;
}
interface PageHeaderNavigationDropdownItem {
    title: string;
    selected?: boolean;
    routerLink?: string | unknown[];
    routerExtras?: NavigationExtras;
    select?: (item: PageHeaderNavigationDropdownItem) => void;
    children?: PageHeaderNavigationDropdownItem[];
    parent?: PageHeaderNavigation;
    disabled?: boolean;
    id?: string;
}
interface PageHeaderSecondaryNavigationItem extends PageHeaderNavigationDropdownItem {
}

type PageHeaderNavigationAlignment = 'left' | 'right' | 'center';
declare class PageHeaderComponent {
    private readonly _colorService;
    private readonly _pageHeaderService;
    /** The path to an image to display as the product logo in the left corner. */
    logo: string;
    /** The product acronym to display in the left corner. This will only be displayed if logo is unset; otherwise it will be used as the alt text for the logo. */
    header: string;
    /** The optional header to display on the left side of the masthead. */
    subheader: string;
    /** The alignment of the primary navigation tabs. */
    alignment: PageHeaderNavigationAlignment;
    /** Determines whether or not to display the page header in the regular or condensed form. */
    condensed: boolean;
    /** The list of icon menus to display in the top right area of the page header. */
    iconMenus: PageHeaderIconMenu[];
    /** Determines whether or not a back button should be visible in the page header. */
    backVisible: boolean;
    /** The alignment of the secondary navigation tabs. */
    secondaryNavigationAlignment: PageHeaderNavigationAlignment;
    /** If set, the first child item will get selected when the parent item is selected. */
    set secondaryNavigationAutoselect(value: boolean);
    get secondaryNavigationAutoselect(): boolean;
    /** The primary navigation tabs. Use the children property in combination with [secondaryNavigation]="true" to include secondary navigation tabs. */
    set items(items: PageHeaderNavigationItem[]);
    /** Whether to show a second level of navigation for any items with children. */
    set secondaryNavigation(enabled: boolean);
    get secondaryNavigation(): boolean;
    /** The optional set of breadcrumbs to display on the left side of the masthead. */
    set crumbs(crumbs: Breadcrumb[]);
    get crumbs(): Breadcrumb[];
    /**
     * The style of the breadcrumbs.
     *   - standard: The breadcrumbs use the same styling as the navigation tabs.
     *   - small: The breadcrumbs use a smaller font, and case is not adjusted.
     */
    crumbsStyle: 'standard' | 'small';
    /** The logo background color. This can either be the name of a color from the color palette, or a CSS color value. */
    set logoBackground(color: string);
    get logoBackground(): string;
    /** The logo text color, when a product acronym is specified via header. This can either be the name of a color from the color palette, or a CSS color value. */
    set logoForeground(color: string);
    get logoForeground(): string;
    get _hasLogoClick(): boolean;
    /** Emit whenever the back button is clicked */
    backClick: EventEmitter<MouseEvent>;
    /** Emit whenever the product logo in the left corner is clicked. */
    logoClick: EventEmitter<Event>;
    /** Access a custom subheader template */
    subheaderTemplate: TemplateRef<void>;
    /** Define a custom logo template  */
    logoTemplate: TemplateRef<void>;
    /** Define a leading content secondary navigation template */
    secondaryNavigationLeadingContentTemplate: TemplateRef<void>;
    /** Define a trailing content secondary navigation template */
    secondaryNavigationTrailingContentTemplate: TemplateRef<void>;
    /** Access all the custom menu TemplateRefs */
    customMenus: QueryList<TemplateRef<void>>;
    /** The currently selected page header item */
    selected$: BehaviorSubject<PageHeaderNavigationItem>;
    /** The currently selected root menu item - this may be different from selected$ if a child menu item is selected */
    selectedRoot$: BehaviorSubject<PageHeaderNavigationItem>;
    private _crumbs;
    private _logoBackground;
    private _logoForeground;
    select(item: PageHeaderNavigation, navigate: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageHeaderComponent, "ux-page-header", ["ux-page-header"], { "logo": { "alias": "logo"; "required": false; }; "header": { "alias": "header"; "required": false; }; "subheader": { "alias": "subheader"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; "condensed": { "alias": "condensed"; "required": false; }; "iconMenus": { "alias": "iconMenus"; "required": false; }; "backVisible": { "alias": "backVisible"; "required": false; }; "secondaryNavigationAlignment": { "alias": "secondaryNavigationAlignment"; "required": false; }; "secondaryNavigationAutoselect": { "alias": "secondaryNavigationAutoselect"; "required": false; }; "items": { "alias": "items"; "required": false; }; "secondaryNavigation": { "alias": "secondaryNavigation"; "required": false; }; "crumbs": { "alias": "crumbs"; "required": false; }; "crumbsStyle": { "alias": "crumbsStyle"; "required": false; }; "logoBackground": { "alias": "logoBackground"; "required": false; }; "logoForeground": { "alias": "logoForeground"; "required": false; }; }, { "backClick": "backClick"; "logoClick": "logoClick"; }, ["subheaderTemplate", "logoTemplate", "secondaryNavigationLeadingContentTemplate", "secondaryNavigationTrailingContentTemplate", "customMenus"], never, true, never>;
}

declare class PageHeaderIconMenuComponent {
    /** Get the data for this icon menu */
    menu: PageHeaderIconMenu;
    select(item: PageHeaderIconMenu | PageHeaderIconMenuDropdownItem): void;
    keydownHandler(item: PageHeaderIconMenu | PageHeaderIconMenuDropdownItem, event: KeyboardEvent): void;
    _getIconType(identifier: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderIconMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageHeaderIconMenuComponent, "ux-page-header-icon-menu", never, { "menu": { "alias": "menu"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PageHeaderCustomMenuDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderCustomMenuDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PageHeaderCustomMenuDirective, "[uxPageHeaderCustomMenu], [uxPageHeaderCustomItem]", never, {}, {}, never, never, true, never>;
}

declare class PageHeaderNavigationDropdownItemComponent {
    private readonly _pageHeaderService;
    /** Access the data for this item */
    item: PageHeaderNavigationDropdownItem;
    select(item: PageHeaderNavigationDropdownItem): void;
    keydownHandler(event: KeyboardEvent, item: PageHeaderNavigationDropdownItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderNavigationDropdownItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageHeaderNavigationDropdownItemComponent, "ux-page-header-horizontal-navigation-dropdown-item", ["ux-page-header-horizontal-navigation-dropdown-item"], { "item": { "alias": "item"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PageHeaderNavigationSecondaryItemDirective implements OnInit, OnDestroy {
    private readonly _pageHeaderService;
    item: PageHeaderNavigationItem;
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderNavigationSecondaryItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PageHeaderNavigationSecondaryItemDirective, "[uxPageHeaderNavigationSecondaryItem]", never, { "item": { "alias": "uxPageHeaderNavigationSecondaryItem"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PageHeaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PageHeaderModule, never, [typeof i1.A11yModule, typeof AccessibilityModule, typeof BreadcrumbsModule, typeof ColorServiceModule, typeof i2.CommonModule, typeof IconModule, typeof MenuModule, typeof ResizeModule, typeof TabsetModule, typeof i3$1.RouterModule, typeof PageHeaderComponent, typeof PageHeaderIconMenuComponent, typeof PageHeaderCustomMenuDirective, typeof PageHeaderNavigationComponent, typeof PageHeaderNavigationItemComponent, typeof PageHeaderNavigationDropdownItemComponent, typeof PageHeaderNavigationSecondaryItemDirective], [typeof PageHeaderComponent, typeof PageHeaderCustomMenuDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PageHeaderModule>;
}

declare const PAGINATION_CONTROL_VALUE_ACCESSOR: {
    provide: i0.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: i0.Type<any>;
    multi: boolean;
};
declare class PaginationComponent implements OnInit, ControlValueAccessor {
    private readonly _changeDetector;
    /** Specify if we should show the next and previous buttons */
    directionButtons: boolean;
    /** Limit the number of pages shown at any given time */
    maxSize: number;
    /** Specify if the component should be disabled */
    disabled: boolean;
    /** Apply classes to the bootstrap pagination element */
    classes: string;
    /** Allow custom class to be added to page buttons */
    pageBtnClass: string;
    /** Aria Label for the component navigation */
    ariaLabel: string;
    /** Aria label for the previous button */
    previousAriaLabel: string;
    /** Aria label for the next button */
    nextAriaLabel: string;
    /** Specify the index of the active page */
    set page(page: number);
    get page(): number;
    /** Define a custom template for the previous button */
    previousBtnTemplate: TemplateRef<void>;
    /** Define a custom template for the next button */
    nextBtnTemplate: TemplateRef<void>;
    /** Specify the page size */
    set itemsPerPage(pagesize: number);
    /** Specify how many items there are in total */
    set totalItems(total: number);
    /** Emit the current page number */
    pageChange: EventEmitter<number>;
    /** Emit the total number of pages */
    numPages: EventEmitter<number>;
    /** Store a list of pages to display in the UI */
    pages: ReadonlyArray<Page>;
    /** ControlValueAccessor functions */
    onTouched: Function;
    onChange: Function;
    isKeyboardEvent: boolean;
    private _page;
    private _total;
    private _pagesize;
    get pageCount(): number;
    ngOnInit(): void;
    select(index: number): void;
    trackByFn(_index: number, item: Page): number;
    registerOnChange(fn: () => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(page: number): void;
    private getPages;
    private isPageVisible;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaginationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PaginationComponent, "ux-pagination", never, { "directionButtons": { "alias": "directionButtons"; "required": false; }; "maxSize": { "alias": "maxSize"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "classes": { "alias": "class"; "required": false; }; "pageBtnClass": { "alias": "pageBtnClass"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "previousAriaLabel": { "alias": "previousAriaLabel"; "required": false; }; "nextAriaLabel": { "alias": "nextAriaLabel"; "required": false; }; "page": { "alias": "page"; "required": false; }; "previousBtnTemplate": { "alias": "previousBtnTemplate"; "required": false; }; "nextBtnTemplate": { "alias": "nextBtnTemplate"; "required": false; }; "itemsPerPage": { "alias": "itemsPerPage"; "required": false; }; "totalItems": { "alias": "totalItems"; "required": false; }; }, { "pageChange": "pageChange"; "numPages": "numPages"; }, never, never, true, never>;
}
interface Page {
    index: number;
    visible: boolean;
}

declare class PaginationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PaginationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PaginationModule, never, [typeof i1.A11yModule, typeof AccessibilityModule, typeof i2.CommonModule, typeof FocusIfModule, typeof IconModule, typeof PaginationComponent], [typeof PaginationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PaginationModule>;
}

declare class PartitionMapSegmentEventsDirective implements AfterViewInit, OnDestroy {
    private readonly _elementRef;
    /** Emit when the segment receives focus */
    segmentFocus: EventEmitter<FocusEvent>;
    /** Emit when the segment is blurred */
    segmentBlur: EventEmitter<FocusEvent>;
    /** Unsubscribe from observables */
    private readonly _onDestroy;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * Find the parent element that is a partition map segment
     */
    private getSegmentElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<PartitionMapSegmentEventsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PartitionMapSegmentEventsDirective, "[segmentFocus],[segmentBlur]", never, {}, { "segmentFocus": "segmentFocus"; "segmentBlur": "segmentBlur"; }, never, never, true, never>;
}

declare class PartitionMapComponent implements OnInit, OnDestroy {
    private readonly _colorService;
    private readonly _elementRef;
    private readonly _changeDetector;
    private readonly _ngZone;
    private readonly _focusOrigin;
    private readonly _contrastRatio;
    private readonly _liveAnnouncer;
    private readonly _resizeService;
    private _segmentCache;
    /** Define the colors to be used for each row and the order they should appear. */
    set colors(colors: (string | ThemeColor)[][]);
    /** Determine the pixel height of collapsed segments. */
    collapsedHeight: number;
    /** Define a minimum desired pixel width for a segment. */
    minSegmentWidth: number;
    /** Define the dataset to display in the chart. */
    set dataset(dataset: Readonly<PartitionMapSegment>);
    get dataset(): Readonly<PartitionMapSegment>;
    /** Define the currently selected item. */
    set selected(selected: PartitionMapSegment);
    /** Define the function that will return the aria announcement for a given segment. */
    segmentAnnouncement: (info: PartitionMapSegmentAnnouncementInfo) => string;
    /** Emits whenever a segment is selected. */
    selectedChange: EventEmitter<PartitionMapSegment>;
    /** Access a if provided custom template */
    segmentTemplate: TemplateRef<PartitionMapCustomSegmentContext>;
    /** Store the processed segments */
    _segments: HierarchyRectangularNode<PartitionMapSegment>[];
    /** Store the current dataset */
    private _dataset;
    /** Store the specified color sequences */
    private _colors;
    /** Store the currently selected segment */
    private _selected;
    /** Store the assigned colors for each segment */
    private readonly _segmentColors;
    /** Store the visible x scale */
    private readonly _x;
    /** Store the visible y scale */
    private readonly _y;
    /** Store the visible d3 segments */
    private _segmentsSelection;
    /** Store the current focusable segment */
    private _focusableSegment;
    /** Store an item awaiting selection */
    private _awaitingSelection;
    /** Store the width of the chart on resize to avoid any reflow */
    private _width;
    /** Store the height of the chart on resize to avoid any reflow */
    private _height;
    /** Flag to determine when the inputs have all been bound */
    private _initialized;
    /** Unsubscribe from any observables on destroy */
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Handle segment clicks */
    _onSegmentSelect(segment: HierarchyRectangularNode<PartitionMapSegment>): void;
    /** Get the background color for a given segment */
    _getBackgroundColor(segment: HierarchyRectangularNode<PartitionMapSegment>): string;
    /** Get the tab index of a segment */
    _getTabIndex(segment: HierarchyRectangularNode<PartitionMapSegment>): number;
    /** Shift focus to the parent segment */
    _focusParent(segment: HierarchyRectangularNode<PartitionMapSegment>): void;
    /** Shift focus to the child segment */
    _focusChild(segment: HierarchyRectangularNode<PartitionMapSegment>): void;
    /** Shift focus to the sibling segment */
    _focusSibling(segment: HierarchyRectangularNode<PartitionMapSegment>, delta: number): void;
    _focusFirstSibling(segment: HierarchyRectangularNode<PartitionMapSegment>): void;
    _focusLastSibling(segment: HierarchyRectangularNode<PartitionMapSegment>): void;
    /** Determine if a given segment is currently collapsed */
    _isCollapsed(segment: HierarchyRectangularNode<PartitionMapSegment>): boolean;
    /** Determine if a given segment is currently selected */
    _isSelected(segment: HierarchyRectangularNode<PartitionMapSegment>): boolean;
    /** Get the contast color class for the segment */
    _getContrastColor(segment: HierarchyRectangularNode<PartitionMapSegment>): string;
    /** Provide an aria announcement when the node is focused */
    _onFocus(segment: HierarchyRectangularNode<PartitionMapSegment>): void;
    /** Determine if the content is smaller than the width of an ellipsis */
    _getSegmentContentHidden(segment: HierarchyRectangularNode<PartitionMapSegment>): boolean;
    /** Get the value of a segment based on the accumulation of all child values */
    _getSegmentValue(segment: PartitionMapSegment): number;
    _getContext(segment: HierarchyRectangularNode<PartitionMapSegment>): PartitionMapCustomSegmentContext;
    trackByIndex(index: number): number;
    /** Convert the public facing data structure into the layout format we require */
    private setDataset;
    /** Update the size and position of the segments */
    private updateSegments;
    private cacheSegment;
    private getSegmentCache;
    /**
     * Get the X position of a given segment. The X position can be determined
     * by calculating the width of every sibling segment to the left of it
     */
    private getSegmentX;
    /** Calculate width based of each segment */
    private getSegmentWidth;
    /** Return the X position of the segment in a normalized form based on the specifiec domain */
    private getNormalizedSegmentX;
    /** Return the Y position of the segment in a normalized form based on the specifiec domain */
    private getNormalizedSegmentY;
    /** Return the width of the segment in a normalized form based on the specifiec domain */
    private getNormalizedSegmentWidth;
    /** Return the height of the segment in a normalized form based on the specifiec domain */
    private getNormalizedSegmentHeight;
    /**
     * As parent segments collapse they increase in size, as the content is centered this can
     * cause the content to appear either mis-aligned or off screen. We can calculate the padding
     * required to always ensure the content appears visibly centered within the node.
     */
    private getSegmentPaddingRight;
    private getSegmentPaddingLeft;
    /**
     * This function returns the value for each segment. Leaf segments will have a value property which we can simply return, however
     * non-leaf segments should get their values based on the leaf segments that are children, in which case we can return 0
     */
    private getSegmentValue;
    /** Get the total height of all the collapse rows */
    private getTotalCollapsedHeight;
    /** Get the collapsed height in percentage format */
    private getCollapsedHeight;
    /** Determine if a given segment is currently visible based on the selected segment */
    private isVisible;
    /** Update the focusable item and perform a focus */
    private focusSegment;
    /** Get all the segments at a given depth */
    private getAllSiblings;
    private getHierarchyNodeFromSegment;
    /** Select a specified segment */
    private select;
    /** Normalize the available colors to a string[][] from portentially a ThemeColor[][] */
    private getColorSequence;
    /** Determine if a segment is a descendant of the currently selected item */
    private isDescendantOfSelected;
    /**
     * We have an option to allow a minimum desired width for items. This will
     * allow us to attempt to determine the size a segment would be accounting for very
     * small segments that have their widths artifically increased to make them more visible
     */
    private getDistributionModifier;
    /** Get the default announcement when a segment is focused */
    private defaultSegmentAnnouncement;
    static ɵfac: i0.ɵɵFactoryDeclaration<PartitionMapComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PartitionMapComponent, "ux-partition-map", never, { "colors": { "alias": "colors"; "required": false; }; "collapsedHeight": { "alias": "collapsedHeight"; "required": false; }; "minSegmentWidth": { "alias": "minSegmentWidth"; "required": false; }; "dataset": { "alias": "dataset"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "segmentAnnouncement": { "alias": "segmentAnnouncement"; "required": false; }; }, { "selectedChange": "selectedChange"; }, ["segmentTemplate"], never, true, never>;
}
interface PartitionMapSegmentBase {
    name: string;
    data?: {
        [key: string]: any;
    };
}
interface PartitionMapSegmentWithChildren extends PartitionMapSegmentBase {
    children: ReadonlyArray<PartitionMapSegment>;
}
interface PartitionMapSegmentWithValue extends PartitionMapSegmentBase {
    value: number;
}
/** This union type allows us to ensure that a partition map segment has either children or a value */
type PartitionMapSegment = PartitionMapSegmentWithChildren | PartitionMapSegmentWithValue;
/** Partition map custom segment template context */
interface PartitionMapCustomSegmentContext {
    segment: PartitionMapSegment;
    color: string;
    value: number;
    expanded: boolean;
    depth: number;
    children: PartitionMapCustomSegmentContext[];
}
/** An object of this interface is passed to the announcer function */
interface PartitionMapSegmentAnnouncementInfo {
    item: PartitionMapSegment;
    value: number;
    parents: PartitionMapSegment[];
    collapsed: boolean;
    selected: boolean;
}

declare class PartitionMapModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PartitionMapModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PartitionMapModule, never, [typeof i1.A11yModule, typeof AccessibilityModule, typeof i2.CommonModule, typeof ColorServiceModule, typeof ResizeModule, typeof PartitionMapComponent, typeof PartitionMapSegmentEventsDirective], [typeof PartitionMapComponent, typeof PartitionMapSegmentEventsDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PartitionMapModule>;
}

declare class ProgressBarComponent {
    value: number;
    min: number;
    max: number;
    indeterminate: boolean;
    trackColor: string;
    barColor: string;
    /** When indeteminate we should omit the valuenow label */
    get valueNow(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressBarComponent, "ux-progress-bar", never, { "value": { "alias": "value"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "indeterminate": { "alias": "indeterminate"; "required": false; }; "trackColor": { "alias": "trackColor"; "required": false; }; "barColor": { "alias": "barColor"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class ProgressBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProgressBarModule, never, [typeof i2.CommonModule, typeof ProgressBarComponent], [typeof ProgressBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProgressBarModule>;
}

declare const RADIOBUTTON_VALUE_ACCESSOR: {
    provide: i0.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: i0.Type<any>;
    multi: boolean;
};
declare class RadioButtonComponent<T = unknown> implements ControlValueAccessor, OnChanges, FocusableControl {
    private readonly _changeDetector;
    private readonly _group;
    /** Provide a default unique id value for the radiobutton */
    _radioButtonId: string;
    /** Specify a unique Id for this component */
    id: string;
    /** Specify a form name for the input element */
    name: string | null;
    /** Specify the role of the input element. */
    inputRole: string;
    /** This should be a two way binding and will store the currently selected option. Each radio button in the same group should have the same value variable. */
    value: T;
    /** Specify if this is a required input */
    required: boolean;
    /** Specify the tabindex */
    tabindex: number;
    /** If set to `true` the radio button will not change state when clicked. */
    clickable: boolean;
    /** If this value is set to `true` then the radio button will be disabled */
    disabled: boolean;
    /** If set to `true` the checkbox will be displayed without a border and background. */
    simplified: boolean;
    /**
     * This should contain the value that this radio button represents. This will be stored in the value variable when the radio button is selected.
     * No two radio buttons should have the same option value within the same group of radio buttons.
     */
    option: T;
    /** Specify an aria label for the input element */
    ariaLabel: string;
    /** Specify an aria labelledby property for the input element */
    ariaLabelledby: string;
    /** Specify an aria describedby property for the input element */
    ariaDescribedby: string;
    /** Emits when the value has been changed. */
    valueChange: EventEmitter<T>;
    /** Get the focus indicator to set focus */
    _focusIndicator?: FocusIndicatorDirective;
    /** Determine if the underlying input component has been focused with the keyboard */
    _focused: boolean;
    /** Internally store the current tabindex */
    _internalTabindex: number;
    /** Used to inform Angular forms that the component has been touched */
    onTouchedCallback: () => void;
    /** Used to inform Angular forms that the component value has changed */
    onChangeCallback: (_: any) => void;
    ngOnChanges(changes: SimpleChanges): void;
    /** Select the current option */
    select(): void;
    writeValue(value: T): void;
    /** Allow Angular forms for provide us with a callback for when the input value changes */
    registerOnChange(fn: () => void): void;
    /** Allow Angular forms for provide us with a callback for when the touched state changes */
    registerOnTouched(fn: () => void): void;
    /** Allow Angular forms to disable the component */
    setDisabledState(isDisabled: boolean): void;
    /** Set the internal tab index of the radio button */
    setInternalTabindex(tabIndex: any): void;
    /** Focus the input element */
    focus(origin: FocusOrigin): void;
    setInputTabIndex(tabindex: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioButtonComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioButtonComponent<any>, "ux-radio-button", never, { "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; "inputRole": { "alias": "inputRole"; "required": false; }; "value": { "alias": "value"; "required": false; }; "required": { "alias": "required"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; "clickable": { "alias": "clickable"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "simplified": { "alias": "simplified"; "required": false; }; "option": { "alias": "option"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; }; }, { "valueChange": "valueChange"; }, never, ["*"], true, never>;
}

declare const RADIO_GROUP_CONTROL_VALUE_ACCESSOR: ExistingProvider;
declare class RadioButtonGroupDirective<T = unknown> implements ControlValueAccessor, AfterContentInit, OnDestroy {
    private readonly _changeDetector;
    /** Define the current selected value within the group */
    set value(value: T);
    /** Return the currently selected value */
    get value(): T;
    /** Emit when the currently selected value changes */
    valueChange: EventEmitter<T>;
    /** Used to inform Angular forms that the component has been touched */
    onTouched: () => void;
    /** Used to inform Angular forms that the component value has changed */
    onChange: (value: any) => void;
    _radioButtons: QueryList<RadioButtonComponent>;
    /** Unsubscribe from all subscriptions on destroy */
    private readonly _onDestroy$;
    /** Internally store the current value */
    private _value;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /** Allow Angular forms for provide us with a callback for when the input value changes */
    registerOnChange(fn: (value: any) => void): void;
    /** Allow Angular forms for provide us with a callback for when the touched state changes */
    registerOnTouched(fn: () => void): void;
    /** Allow Angular forms to give us the current value */
    writeValue(value: any): void;
    /** Allow Angular forms to disable the component */
    setDisabledState(isDisabled: boolean): void;
    /** Emit the currently selected value */
    emitChange(value: T): void;
    /** Determine and set the correct internal tabindex */
    determineAndSetInternalTabIndex(): void;
    /** Inform all child radio buttons of the latest value */
    private updateSelectedRadioButton;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioButtonGroupDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RadioButtonGroupDirective<any>, "ux-radio-button-group, [uxRadioButtonGroup]", never, { "value": { "alias": "value"; "required": false; }; }, { "valueChange": "valueChange"; }, ["_radioButtons"], never, true, never>;
}

declare class RadioButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RadioButtonModule, never, [typeof AccessibilityModule, typeof i3$2.FormsModule, typeof RadioButtonComponent, typeof RadioButtonGroupDirective], [typeof RadioButtonComponent, typeof RadioButtonGroupDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RadioButtonModule>;
}

interface SankeyLink {
    source: number | string;
    target: number | string;
    value: number;
}
interface SankeyLinkPlot {
    topLeft?: [number, number];
    topRight?: [number, number];
    bottomLeft?: [number, number];
    bottomRight?: [number, number];
}
interface SankeyLinkInteraction {
    active?: boolean;
    focus?: boolean;
}

interface SankeyNode<T> {
    id: number | string;
    data: T;
}

/**
 * This data structure represents the node
 * combined with all the the input and output
 * links that flow to and from it.
 */
interface SankeyNodeLink<T> {
    node: SankeyNode<T>;
    value: number;
    falloff: number;
    column: number;
    x: number;
    y: number;
    width: number;
    height: number;
    naturalHeight: number;
    active: boolean;
    focus: boolean;
    inputs: ReadonlyArray<SankeyLink & SankeyLinkPlot & SankeyLinkInteraction>;
    outputs: ReadonlyArray<SankeyLink & SankeyLinkPlot & SankeyLinkInteraction>;
}

declare class SankeyChart<T> {
    /** Define the nodes in the chart */
    private _nodes;
    /** Define the links in the chart */
    private _links;
    /** Store the node-links */
    private _nodeLinks;
    /** Define the minimum width of the nodes */
    private _minWidth;
    /** Define the maximum width of the nodes */
    private _maxWidth;
    /** The minimum height of a node. */
    private _minHeight;
    /** Define the width of the chart */
    private _width;
    /** Define the height of the chart */
    private _height;
    /** Define the vertical padding between nodes */
    private _spacing;
    /** Define the minimum distance from the edge of the chart */
    private readonly _padding;
    /** Define the spacing of the chart */
    spacing(spacing: number): this;
    /** Define the width of the chart */
    width(width: number): this;
    /** Define the height of the chart */
    height(height: number): this;
    /** Define the nodes */
    nodes(nodes: ReadonlyArray<SankeyNode<T>>): this;
    /** Define the links */
    links(links: ReadonlyArray<SankeyLink>): this;
    /** Define the minimum and maximum size of the nodes */
    size(minWidth: number, maxWidth: number, minHeight: number): this;
    /** Get the sizes of each column */
    columns(): number[];
    /**
     * Perform the various stages of the layout
     * in the correct order as some steps are dependant
     * on the previous layout stages.
     */
    layout(): ReadonlyArray<SankeyNodeLink<T>>;
    /** The curve equation for links */
    link(link: SankeyLink & SankeyLinkPlot): string;
    getFalloffPath(nodeLink: SankeyNodeLink<T>): string;
    /**
     * Get a `SankeyNodeLink` object from the id of a node
     */
    getNodeLink(id: string | number): SankeyNodeLink<T>;
    /** Replace the node ids with actual references */
    private getNodeLinks;
    /** Get the value for the node based on all its inputs and outputs */
    private getNodeValues;
    /**
     * We need to determine which column the node should
     * be placed in. This is determined by taking the input
     * and adding one.
     */
    private getNodeColumns;
    /** Get the width of each node */
    private getNodeWidths;
    /**
     * Scale the nodes height based on the value the represent
     */
    private getNodeHeights;
    /**
     * Recalculate node heights within height limits until they fit (if possible).
     * @throws If it is not possible to fit all nodes in the chart due to `minHeight`.
     */
    private adjustNodeHeightsToFit;
    /** Set all nodes height to be the same as the naturalHeight. */
    private setNodesToNaturalHeight;
    /**
     * Get all nodes grouped in their corresponding columns
     */
    private getColumnGroups;
    /**
     * Get the number of columns
     */
    private getColumnCount;
    /**
     * Position the nodes in their corresponding x and y positions
     */
    private getNodePositions;
    private getColumnPadding;
    private getLinkPlots;
    /** Determine the position at which a column starts */
    private getColumnPosition;
    /** Get the pixel width of a node */
    private getNodeWidth;
    /** Get the column with the greatest height (along with its height) */
    private getLargestColumn;
}

declare class SankeyNodeDirective<T> implements OnInit, OnDestroy {
    private readonly _focusManager;
    private readonly _elementRef;
    /** Access the node data */
    node: SankeyNodeLink<T>;
    /** Specify the tab index of the current item */
    tabIndex: number;
    /** Unsubscribe from all observables on destroy */
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    onClick(): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SankeyNodeDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SankeyNodeDirective<any>, "[uxSankeyNode]", never, { "node": { "alias": "uxSankeyNode"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SankeyChartComponent<T> implements OnChanges, AfterViewInit {
    private readonly _focusManager;
    private readonly _changeDetector;
    private readonly _colorService;
    /** Define the nodes to display */
    nodes: ReadonlyArray<SankeyNode<T>>;
    /** Define the links to display */
    links: ReadonlyArray<SankeyLink>;
    /** Define the headers of each column */
    columns: string[];
    /** Define the minimum width of a node */
    minWidth: number;
    /** Define the maximum width of a node */
    maxWidth: number;
    /** The minimum height of a node. */
    minHeight: number;
    /** Define the function to get the contents of a link tooltip */
    linkTooltip: (link: SankeyLink) => string;
    /** Define the function to get the contents of a falloff tooltip */
    falloffTooltip: (falloff: number) => string;
    /** Define the active color of a node */
    color: string | ThemeColor;
    /** Define the template of sankey chart nodes */
    nodeTemplate: TemplateRef<SankeyNodeContext<T>>;
    /** Access the SVG element which will contain the links */
    linkContainer: ElementRef;
    /** Access the element which will contain the nodes */
    nodeContainer: ElementRef;
    /** Store the width of the chart area */
    _width: number;
    /** Store the height of the chart area */
    _height: number;
    /** Define the nodes that should be rendered */
    _nodes: ReadonlyArray<SankeyNodeLink<T>>;
    /** Define the columns to display */
    _columns: ReadonlyArray<SankeyColumn>;
    /** Determine if the tooltip should be visible or not */
    _isTooltipOpen: boolean;
    /** Define the position of the tooltip */
    _tooltipPosition: SankeyTooltipPosition;
    /** Define the content to display in the tooltip */
    _tooltipContent: string;
    /** Determine if the component is initialised */
    private _isInitialised;
    /** Store the instance of the sankey layout */
    private readonly _sankey;
    ngAfterViewInit(): void;
    /**
     * Detect any changes from Inputs. We can skip
     * the first function call as this happens before
     * the initial render so it has no effect.
     */
    ngOnChanges(): void;
    /** Re-render the chart */
    _render(): void;
    /** Update the layout whenever the dimensions change changes */
    _onResize(dimensions: ResizeDimensions): void;
    /**
     * Column count should be based on the data, not the titles
     * as they may not specify titles but the nodes will still be
     * rendered.
     */
    _getColumnCount(): number;
    /**
     * Get the SVG path that defines the shape of the link
     */
    _getPath(link: SankeyLink): string;
    /**
     * Set the active state of a node and the inputs and outputs
     * associated with this node.
     */
    _setNodeActive(nodeLink: SankeyNodeLink<T>, active: boolean): void;
    /**
     * Set the focused state of a node and the inputs and outputs
     * associated with this node.
     */
    _setNodeFocus(nodeLink: SankeyNodeLink<T>, focused: boolean, element: HTMLDivElement): void;
    /**
     * Set the active state of a link and the source and target
     * nodes associated with the link
     */
    _setLinkActive(link: SankeyLink & SankeyLinkPlot & SankeyLinkInteraction, active: boolean): void;
    /**
     * This is required because we want to toggle a class based on the `active`
     * property on a link, however toggling classes using `NgClass` or the class
     * binding syntax `[class.xyz]` does not work in IE when applied to an SVG
     * element. (https://github.com/angular/angular/issues/6327)
     *
     * The alternatice is to bind directly to the `class` attribute and return a
     * string that will toggle the class based on the `active` property.
     */
    _getLinkClass(link: SankeyLink & SankeyLinkPlot & SankeyLinkInteraction): string;
    /**
     * Get the SVG path that defines the shape of the falloff indicator
     */
    _getFalloffPath(node: SankeyNodeLink<T>): string;
    /**
     * Falloff represents the amount of data that does not get passed on,
     * for example, if a node gets 1,000,000 items from inputs and only outputs
     * 500,000 then there is falloff of 500,000. However, items in the last column
     * never pass on any information, so tecnhically 100% of their input is falloff
     * so we shouldn't show it in the last column.
     */
    _showFalloff(nodeLink: SankeyNodeLink<T>): boolean;
    /** Update the visibility and content of the tooltip on falloff hover */
    _setFalloffTooltip(nodeLink: SankeyNodeLink<T>, isVisible: boolean): void;
    /**
     * Update the position of the tooltip
     */
    _setTooltipPosition(event: MouseEvent): void;
    /**
     * Correctly track the node changes in `*ngFor` based on
     * the unique node ids to prevent unnecessary re-rendering
     */
    _trackNodeBy(_index: number, nodeLink: SankeyNodeLink<T>): string | number;
    /**
     * Correctly track the link changes in `*ngFor` based on
     * the source and target to prevent unnecessary re-rendering
     */
    _trackLinkBy(_index: number, link: SankeyLink): string;
    /**
     * Get the color of node based on whether or not
     * the `color` input has been provided.
     */
    _getColor(item: SankeyNodeLink<T> | (SankeyLink & SankeyLinkInteraction)): string;
    /**
     * We want the focus indicator color to match the active color,
     * which if programmatically defined need to be overriden
     */
    _getFocusIndicator(nodeLink: SankeyNodeLink<T>): string;
    /**
     * Get columns mapped with their title if they have any
     */
    private getColumns;
    /**
     * Get the start position of a column which can be determined
     * by finding a node that is in that column and using its
     * x position as all nodes start at the same position within a column.
     */
    private getColumnPosition;
    /**
     * Get the default content of a link tooltip
     */
    private getLinkTooltip;
    /**
     * Get the default content of a falloff tooltip
     */
    private getFalloffTooltip;
    static ɵfac: i0.ɵɵFactoryDeclaration<SankeyChartComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SankeyChartComponent<any>, "ux-sankey-chart", never, { "nodes": { "alias": "nodes"; "required": false; }; "links": { "alias": "links"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "linkTooltip": { "alias": "linkTooltip"; "required": false; }; "falloffTooltip": { "alias": "falloffTooltip"; "required": false; }; "color": { "alias": "color"; "required": false; }; }, {}, ["nodeTemplate"], never, true, never>;
}
interface SankeyColumn {
    width: number;
    title: string;
    position: number;
}
interface SankeyTooltipPosition {
    x: number;
    y: number;
}
interface SankeyNodeContext<T> {
    node: SankeyNode<T>;
    active: boolean;
    focus: boolean;
}

declare class SankeyChartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SankeyChartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SankeyChartModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof ResizeModule, typeof TooltipModule, typeof ColorServiceModule, typeof SankeyChartComponent, typeof SankeyNodeDirective], [typeof SankeyChartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SankeyChartModule>;
}

interface SearchBuilderComponentContext {
    name: string;
    value: unknown;
    config?: {
        [key: string]: unknown;
    };
}

interface SearchBuilderComponentDefinition {
    name: string;
    component: any;
    config?: any;
}

interface SearchBuilderGroupQuery {
    type: string;
    value: unknown;
    config?: {
        [key: string]: unknown;
    };
}

interface SearchBuilderQuery {
    [key: string]: SearchBuilderGroupQuery[];
}

declare class SearchBuilderFocusService {
    focus$: BehaviorSubject<SearchBuilderFocus>;
    /**
     * Set focus on a search builder component.
     * @param groupId The `id` of the group containing the component.
     * @param index The (zero-based) index of the component.
     */
    setFocus(groupId: string, index: number): void;
    /**
     * Removes focus from all components. If focus is not on a search builder component, this does nothing.
     */
    clearFocus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBuilderFocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchBuilderFocusService>;
}
interface SearchBuilderFocus {
    groupId: string;
    index: number;
}

declare class SearchBuilderGroupService {
    private readonly _searchBuilderService;
    private readonly _searchBuilderFocusService;
    private _id;
    /**
     * Initialise the group by defining an id
     */
    init(id: string): void;
    /**
     * Remove a field from the search builder query and return focus to the previous field.
     */
    removeAtIndex(index: number): void;
    /**
     * Get the query for this specific search group
     */
    getQuery(): SearchBuilderGroupQuery[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBuilderGroupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchBuilderGroupService>;
}

declare class SearchBuilderGroupComponent implements OnInit, OnDestroy {
    readonly searchBuilderGroupService: SearchBuilderGroupService;
    private readonly _searchBuilderFocusService;
    id: string;
    header: string;
    operator: SearchBuilderGroupOperator;
    addText: string;
    placeholder: TemplateRef<void>;
    showPlaceholder: boolean;
    removeFieldButtonAriaLabel: string;
    add: EventEmitter<MouseEvent>;
    remove: EventEmitter<SearchBuilderGroupQuery>;
    focusIndex: number;
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    addField(event: MouseEvent): void;
    removeFieldAtIndex(index: number, field: SearchBuilderGroupQuery): void;
    setFocus(index: number): void;
    clearFocus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBuilderGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchBuilderGroupComponent, "ux-search-builder-group", never, { "id": { "alias": "id"; "required": false; }; "header": { "alias": "header"; "required": false; }; "operator": { "alias": "operator"; "required": false; }; "addText": { "alias": "addText"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "showPlaceholder": { "alias": "showPlaceholder"; "required": false; }; "removeFieldButtonAriaLabel": { "alias": "removeFieldButtonAriaLabel"; "required": false; }; }, { "add": "add"; "remove": "remove"; }, never, never, true, never>;
}
type SearchBuilderGroupOperator = 'and' | 'or' | 'not';

declare class SearchBuilderOutletDirective implements OnInit, OnDestroy {
    private readonly _viewContainerRef;
    private readonly _componentFactoryResolver;
    private readonly _searchBuilderService;
    private readonly _searchBuilderFocusService;
    outlet: string;
    context: any;
    groupId: string;
    index: number;
    private _componentRef;
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBuilderOutletDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SearchBuilderOutletDirective, "[uxSearchBuilderOutlet]", never, { "outlet": { "alias": "uxSearchBuilderOutlet"; "required": false; }; "context": { "alias": "uxSearchBuilderOutletContext"; "required": false; }; "groupId": { "alias": "uxSearchBuilderOutletGroupId"; "required": false; }; "index": { "alias": "uxSearchBuilderOutletIndex"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SearchBuilderComponent implements OnDestroy {
    private readonly _searchBuilderService;
    set components(components: SearchBuilderComponentDefinition[]);
    set query(value: SearchBuilderQuery);
    get query(): SearchBuilderQuery;
    queryChange: EventEmitter<SearchBuilderQuery>;
    valid: EventEmitter<boolean>;
    private readonly _querySubscription;
    private readonly _validSubscription;
    /**
     * Register the default search builder components
     */
    constructor();
    /**
     * Remove any subscriptions and cleanup
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBuilderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchBuilderComponent, "ux-search-builder", never, { "components": { "alias": "components"; "required": false; }; "query": { "alias": "query"; "required": false; }; }, { "queryChange": "queryChange"; "valid": "valid"; }, never, ["*"], true, never>;
}

declare class TagInputEvent {
    tag: unknown;
    private _defaultPrevented;
    constructor(tag: unknown);
    preventDefault(): void;
    defaultPrevented(): boolean;
}

declare class TagInputComponent<T = any> implements AfterContentInit, OnChanges, ControlValueAccessor, Validator, OnDestroy {
    private readonly _changeDetector;
    private readonly _element;
    private readonly _typeaheadKeyService;
    private readonly _document;
    /** Specify a unique Id for the component */
    id: string;
    /**
     * The list of tags appearing in the tag input. This can be an array of strings or custom objects.
     * See the `displayProperty` property for details of using a custom object.
     */
    get tags(): T | ReadonlyArray<T>;
    set tags(value: T | ReadonlyArray<T>);
    /** The editable text appearing in the tag input. */
    input: string;
    /**
     * Determines the display value of the `options`, if they are custom objects.
     * This may be a function or a string. If a function is provided, it receives
     * the option object as an argument, and should return the appropriate display value.
     * If the name of a property is provided as a string, that property is used as the display value.
     */
    display: TagInputDisplayFunction<T> | string;
    /** Controls whether pasting text into the text input area automatically converts that text into one or more tags. */
    addOnPaste: boolean;
    /** The aria-label to apply to the child `input` element. */
    ariaLabel: string;
    /** ID of the element which serves as a label for the input element. */
    ariaLabelledby: string;
    /** Controls the disabled state of the tag input. */
    disabled: boolean;
    /** Specified if this is a required input. */
    required: boolean;
    /**
     * If set to `true`, the tag input will prevent addition and removal of tags to enforce the minTags and maxTags settings.
     * Otherwise, a validation error will be raised.
     */
    enforceTagLimits: boolean;
    /**
     * If `true`, input entered into the text input area can be converted into a tag by pressing enter.
     * Otherwise, tags can only be added from the typeahead list or other external means.
     * (Note that the `maxTags` and `tagPattern` will prevent invalid inputs regardless of this setting.)
     */
    freeInput: boolean;
    /** If `true` the input field will be readonly and selection can only occur by using the dropdown. */
    readonlyInput: boolean;
    /**
     * The maximum number of tags permitted in the tag input. If the number of tags is equal to `maxTags` and
     * `enforceTagLimits` is `true`, addition of tags will be prevented until a tag is removed
     */
    maxTags: number;
    /**
     * The minimum number of tags permitted in the tag input. If the number of tags is equal to `minTags` and `enforceTagLimits` is
     * `true`, removal of tags will be prevented until a new tag is added.
     */
    minTags: number;
    /** The placeholder text which appears in the text input area when it is empty. */
    placeholder: string;
    /** Controls whether the typeahead appears when the text input area is clicked. This has no effect if the ux-typeahead component is not configured. */
    showTypeaheadOnClick: boolean;
    /**
     * A string containing the characters which delimit tags.
     * Typing one of the characters in `tagDelimiters` will cause the preceding text to be added as a tag,
     * and the text input area will be cleared. Pasting a string containing one or more of characters in
     * `tagDelimiters` will cause the string to be split into multiple tags.
     * Note that the delimiter character will not be part of the tag text.
     */
    tagDelimiters: string;
    /** The validation expression for tags added via the input text area. Strings which do not match this expression will not be added as tags. */
    tagPattern: RegExp;
    /**
     * A template which will be rendered as the content of each tag. The following context properties are available in the template:
     * - `tag: any` - the string or custom object representing the tag.
     * - `index: number` - the zero-based index of the tag as it appears in the tag input.
     * - `api: TagApi` - provides the functions getTagDisplay, removeTagAt and canRemoveTagAt.
     */
    tagTemplate: TemplateRef<TagTemplateContext<T>>;
    /**
     * A function which returns either a string, string[], or Set<string>, compatible with the NgClass directive. The function receives the following parameters:
     * - `tag: any` - the string or custom object representing the tag.
     * - `index: number` - the zero-based index of the tag as it appears in the tag input.
     * - `selected: boolean` - true if the tag is currently selected.
     */
    tagClass: TagClassFunction<T>;
    /**
     * An object which contains details of validation errors. The following properties will be present if there is a related validation error:
     * - `tagRangeError` - present if the number of tags is outside the range specified by minTags and maxTags.
     * - `inputPattern` - present if an input has been submitted which does not match the tagPattern.
     */
    validationErrors: any;
    /** Defines the autocomplete property on the input field which can be used to prevent the browser from displaying autocomplete suggestions. */
    autocomplete: string;
    /**
     * A custom function which is called to create a new tag object.
     * This can be used to populate other properties in the tag object.
     * If `createTag` is not provided, then an object is created with the `displayProperty` set to the input.
     * If `displayProperty` is also not set, then the tag is created as a simple string.
     */
    createTagHandler: (value: string) => any;
    /** Define a custom icon to be used instead of the chevron */
    icon: TemplateRef<void>;
    /** Determine if we should show the clear all button */
    clearButton: boolean;
    /** Determine an aria label for the clear button */
    clearButtonAriaLabel: string;
    /** Determine if the dropdown panel should close on external click.*/
    set autoCloseDropdown(value: boolean);
    get autoCloseDropdown(): boolean;
    /** Emits when tags is changed. */
    tagsChange: EventEmitter<readonly T[]>;
    /** Emits when input is changed. */
    inputChange: EventEmitter<string>;
    /** Raised when a tag is about to be added. The `tag` property of the event contains the tag to be added. Call `preventDefault()` on the event to prevent addition. */
    tagAdding: EventEmitter<TagInputEvent>;
    /** Raised when a tag has been added. The tag property of the event contains the tag. */
    tagAdded: EventEmitter<TagInputEvent>;
    /** Raised when a tag has failed validation according to the `tagPattern`. The tag property of the event contains the string which failed validation. */
    tagInvalidated: EventEmitter<TagInputEvent>;
    /** Raised when a tag is about to be removed. The `tag` property of the event contains the tag to be removed. Call `preventDefault()` on the event to prevent removal. */
    tagRemoving: EventEmitter<TagInputEvent>;
    /** Raised when a tag has been removed. The tag property of the event contains the tag. */
    tagRemoved: EventEmitter<TagInputEvent>;
    /** Raised when a tag has been clicked. The `tag` property of the event contains the clicked tag. Call `preventDefault()` on the event to prevent the default behaviour of selecting the tag. */
    tagClick: EventEmitter<TagInputEvent>;
    inputFocus: EventEmitter<FocusEvent>;
    inputBlur: EventEmitter<FocusEvent>;
    typeaheadQuery: QueryList<TypeaheadComponent>;
    tagInput: ElementRef<HTMLInputElement>;
    selectedIndex: number;
    tagApi: TagApi<T>;
    valid: boolean;
    inputValid: boolean;
    typeahead: TypeaheadComponent;
    highlightedElement: HTMLElement;
    get _showClearButton(): boolean;
    _tags: ReadonlyArray<T>;
    private _onChangeHandler;
    private _onTouchedHandler;
    private _subscription;
    private readonly _onDestroy;
    private _autoCloseDropdown;
    static ngAcceptInputType_autoCloseDropdown: BooleanInput;
    ngAfterContentInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    writeValue(value: T[]): void;
    registerOnChange(fn: () => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    /**
     * Set focus on the input field.
     */
    focus(): void;
    /**
     * Validate the value of the control (tags property).
     */
    validate(): ValidationErrors | null;
    keyHandler(event: KeyboardEvent): void;
    focusOutHandler(): void;
    onClick(): void;
    tagClickHandler(event: MouseEvent, tag: T, index: number): void;
    inputClickHandler(): void;
    inputFocusHandler(): void;
    inputPasteHandler(event: ClipboardEvent): void;
    typeaheadOptionSelectedHandler(event: TypeaheadOptionEvent): void;
    /**
     * Commit the current input value and clear the input field if successful.
     */
    commitInput(): void;
    /**
     * Commit the given tag object and clear the input if successful.
     */
    commitTypeahead(tag: T): void;
    /**
     * Commit the given string value as one or more tags, if validation passes. Returns true if the tag(s) were created.
     */
    commit(input: string): boolean;
    /**
     * If no tag is selected, select the rightmost tag. If a tag is selected, remove it.
     */
    backspace(): void;
    /**
     * Move the highlighted option forwards or backwards in the list. Wraps at the limits.
     * @param delta Value to be added to the selected index, i.e. -1 to move backwards, +1 to move forwards.
     */
    moveSelection(delta: number): void;
    /**
     * Returns a value to display for the given tag. Uses display function/property name if set, otherwise assumes that the tag is a simple string.
     */
    getTagDisplay(tag: any): string;
    /**
     * Returns true if the given index is selected (tag index or input field).
     */
    isSelected(index: number): boolean;
    /**
     * Select the tag at the given index. Does nothing if disabled is true.
     */
    selectTagAt(tagIndex: number): void;
    /**
     * Select the input field, giving it focus. Does nothing if disabled is true.
     */
    selectInput(): void;
    /**
     * Remove the tag at the given index. Does nothing if disabled is true or the minTags property prevents removal.
     */
    removeTagAt(tagIndex: number): void;
    /**
     * Returns true if the tag at the given index can be removed.
     */
    canRemoveTagAt(): boolean;
    /**
     * Returns true if the input field should be available.
     */
    isInputVisible(): boolean;
    /**
     * Returns true if any part of the control has focus.
     */
    hasFocus(): boolean;
    toggle(): void;
    clear(): void;
    setInputValue(text: string): void;
    setTagsValue(tags: ReadonlyArray<T>): void;
    private connectTypeahead;
    /**
     * Validate the given tagValue with the tagPattern, if set. Update validationErrors on validation failure.
     */
    private validateTag;
    /**
     * Create a tag object for the given tagValue. If createTagHandler is specified, use it; otherwise if displayProperty is specified, create an object with the tagValue as the single named property; otherwise return the tagValue itself.
     */
    private createTag;
    /**
     * Add a tag object, calling the tagAdding and tagAdded events. Returns true if the tag was added to the tags array.
     */
    private addTag;
    /**
     * Returns true if the given tagIndex is a valid tag index.
     */
    private isValidTagIndex;
    /**
     * Returns true if the given index is a valid selection index (tags or input field).
     */
    private isValidSelectIndex;
    /**
     * Returns the character corresponding to the given key event, mainly for IE compatibility.
     */
    private getKeyChar;
    /**
     * Returns an array of strings corresponding to the input string split by the tagDelimiters characters.
     */
    private splitTagInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<TagInputComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TagInputComponent<any>, "ux-tag-input", ["ux-tag-input"], { "id": { "alias": "id"; "required": false; }; "tags": { "alias": "tags"; "required": false; }; "input": { "alias": "input"; "required": false; }; "display": { "alias": "display"; "required": false; }; "addOnPaste": { "alias": "addOnPaste"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "ariaLabelledby": { "alias": "ariaLabelledby"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "required": { "alias": "required"; "required": false; }; "enforceTagLimits": { "alias": "enforceTagLimits"; "required": false; }; "freeInput": { "alias": "freeInput"; "required": false; }; "readonlyInput": { "alias": "readonlyInput"; "required": false; }; "maxTags": { "alias": "maxTags"; "required": false; }; "minTags": { "alias": "minTags"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "showTypeaheadOnClick": { "alias": "showTypeaheadOnClick"; "required": false; }; "tagDelimiters": { "alias": "tagDelimiters"; "required": false; }; "tagPattern": { "alias": "tagPattern"; "required": false; }; "tagTemplate": { "alias": "tagTemplate"; "required": false; }; "tagClass": { "alias": "tagClass"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "autocomplete": { "alias": "autocomplete"; "required": false; }; "createTagHandler": { "alias": "createTag"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "clearButton": { "alias": "clearButton"; "required": false; }; "clearButtonAriaLabel": { "alias": "clearButtonAriaLabel"; "required": false; }; "autoCloseDropdown": { "alias": "autoCloseDropdown"; "required": false; }; }, { "tagsChange": "tagsChange"; "inputChange": "inputChange"; "tagAdding": "tagAdding"; "tagAdded": "tagAdded"; "tagInvalidated": "tagInvalidated"; "tagRemoving": "tagRemoving"; "tagRemoved": "tagRemoved"; "tagClick": "tagClick"; "inputFocus": "inputFocus"; "inputBlur": "inputBlur"; }, ["typeaheadQuery"], ["*"], true, never>;
}
/**
 * The API available to tag templates.
 */
interface TagApi<T = any> {
    /**
     * Returns the display value of the given tag, according to the displayProperty property.
     */
    getTagDisplay: (tag: T) => string;
    /**
     * Removes the tag at the given index, if possible.
     */
    removeTagAt: (index: number) => void;
    /**
     *    Returns true if the tag at the given index can be removed.
     */
    canRemoveTagAt: (index: number) => boolean;
}
/**
 * The function used to return custom class information, for use in `ngClass`.
 */
type TagClassFunction<T = any> = (tag: T, index: number, selected: boolean) => string | string[] | Set<string>;
type TagInputDisplayFunction<T> = (option: T) => string;
interface TagTemplateContext<T = string | any> {
    tag: T;
    index: number;
    api: TagApi;
}

declare class TagInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TagInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TagInputModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof i3$2.FormsModule, typeof FocusIfModule, typeof IconModule, typeof TypeaheadModule, typeof TagInputComponent], [typeof TagInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TagInputModule>;
}

declare const SELECT_VALUE_ACCESSOR: StaticProvider;
declare class SelectComponent<T> implements OnInit, OnChanges, OnDestroy, ControlValueAccessor {
    private readonly _element;
    private readonly _platform;
    private readonly _typeaheadKeyService;
    private readonly _changeDetector;
    private readonly _document;
    /** A unique id for the component. */
    id: string;
    /** The selected option (for single select) or array of options (for multiple select). */
    set value(value: T | ReadonlyArray<T>);
    get value(): T | ReadonlyArray<T>;
    /** The text in the input area. This is used to filter the options dropdown. */
    set input(value: string);
    get input(): string;
    /** The status of the typeahead dropdown. */
    set dropdownOpen(value: boolean);
    get dropdownOpen(): boolean;
    /**
     * If an array is provided, this is the list of options which can be chosen from. It can be an array of strings or
     * custom objects. If custom objects are required, the display property must also be set. If a function is provided,
     * this is used as a callback to dynamically retrieve data in pages. The function parameters are:
     * @param pageNum The index of the requested page, starting from 0.
     * @param pageSize The number of items requested.
     * @param filter The filter details as provided via the filter binding.
     * @returns Either a promise which resolves to an array, or a plain array in case the data can be loaded
     * synchronously. An empty array or an array with fewer than `pageSize` items can be returned, which indicates that
     * the end of the data set has been reached.
     */
    options: T[] | InfiniteScrollLoadFunction;
    /**
     * Determines the display value of the `options`, if they are custom objects. This may be a function or a string.
     * If a function is provided, it receives the option object as an argument, and should return the appropriate
     * display value. If the name of a property is provided as a string, that property is used as the display value.
     */
    display: ((option: T) => string) | string;
    /**
     * Determines the unique key value of the `options`, if they are custom objects. This may be a function or a string.
     * If a function is provided, it receives the option object as an argument, and should return the appropriate
     * key value. If the name of a property is provided as a string, that property is used as the key value.
     */
    key: ((option: T) => string) | string;
    /**
     * Controls whether the value of the single select control can be cleared by deleting the selected value in the
     * input field. This does not affect the initial state of the control, so specify a value for `value` if null should
     * never be allowed.
     */
    allowNull: boolean;
    /** The aria-label to apply to the child `input` element. */
    ariaLabel: string;
    /** ID of the element which serves as a label for the input element. */
    ariaLabelledby: string;
    /** The aria-label to apply to the typeahead listbox */
    listboxAriaLabel: string;
    /** Controls the disabled state of the tag input. */
    disabled: boolean;
    /** The positioning of the typeahead dropdown in relation to its parent. */
    dropDirection: 'auto' | 'up' | 'down';
    /** The maximum height of the typeahead dropdown, as a CSS value. */
    maxHeight: string;
    /**
     * Controls whether the user can select more than one option in the select control. If set to true, selected
     * options will appear as tags in the input area. If set to false, the selected value will appear as editable text
     * in the input area.
     */
    multiple: boolean;
    /**
     * The number of options to request in a page. This should ideally be more than twice the number of items which
     * fit into the height of the dropdown, but this is not required.
     */
    pageSize: number;
    /** The placeholder text which appears in the text input area when it is empty. */
    placeholder: string;
    /**
     * A template which will be rendered as the content of each selected option. The following context
     * properties are available in the template via the TagTemplateContext:
     * - `tag: T` - the string or custom object representing the selected option.
     * - `index: number` - the zero-based index of the selected option as it appears in the dropdown.
     * - `api: TagApi` - provides the functions getTagDisplay, removeTagAt and canRemoveTagAt.
     */
    tagTemplate: TemplateRef<TagTemplateContext>;
    optionsHeadingTemplate: TemplateRef<void>;
    recentOptionsHeadingTemplate: TemplateRef<void>;
    /**
     * Defines the `autocomplete` property on the `input` element which can be used to prevent the browser from
     * displaying autocomplete suggestions.
     */
    autocomplete: string;
    /** A template which will be rendered in the dropdown while options are being loaded. */
    loadingTemplate: TemplateRef<void>;
    /** A template which will be rendered in the dropdown if no options match the current filter value. */
    noOptionsTemplate: TemplateRef<void>;
    /** If `true` the input field will be readonly and selection can only occur by using the dropdown. */
    readonlyInput: boolean;
    /** Determine if we should show the clear all button */
    clearButton: boolean;
    /** Determine an aria label for the clear button */
    clearButtonAriaLabel: string;
    /** Determine if the dropdown panel should close on external click.*/
    set autoCloseDropdown(value: boolean);
    get autoCloseDropdown(): boolean;
    /**
     * A template which will be rendered in the dropdown for each option.
     * The following context properties are available in the template:
     * - option: any - the string or custom object representing the option.
     * - api: TypeaheadOptionApi - provides the functions `getKey`, `getDisplay` and `getDisplayHtml`.
     */
    optionTemplate: TemplateRef<TypeaheadOptionContext<T>>;
    /**
     * An initial list of recently selected options, to be presented above the full list of options.
     * Bind an empty array to `recentOptions` to enable this feature without providing an initial set.
     */
    recentOptions: ReadonlyArray<T>;
    /** Maximum number of displayed recently selected options. */
    recentOptionsMaxCount: number;
    /** Specified if this is a required input. */
    required: boolean;
    /** Specify the debounceTime value for the select filter */
    get filterDebounceTime(): number;
    set filterDebounceTime(filterDebounceTime: number);
    /** Emits when `value` changes. */
    valueChange: EventEmitter<T | readonly T[]>;
    /** Emits when `input` changes. */
    inputChange: EventEmitter<string>;
    /** Emits when `dropdownOpen` changes. */
    dropdownOpenChange: EventEmitter<boolean>;
    /** Emits when recently selected options change. */
    recentOptionsChange: EventEmitter<readonly T[]>;
    /** Allow a custom icon to be used instead of the chevron */
    icon: TemplateRef<void>;
    singleInput: ElementRef;
    tagInput: TagInputComponent;
    multipleTypeahead: TypeaheadComponent;
    singleTypeahead: TypeaheadComponent;
    highlightedElement: HTMLElement;
    filter$: Observable<string>;
    _value$: ReplaySubject<T | readonly T[]>;
    _hasValue: boolean;
    /** We need to store the most recent value*/
    private _value;
    private readonly _input$;
    private _dropdownOpen;
    private _userInput;
    private _filterDebounceTime;
    private _autoCloseDropdown;
    private _onChange;
    private _onTouched;
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    writeValue(obj: T): void;
    registerOnChange(fn: (value: T) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    inputClickHandler(): void;
    inputBlurHandler(): void;
    /**
     * Key handler for single select only. Multiple select key handling is in TagInputComponent.
     */
    inputKeyHandler(event: KeyboardEvent): void;
    /** This gets called whenever the user types in the input */
    onInputChange(input: string): void;
    /** Whenever a single select item is selected emit the values */
    _singleOptionSelected(event: TypeaheadOptionEvent): void;
    /** Whenever a multi-select item is selected emit the values */
    _multipleOptionSelected(selection: ReadonlyArray<T>): void;
    /**
     * Returns the display value of the given option.
     */
    getDisplay(option: T | readonly T[]): string;
    /** Toggle the dropdown open state */
    toggle(): void;
    /** Handle input focus events */
    onFocus(): void;
    clear(): void;
    private selectInputText;
    static ngAcceptInputType_filterDebounceTime: NumberInput;
    static ngAcceptInputType_autoCloseDropdown: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectComponent<any>, "ux-select, ux-combobox, ux-dropdown", never, { "id": { "alias": "id"; "required": false; }; "value": { "alias": "value"; "required": false; }; "input": { "alias": "input"; "required": false; }; "dropdownOpen": { "alias": "dropdownOpen"; "required": false; }; "options": { "alias": "options"; "required": false; }; "display": { "alias": "display"; "required": false; }; "key": { "alias": "key"; "required": false; }; "allowNull": { "alias": "allowNull"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "ariaLabelledby": { "alias": "ariaLabelledby"; "required": false; }; "listboxAriaLabel": { "alias": "listboxAriaLabel"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dropDirection": { "alias": "dropDirection"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "tagTemplate": { "alias": "tagTemplate"; "required": false; }; "optionsHeadingTemplate": { "alias": "optionsHeadingTemplate"; "required": false; }; "recentOptionsHeadingTemplate": { "alias": "recentOptionsHeadingTemplate"; "required": false; }; "autocomplete": { "alias": "autocomplete"; "required": false; }; "loadingTemplate": { "alias": "loadingTemplate"; "required": false; }; "noOptionsTemplate": { "alias": "noOptionsTemplate"; "required": false; }; "readonlyInput": { "alias": "readonlyInput"; "required": false; }; "clearButton": { "alias": "clearButton"; "required": false; }; "clearButtonAriaLabel": { "alias": "clearButtonAriaLabel"; "required": false; }; "autoCloseDropdown": { "alias": "autoCloseDropdown"; "required": false; }; "optionTemplate": { "alias": "optionTemplate"; "required": false; }; "recentOptions": { "alias": "recentOptions"; "required": false; }; "recentOptionsMaxCount": { "alias": "recentOptionsMaxCount"; "required": false; }; "required": { "alias": "required"; "required": false; }; "filterDebounceTime": { "alias": "filterDebounceTime"; "required": false; }; }, { "valueChange": "valueChange"; "inputChange": "inputChange"; "dropdownOpenChange": "dropdownOpenChange"; "recentOptionsChange": "recentOptionsChange"; }, ["icon"], never, true, never>;
}

declare class SelectModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SelectModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof i3$2.FormsModule, typeof InfiniteScrollModule, typeof TagInputModule, typeof TypeaheadModule, typeof i3.PlatformModule, typeof SelectComponent], [typeof SelectComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SelectModule>;
}

declare class BaseSearchComponent implements OnDestroy {
    private readonly _searchBuilderService;
    get id(): string;
    type: string;
    config: any;
    context: SearchBuilderComponentContext;
    focus: boolean;
    /**
     * Get the current value of the component
     */
    get value(): any;
    /**
     * Set the current value of the component
     */
    set value(value: any);
    get valid(): boolean;
    set valid(valid: boolean);
    private readonly _id;
    private _valid;
    /**
     * Make sure we clean up after ourselves
     */
    ngOnDestroy(): void;
    /**
     * Perform any required validation on the value
     */
    validate(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BaseSearchComponent, "ux-base-search", never, {}, {}, never, never, true, never>;
}
interface BaseSearchComponentConfig {
    label?: string;
    placeholder?: string;
    validation?: (value: unknown) => boolean;
}

declare class SearchTextComponent extends BaseSearchComponent {
    type: string;
    get label(): string;
    get placeholder(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchTextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchTextComponent, "ux-search-text", never, {}, {}, never, never, true, never>;
}
type SearchTextConfig = BaseSearchComponentConfig;

declare class SearchDateComponent extends BaseSearchComponent implements OnInit {
    type: string;
    get label(): string;
    get placeholder(): string;
    get dateInputAriaLabel(): string;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchDateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchDateComponent, "ux-search-date", never, {}, {}, never, never, true, never>;
}
interface SearchDateConfig extends BaseSearchComponentConfig {
    dateInputAriaLabel: string;
}

declare class SearchDateRangeComponent extends BaseSearchComponent {
    type: string;
    get label(): string;
    get from(): string | number | Date;
    set from(fromValue: string | number | Date);
    get to(): string | number | Date;
    set to(toValue: string | number | Date);
    get fromLabel(): string;
    get toLabel(): string;
    get fromPlaceholder(): string;
    get toPlaceholder(): string;
    get toDateInputAriaLabel(): string;
    get fromDateInputAriaLabel(): string;
    /**
     * Override the default validation
     */
    validate(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchDateRangeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchDateRangeComponent, "ux-search-date-range", never, {}, {}, never, never, true, never>;
}
interface SearchDateRangeConfig {
    label?: string;
    fromLabel?: string;
    toLabel?: string;
    fromPlaceholder?: string;
    toPlaceholder?: string;
    toDateInputAriaLabel?: string;
    fromDateInputAriaLabel?: string;
    validation: (value: unknown) => boolean;
}

declare class SearchSelectComponent extends BaseSearchComponent {
    type: string;
    /**
     * Provide defaults for undefined properties
     */
    get label(): string;
    get options(): any;
    get multiple(): boolean;
    get placeholder(): string;
    get dropDirection(): 'auto' | 'up' | 'down';
    get allowNull(): boolean;
    get disabled(): boolean;
    get maxHeight(): string;
    get pageSize(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchSelectComponent, "ux-search-select", never, {}, {}, never, never, true, never>;
}
interface SearchSelectConfig extends BaseSearchComponentConfig {
    options?: any[] | InfiniteScrollLoadFunction;
    multiple?: boolean;
    dropDirection?: 'up' | 'down';
    allowNull?: boolean;
    disabled?: boolean;
    maxHeight?: string;
    pageSize?: number;
}

declare class SearchBuilderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBuilderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SearchBuilderModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof DateTimePickerModule, typeof FocusIfModule, typeof i3$2.FormsModule, typeof IconModule, typeof PopoverModule, typeof SelectModule, typeof SearchBuilderComponent, typeof SearchBuilderGroupComponent, typeof SearchTextComponent, typeof SearchDateComponent, typeof SearchDateRangeComponent, typeof SearchBuilderOutletDirective, typeof SearchSelectComponent, typeof BaseSearchComponent], [typeof SearchBuilderComponent, typeof SearchBuilderGroupComponent, typeof BaseSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SearchBuilderModule>;
}

declare class SearchBuilderService {
    query: SearchBuilderQuery;
    queryChange: Subject<SearchBuilderQuery>;
    validationChange: BehaviorSubject<boolean>;
    private _componentId;
    private readonly _components;
    private _validation;
    /**
     * Add a component to the internal list of components
     */
    registerComponent(component: SearchBuilderComponentDefinition): void;
    /**
     * Bulk registration of components
     * (Just a helper method)
     */
    registerComponents(components: SearchBuilderComponentDefinition[]): void;
    /**
     * Get a registered component class
     */
    getComponent(name: string): SearchBuilderComponentDefinition;
    /**
     * Update the internal search query state
     * note that the query will be immutable
     */
    setQuery(query: SearchBuilderQuery): void;
    /**
     * Return the current query state
     */
    getQuery(): SearchBuilderQuery;
    /**
     * Trigger the observable to indicate the query has been updated
     */
    queryHasChanged(): void;
    /**
     * Store the validation state of the query
     */
    setValid(id: number, valid: boolean): void;
    /**
     * Generate a unique id for each component
     */
    generateComponentId(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBuilderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchBuilderService>;
}

declare class SelectListItemComponent<T> implements OnDestroy {
    private readonly _selection;
    readonly elementRef: ElementRef<any>;
    readonly focusIndicatorService: FocusIndicatorService;
    /** This should define the data this item represents. This value will appear in the selected array whenever this item is selected. */
    data: T;
    tabindex: number;
    set selected(isSelected: boolean);
    get selected(): boolean;
    /** Store a reference to the focus indicator instance */
    private readonly _focusIndicator;
    /** Unsubscribe from all subscriptions on destroy */
    private readonly _onDestroy;
    constructor();
    ngOnDestroy(): void;
    onMouseDown(event: MouseEvent): void;
    onClick(event: MouseEvent): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectListItemComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectListItemComponent<any>, "ux-select-list-item", never, { "data": { "alias": "data"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class SelectListComponent<T> implements AfterContentInit, OnDestroy {
    private readonly _selection;
    /** Determine if we allow multiple items to be selected */
    set multiple(multiple: boolean);
    /** Set the selected items */
    set selected(selected: T | ReadonlyArray<T>);
    /** Emit when the selection changes */
    selectedChange: EventEmitter<readonly T[]>;
    /** Find all select list items */
    items: QueryList<SelectListItemComponent<T>>;
    /** Automatically unsubscribe all observables */
    private readonly _onDestroy;
    constructor();
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectListComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectListComponent<any>, "ux-select-list", never, { "multiple": { "alias": "multiple"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; }, { "selectedChange": "selectedChange"; }, ["items"], ["*"], true, never>;
}

declare class SelectListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SelectListModule, never, [typeof AccessibilityModule, typeof SelectListComponent, typeof SelectListItemComponent], [typeof SelectListComponent, typeof SelectListItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SelectListModule>;
}

declare class SidePanelCloseDirective {
    private readonly _service;
    private readonly _focusOrigin;
    onClick(event: MouseEvent | KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidePanelCloseDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SidePanelCloseDirective, "[uxSidePanelClose]", never, {}, {}, never, never, true, never>;
}

declare class SidePanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SidePanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SidePanelModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof i1.A11yModule, typeof FocusIfModule, typeof SidePanelComponent, typeof SidePanelCloseDirective], [typeof SidePanelComponent, typeof SidePanelCloseDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SidePanelModule>;
}

declare class SparkComponent {
    private readonly _colorService;
    values: number[];
    barHeight: number;
    inlineLabel: string;
    topLeftLabel: string;
    topRightLabel: string;
    bottomLeftLabel: string;
    bottomRightLabel: string;
    tooltip: string;
    ariaLabel: string | string[];
    ariaDescription: string;
    private _trackColor;
    private _theme;
    private _barColor;
    set theme(value: string);
    get theme(): string;
    set trackColor(value: string);
    get trackColor(): string;
    set barColor(value: string | string[]);
    get barColor(): string | string[];
    set value(value: number | number[]);
    get value(): number | number[];
    /**
     * Get the aria label for the spark chart
     */
    getAriaLabel(): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<SparkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SparkComponent, "ux-spark", never, { "barHeight": { "alias": "barHeight"; "required": false; }; "inlineLabel": { "alias": "inlineLabel"; "required": false; }; "topLeftLabel": { "alias": "topLeftLabel"; "required": false; }; "topRightLabel": { "alias": "topRightLabel"; "required": false; }; "bottomLeftLabel": { "alias": "bottomLeftLabel"; "required": false; }; "bottomRightLabel": { "alias": "bottomRightLabel"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaDescription": { "alias": "aria-description"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "trackColor": { "alias": "trackColor"; "required": false; }; "barColor": { "alias": "barColor"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SparkModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SparkModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SparkModule, never, [typeof i2.CommonModule, typeof ColorServiceModule, typeof TooltipModule, typeof SparkComponent], [typeof SparkComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SparkModule>;
}

/** An interface representing a grouped item */
interface ColumnPickerGroupItem {
    /**  The name of the group that this column belongs to. */
    group?: string;
    /**  The name of the column. */
    name: string;
}
declare function isColumnPickerGroupItem(column: string | ColumnPickerGroupItem): column is ColumnPickerGroupItem;

/** Represents a tree node item. Normalises data for both groups and columns into one format */
interface ColumnPickerTreeNode {
    /** The name of the column or group. */
    name: string;
    /** The original ColumnPickerGroupItem or string */
    column: ColumnPickerGroupItem | string;
    /**  The level this node exists in the tree hierarchy (top level nodes are 0, grouped nodes are 1). */
    level?: number;
    /**  The names of the columns that are children of this node (if this node is a group). */
    children?: string[];
    /**  A flag to identify group nodes. */
    expandable?: boolean;
    /**  A flag to track the current state of a group node (if this node is a group). */
    isExpanded?: boolean;
}

declare class ColumnPickerComponent implements OnChanges {
    private readonly _columnPicker;
    /** Access the LiveAnnounce to provide accessibility on reordering */
    private readonly _liveAnnouncer;
    /** We are using OnPush change detection so we must manually trigger CD */
    private readonly _changeDetectorRef;
    /** Sets the id of the column picker. */
    id: string;
    /** Define a list of all selected columns. */
    selected: ReadonlyArray<string | ColumnPickerGroupItem>;
    /** Define a list of columns that are always selected. The columns cannot be moved or reordered. */
    locked: ReadonlyArray<string>;
    /** Define a list of columns that are not selected or locked. All columns must have unique names, including columns in different groups. */
    deselected: ReadonlyArray<string | ColumnPickerGroupItem>;
    /** Define a custom selected title template. */
    selectedTitleTemplate: TemplateRef<void>;
    /** Define a custom deselected title template. */
    deselectedTitleTemplate: TemplateRef<void>;
    /** Define a custom template for deselected items. */
    deselectedTemplate: TemplateRef<string>;
    /** Define a custom template for selected items. */
    selectedTemplate: TemplateRef<string>;
    /** Define a custom template for locked items. */
    lockedTemplate: TemplateRef<string>;
    /** Define a custom template for the action buttons columns. */
    actionsTemplate: TemplateRef<ColumnPickerActionsContext>;
    /** Define a function to get the aria label of reorderable items in the selected column. */
    selectedAriaLabel: (column: string | ColumnPickerGroupItem, index: number) => string;
    /** Define a function to get the aria label of a group in the deselected list. */
    deselectedGroupAriaLabel: (column: string | ColumnPickerGroupItem, isExpanded: boolean) => string;
    /** Define a function that returns a column move announcement. */
    columnMovedAnnouncement: (column: string | ColumnPickerGroupItem, delta: number) => string;
    /** Define settings for the grouped deselected items. */
    set groups(groups: ColumnPickerGroup[]);
    get groups(): ColumnPickerGroup[];
    /** Define a comparator function used for sorting the deselected columns. */
    sort: (a: ColumnPickerGroupItem, b: ColumnPickerGroupItem) => number;
    /** Define the aria label for the add column button */
    addColumnAriaLabel: string;
    /** Define the aria label for the remove column button */
    removeColumnAriaLabel: string;
    /** Define the aria label for the add all column button */
    addAllColumnsAriaLabel: string;
    /** Define the aria label for the remove all column button */
    removeAllColumnsAriaLabel: string;
    /** Emits when the selected items change or the order of the selected items change. */
    selectedChange: EventEmitter<readonly (string | ColumnPickerGroupItem)[]>;
    /** Emits when the deselected items change. */
    deselectedChange: EventEmitter<readonly (string | ColumnPickerGroupItem)[]>;
    /** The Nested tree control used for the deselect tree */
    _treeControl: FlatTreeControl<ColumnPickerTreeNode>;
    /** A tree-friendly representation of the deselected data */
    _treeData: ColumnPickerTreeNode[];
    /** Data source observable bound to the tree control */
    _treeDataSource: ArrayDataSource<ColumnPickerTreeNode>;
    /** The remaining selectable columns in the deselected list */
    _availableDeselectedColumns: number;
    /** An array of items that are currently selected in the left column. */
    _deselectedSelection: ReadonlyArray<string | ColumnPickerGroupItem>;
    /** An array of items that are currently selected in the right column. */
    _selectedSelection: ReadonlyArray<string | ColumnPickerGroupItem>;
    /** Cache selection during reordering */
    private _selection;
    /** Shallow copy of selection for reordering directive */
    _storedSelection: Array<string | ColumnPickerGroupItem>;
    /** Get the elements for the selected items */
    selectedElements: QueryList<ElementRef>;
    ngOnChanges(changes: SimpleChanges): void;
    /** Parse data into suitable format for the FlatTreeComponent to understand and initialize deselect tree */
    private rebuildDeselectTree;
    /** A function that can be called to add columns. If no columns are passed to the function, the items that are selected in the left column will be added. */
    addColumns(columns?: ReadonlyArray<string | ColumnPickerGroupItem>): void;
    /** A function that can be called to remove columns. If no columns are passed to the function, the items that are selected in the right column will be removed. */
    removeColumns(columns?: ReadonlyArray<string | ColumnPickerGroupItem>): void;
    /** A function that can be called to add all columns. */
    addAllColumns(): void;
    /** A function that can be called to remove all columns. */
    removeAllColumns(): void;
    /** Ensure we don't select while dragging */
    storeSelection(): void;
    /** Restore the selection once dragging ends */
    restoreSelection(): void;
    /** Update when reordering has occurred */
    onReorder(): void;
    /** Get an aria label for deselected list groups */
    private getDefaultDeselectedGroupAriaLabel;
    /** Get an aria label for reorderable items */
    private getDefaultSelectedAriaLabel;
    /** Get the announcement to read when a selected column is moved */
    getColumnMovedAnnouncement(column: string, delta: number): string;
    /** Perform a reorder with the keyboard */
    move(column: string | ColumnPickerGroupItem, delta: number): void;
    /** Provide a trackBy function for the reorderable options */
    selectedTrackBy(index: number, column: string | ColumnPickerGroupItem): string;
    /** Swap two elements in the selected columns array */
    private swap;
    /** Get the column name based on type */
    _getColumnName(item: string | ColumnPickerGroupItem): string;
    /** Check if tree group has visible children */
    _nodeHasChildren(_: number, node: ColumnPickerTreeNode): boolean;
    _nodeHasAvailableChildren(node: ColumnPickerTreeNode): boolean;
    /** Check to see if current item should display in deselect tree */
    _shouldRenderNode(node: ColumnPickerTreeNode): boolean;
    /** Work backwards from the index of the current node to find the parent node  */
    private getTreeParent;
    /** Store the current count of nodes that are available for selection from the deselected list */
    private updateAvailableDeselectedColumns;
    /** Update the order of the items when reordering has changed */
    onReorderChange(model: string[]): void;
    /** Get the action context, ensuring that functions have a pre-bound context */
    _getActionContext(): ColumnPickerActionsContext;
    /** Change the expanded state of a node */
    _setNodeExpanded(node: ColumnPickerTreeNode, isExpanded: boolean): void;
    protected _isNodeSelected(name: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnPickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColumnPickerComponent, "ux-column-picker", never, { "id": { "alias": "id"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "deselected": { "alias": "deselected"; "required": false; }; "selectedTitleTemplate": { "alias": "selectedTitleTemplate"; "required": false; }; "deselectedTitleTemplate": { "alias": "deselectedTitleTemplate"; "required": false; }; "deselectedTemplate": { "alias": "deselectedTemplate"; "required": false; }; "selectedTemplate": { "alias": "selectedTemplate"; "required": false; }; "lockedTemplate": { "alias": "lockedTemplate"; "required": false; }; "actionsTemplate": { "alias": "actionsTemplate"; "required": false; }; "selectedAriaLabel": { "alias": "selectedAriaLabel"; "required": false; }; "deselectedGroupAriaLabel": { "alias": "deselectedGroupAriaLabel"; "required": false; }; "columnMovedAnnouncement": { "alias": "columnMovedAnnouncement"; "required": false; }; "groups": { "alias": "groups"; "required": false; }; "sort": { "alias": "sort"; "required": false; }; "addColumnAriaLabel": { "alias": "addColumnAriaLabel"; "required": false; }; "removeColumnAriaLabel": { "alias": "removeColumnAriaLabel"; "required": false; }; "addAllColumnsAriaLabel": { "alias": "addAllColumnsAriaLabel"; "required": false; }; "removeAllColumnsAriaLabel": { "alias": "removeAllColumnsAriaLabel"; "required": false; }; }, { "selectedChange": "selectedChange"; "deselectedChange": "deselectedChange"; }, never, never, true, never>;
}
/** Define a context for the column actions template */
interface ColumnPickerActionsContext {
    /** An array of items that are currently selected in the left column. */
    addSelection: ReadonlyArray<string | ColumnPickerGroupItem>;
    /** An array of items that are currently selected in the right column. */
    removeSelection: ReadonlyArray<string | ColumnPickerGroupItem>;
    /** A function that can be called to add columns. If no columns are passed to the function, the items that are selected in the left column will be added. */
    addColumns(columns?: ReadonlyArray<string | ColumnPickerGroupItem>): void;
    /** A function that can be called to remove columns. If no columns are passed to the function, the items that are selected in the right column will be removed. */
    removeColumns(columns?: ReadonlyArray<string | ColumnPickerGroupItem>): void;
    /** A function that can be called to add all columns. */
    addAllColumns(): void;
    /** A function that can be called to remove all columns. */
    removeAllColumns(): void;
}
/** An interface representing settings of groups defined in ColumnPickerGroupItem objects */
interface ColumnPickerGroup {
    /**  The name of the group this setting object is related to. */
    name: string;
    /**  Defines if this group will be expanded on load. This is an optional property. */
    expanded?: boolean;
}

declare class ResizableTableCellComponent implements OnInit, OnDestroy {
    private readonly _table;
    private readonly _elementRef;
    private readonly _renderer;
    /** Unsubscribe from all subscriptions on destroy */
    private readonly _onDestroy;
    /** Min width of the column*/
    private _minWidth;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Get the column index this cell is part of */
    private getCellIndex;
    /** Set the width of the column */
    private setColumnWidth;
    /** Set the flex value of the column */
    private setColumnFlex;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResizableTableCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ResizableTableCellComponent, "[uxResizableTableCell]", never, {}, {}, never, ["*"], true, never>;
}

declare class ResizableTableColumnComponent implements AfterViewInit, OnDestroy {
    private readonly _table;
    private readonly _elementRef;
    private readonly _renderer;
    /** Show/Hide column resizable handle */
    private _handleVisible;
    /** Disabled the column resizing */
    disabled: boolean;
    get handleVisible(): boolean;
    set handleVisible(value: boolean);
    /** Define the width of a column */
    set width(width: number);
    get width(): number;
    /** Emit the current column width */
    widthChange: EventEmitter<number>;
    /** Get the minimum width allowed by the column */
    get minWidth(): number;
    /** Determine if this column is a variable width column */
    isFixedWidth: boolean;
    /** Store the width specifically set by the input */
    private _width;
    /** Store the position of the mouse within the drag handle */
    private _offset;
    /** Min width of the column*/
    private _minWidth;
    /** Emit when all observables should be unsubscribed */
    private readonly _onDestroy;
    ngAfterViewInit(): void;
    /** Cleanup when component is destroyed */
    ngOnDestroy(): void;
    /** Get the natural pixel width of the column */
    getNaturalWidth(): number;
    /** When the dragging starts */
    onDragStart(event: MouseEvent): void;
    /** When the mouse is moved */
    onDragMove(event: MouseEvent, handle: HTMLDivElement): void;
    /** When the dragging ends */
    onDragEnd(): void;
    /** Shrink the column when the left arrow key is pressed */
    onMoveLeft(): void;
    /** Grow the column when the right arrow key is pressed */
    onMoveRight(): void;
    /** Get the column index this cell is part of */
    getCellIndex(): number;
    /** The percentage width of the column */
    private setColumnWidth;
    /** The flex width of the column */
    private setColumnFlex;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResizableTableColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ResizableTableColumnComponent, "[uxResizableTableColumn]", never, { "disabled": { "alias": "disabled"; "required": false; }; "handleVisible": { "alias": "handleVisible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "widthChange": "widthChange"; }, never, ["*", "ux-column-sorting"], true, never>;
}

declare abstract class BaseResizableTableService implements OnDestroy {
    abstract type: ResizableTableType;
    /** Emit an event whenever a column is resized */
    onResize$: Subject<void>;
    /** Store the current width of the table */
    tableWidth: number;
    /** Determine if we are currently resizing */
    isResizing$: BehaviorSubject<boolean>;
    /** Indicate when the columns are ready */
    isInitialised$: BehaviorSubject<boolean>;
    /** Store the percentage widths of each column */
    columns: ReadonlyArray<number>;
    abstract resizeColumn(index: number, delta: number, isDragging?: boolean): void;
    abstract setColumns(columns: QueryList<ResizableTableColumnComponent>): void;
    abstract setUniformWidths(): void;
    abstract getColumnDisabled(index: number): boolean;
    /** Cleanup when service is disposed */
    ngOnDestroy(): void;
    /** Update the resizing state */
    setResizing(isResizing: boolean): void;
    /** Get the width of a column in a specific unit */
    getColumnWidth(index: number, unit: ColumnUnit, columns?: ReadonlyArray<number>): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseResizableTableService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BaseResizableTableService>;
}
declare enum ColumnUnit {
    Pixel = 0,
    Percentage = 1
}
declare enum ResizableTableType {
    Standard = 0,
    Expand = 1
}

declare abstract class BaseResizableTableDirective implements OnDestroy {
    protected readonly _table: BaseResizableTableService;
    protected readonly _elementRef: ElementRef<HTMLTableElement>;
    protected readonly _renderer: Renderer2;
    readonly resize: ResizeService;
    columns: QueryList<ResizableTableColumnComponent>;
    /** Unsubscribe from the observables */
    protected _onDestroy: Subject<void>;
    /** Store the initialised state of the table */
    protected _initialised: boolean;
    constructor();
    /** Cleanup after the component is destroyed */
    ngOnDestroy(): void;
    /** Set all resizable columns to the same width */
    setUniformWidths(): void;
    /** Get the smallest tbody width taking into account scrollbars (uxFixedHeaderTable) */
    protected getScrollWidth(): number;
    abstract onTableReady(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseResizableTableDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseResizableTableDirective, never, never, {}, {}, never, never, true, never>;
}

declare class ResizableExpandingTableDirective extends BaseResizableTableDirective implements AfterViewInit {
    private readonly _platformId;
    /** Get all the column headers */
    columns: QueryList<ResizableTableColumnComponent>;
    /** Has horizontal overflow */
    _overflowX: boolean;
    constructor();
    ngAfterViewInit(): void;
    /**
     * If this is being used within a modal the table width may initially be zero. This can cause some issues when it does actually appear
     * visibily on screen. We should only setup the table once we actually have a width/
     */
    onTableReady(): void;
    /** Force the layout to recalculate */
    updateLayout(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResizableExpandingTableDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ResizableExpandingTableDirective, "[uxResizableExpandingTable]", ["ux-resizable-expanding-table"], {}, {}, ["columns"], never, true, never>;
}

declare class ResizableTableDirective extends BaseResizableTableDirective {
    /** Get all the column headers */
    columns: QueryList<ResizableTableColumnComponent>;
    constructor();
    /**
     * If this is being used within a modal the table width may initially be zero. This can cause some issues when it does actually appear
     * visibily on screen. We should only setup the table once we actually have a width/
     */
    onTableReady(): void;
    /** Force the layout to recalculate */
    updateLayout(): void;
    /**
     * We should hide any horizontal overflow whenever we are resizing, this is because when we are dragging a column
     * we must set the column widths in pixel values as percentages cause some jankiness when moving them. However pixel
     * values are less precise and can in some cases cause overflow, so we should hide overflow when we are resizing
     */
    private setOverflow;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResizableTableDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ResizableTableDirective, "[uxResizableTable]", ["ux-resizable-table"], {}, {}, ["columns"], never, true, never>;
}

declare class SelectionItemDirective<T> implements OnInit, OnChanges, OnDestroy {
    readonly focusIndicatorService: FocusIndicatorService;
    private readonly _selectionService;
    private readonly _elementRef;
    private readonly _managedFocusContainerService;
    private readonly _changeDetector;
    /** Defines the data associated with this item. */
    uxSelectionItem: T;
    /** Defines whether or not this item is currently selected. */
    set selected(selected: boolean);
    get selected(): boolean;
    /** Defines the tab index of the row */
    tabindex: number;
    /** Determine whether or not this item can be selected */
    set uxSelectionDisabled(isDisabled: boolean);
    /** Whether aria-selected is added to the host element */
    set addAriaAttributes(value: boolean);
    get addAriaAttributes(): boolean;
    /** Defines whether or not this item is currently selected. */
    selectedChange: EventEmitter<boolean>;
    /** Store whether this item is the focusable item */
    active: boolean;
    /** Store the focused state of the element */
    isFocused: boolean;
    get attrTabIndex(): number;
    /** Store the current selected state */
    private _selected;
    /** Store the disabled state */
    private _isDisabled;
    /** Store the tab indexed if using the managed focus container */
    private _managedTabIndex;
    /** Determine if there is a pending state change as we debounce before emitting */
    private _hasPendingStateChange;
    /** Subscription to the selection state observable. */
    private _selectionStateSubscription;
    /** Store value for _addAriaAttributes */
    private _addAriaAttributes;
    /** Automatically unsubscribe when the component is destroyed */
    private readonly _onDestroy;
    /** The the instance of the focus indicator */
    private readonly _focusIndicator;
    constructor();
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    click(event: MouseEvent): void;
    mousedown(event: MouseEvent): void;
    keydown(event: KeyboardEvent): void;
    focus(): void;
    /**
     * Select this item using the current strategy
     */
    select(): void;
    /**
     * Deselect this item using the current strategy
     */
    deselect(): void;
    private updateSelectionItem;
    static ngAcceptInputType_addAriaAttributes: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectionItemDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SelectionItemDirective<any>, "[uxSelectionItem]", ["ux-selection-item"], { "uxSelectionItem": { "alias": "uxSelectionItem"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; "uxSelectionDisabled": { "alias": "uxSelectionDisabled"; "required": false; }; "addAriaAttributes": { "alias": "addAriaAttributes"; "required": false; }; }, { "selectedChange": "selectedChange"; }, never, never, true, never>;
}

declare class SelectionStrategy<T = any> {
    protected selectionService?: SelectionService<T>;
    constructor(selectionService?: SelectionService<T>);
    setSelectionService(selectionService: SelectionService<T>): void;
    mousedown(event: MouseEvent, data: T): void;
    click(event: MouseEvent, data: T): void;
    keydown(event: KeyboardEvent, data: T): void;
    /**
     * Select the item - default behavior
     */
    select(...data: T[]): void;
    /**
     * Replace the current selection with the list of items specified
     */
    selectOnly(...data: T[]): void;
    /**
     * Toggle the item's selected state - default behavior
     */
    toggle(...data: T[]): void;
    /**
     * Deselect the item - default behavior
     */
    deselect(...data: T[]): void;
    /**
     * Select all items - default behavior
     */
    selectAll(): void;
    /**
     * Deselect all items - default behavior
     */
    deselectAll(): void;
    destroy(): void;
}

declare class SelectionService<T> implements OnDestroy {
    /** Store the current set of selectable items and ensure an item can be focused */
    set dataset(dataset: ReadonlyArray<T>);
    /** Get the current set of selectable items */
    get dataset(): ReadonlyArray<T>;
    /** The active selection strategy that defines how selections can be made */
    strategy: SelectionStrategy<T>;
    /** Define if selections can be performed on any items */
    isEnabled: boolean;
    /** Define if the mouse can be used to perform selections */
    isClickEnabled: boolean;
    /** Define if the keyboard can be used to perform selections */
    isKeyboardEnabled: boolean;
    /** Define the currently focused item */
    readonly focus$: BehaviorSubject<T>;
    /** Define the currently active item */
    readonly active$: BehaviorSubject<T>;
    /** Store the current list of selected items as an array */
    readonly selection$: BehaviorSubject<T[]>;
    /** Store the active item */
    private _active;
    /** Store the current set of selectable items */
    private _dataset;
    /** Store the selection strategy that should be destroyed */
    private _strategyToDestroy;
    /** Store the current selection in a set */
    private readonly _selection;
    /** Store the current disabled items in a set */
    private readonly _disabled;
    ngOnDestroy(): void;
    /**
     * If the item is not currently selected then add it
     * to the list of selected items
     */
    select(...selections: T[]): void;
    /**
     * Deselect all currently selected items and replace with a new selection
     */
    selectOnly(...selection: T[]): void;
    /**
     * Remove an item from the list of selected items
     */
    deselect(...selections: T[]): void;
    /**
     * Remove all items from the list of selected items
     */
    deselectAll(): void;
    /**
     * Toggle the selected state of any specified items
     */
    toggle(...selections: T[]): void;
    /**
     * Determine whether or not a specific item is currently selected
     */
    isSelected(data: T): boolean;
    /**
     * Return an observable specifically for notifying the subscriber
     * only when the selection state of a specific object has changed
     */
    getSelectionState(data: T): Observable<boolean>;
    /**
     * Define how selections should be performed.
     * This allows us to use an strategy pattern to handle the various keyboard
     * and mouse interactions while keeping each mode separated and
     * easily extensible if we want to add more modes in future!
     */
    setStrategy(mode: SelectionMode | SelectionStrategy<T>): void;
    /**
     * Set the current active item
     */
    activate(data: T): void;
    /**
     * Deactive all items
     */
    deactivate(): void;
    /**
     * Return the next or previous sibling of the current active item.
     * @param previous If true, the previous sibling will be returned.
     */
    getSibling(previous?: boolean): T;
    /**
     * Activate the sibling of the current active item.
     * If previous is set to true the previous sibling will be activated
     * rather than the next sibling. This function will also return the
     * data of the newly activated sibling
     */
    activateSibling(previous?: boolean): T;
    setDisabled(disabled: boolean): void;
    /** Store the disabled state of an item */
    setItemDisabled(item: T, isDisabled: boolean): void;
    private selectionHasMutated;
    private setFirstItemFocusable;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectionService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SelectionService<any>>;
}
type SelectionMode = 'simple' | 'row' | 'row-alt';

declare class SelectionDirective<T> implements AfterContentInit, OnDestroy {
    readonly _selectionService: SelectionService<T>;
    readonly _cdRef: ChangeDetectorRef;
    /** Defines the items that should be selected. */
    set uxSelection(items: Array<T> | ReadonlyArray<T>);
    /** Can be used to enabled/disable selection behavior. */
    set disabled(disabled: boolean);
    /**
     * Defines the selection behavior. Alternatively, custom selection behavior can be defined by defining a
     * class which extends SelectionStrategy, and providing an instance of the custom class to this property.
     * See below for details of the SelectionStrategy class.
     */
    set mode(mode: SelectionMode | SelectionStrategy<T>);
    /**
     * Can be used to enable/disable click selection on items. This can be used to manually control the selection of an item,
     * for example, binding the selection state to a checkbox.
     */
    set clickSelection(isClickEnabled: boolean);
    /** Can be used to enable/disable keyboard navigation on items. Use this if you wish to provide custom keyboard controls for selection. */
    set keyboardSelection(isKeyboardEnabled: boolean);
    /**
     * The full set of selection items.
     * Only needed if the full set of `uxSelectionItem`s is not available, e.g. within a virtual scroll container.
     */
    set selectionItems(value: T[]);
    /** The tabstop of the selection outer element */
    tabindex: string | number;
    /** This event will be triggered when there is a change to the selected items. It will contain an array of the currently selected items. */
    uxSelectionChange: EventEmitter<T[]>;
    /** Access all items within the list */
    items: QueryList<SelectionItemDirective<T>>;
    /** Unsubscribe from all observables on component destroy */
    private readonly _onDestroy;
    /** Store the previous selection so we don't emit more than we have to */
    private _lastSelection;
    /** Whether a value has been provided to the `selectionItems` input. */
    private _hasExplicitDataset;
    constructor();
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /**
     * Update the dataset to reflect the latest selection items
     */
    update(): void;
    /**
     * Select all the items in the list
     */
    selectAll(): void;
    /**
     * Deselect all currently selected items
     */
    deselectAll(): void;
    /**
     * Determine if the previous selection is the same as the current selection
     */
    private isSelectionChanged;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectionDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SelectionDirective<any>, "[uxSelection]", ["ux-selection"], { "uxSelection": { "alias": "uxSelection"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "clickSelection": { "alias": "clickSelection"; "required": false; }; "keyboardSelection": { "alias": "keyboardSelection"; "required": false; }; "selectionItems": { "alias": "selectionItems"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; }, { "uxSelectionChange": "uxSelectionChange"; }, ["items"], never, true, never>;
}

declare class SelectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SelectionModule, never, [typeof SelectionDirective, typeof SelectionItemDirective], [typeof SelectionDirective, typeof SelectionItemDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SelectionModule>;
}

declare class TableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TableModule, never, [typeof i1.A11yModule, typeof AccessibilityModule, typeof i3$4.CdkTreeModule, typeof i2.CommonModule, typeof DragModule, typeof IconModule, typeof ResizeModule, typeof ReorderableModule, typeof SelectionModule, typeof ColumnPickerComponent, typeof ResizableTableDirective, typeof ResizableExpandingTableDirective, typeof ResizableTableColumnComponent, typeof ResizableTableCellComponent], [typeof ColumnPickerComponent, typeof ResizableTableDirective, typeof ResizableExpandingTableDirective, typeof ResizableTableColumnComponent, typeof ResizableTableCellComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TableModule>;
}

declare class TimelineComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimelineComponent, "ux-timeline", never, {}, {}, never, ["*"], true, never>;
}

declare class TimelineEventComponent {
    /** Define the id for the event */
    id: string;
    /** Define the badge color */
    badgeColor: string;
    /** Define the title to display in the badge */
    badgeTitle: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineEventComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimelineEventComponent, "ux-timeline-event", never, { "id": { "alias": "id"; "required": false; }; "badgeColor": { "alias": "badgeColor"; "required": false; }; "badgeTitle": { "alias": "badgeTitle"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class TimelineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TimelineModule, never, [typeof i2.CommonModule, typeof IconModule, typeof TimelineComponent, typeof TimelineEventComponent], [typeof TimelineComponent, typeof TimelineEventComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TimelineModule>;
}

declare class ToggleSwitchComponent implements ControlValueAccessor, FocusableControl {
    private readonly _changeDetector;
    /** Provide a default unique id value for the toggle switch */
    _toggleSwitchId: string;
    /** Specify a unique id for the element. */
    id: string;
    /** Specify a form name for the input element. */
    name: string | null;
    /** Binding for the state of the switch; `true` for "on" and `false` for "off." */
    value: boolean;
    /** Specify a tabindex. */
    tabindex: number;
    /** If set to `false` the switch will not be updated when clicking on it, can be used if something else is updating the state of the switch. */
    clickable: boolean;
    /** If this value is set to `true` then the toggle switch will be disabled. */
    disabled: boolean;
    /** Specify an aria label for the input element */
    ariaLabel: string;
    /** Specify an aria labelledby property for the input element */
    ariaLabelledby: string;
    /** Specified if this is a required input. */
    required: boolean;
    /** Emits when `value` has been changed. */
    valueChange: EventEmitter<boolean>;
    /** Get the focus indicator to set focus */
    _focusIndicator?: FocusIndicatorDirective;
    /** Determine if the underlying input component has been focused with the keyboard */
    _focused: boolean;
    /** Used to inform Angular forms that the component has been touched */
    onTouchedCallback: () => void;
    /** Used to inform Angular forms that the component value has changed */
    onChangeCallback: (_: unknown) => void;
    toggle(): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: () => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    /** Focus the input element */
    focus(origin: FocusOrigin): void;
    setInputTabIndex(tabindex: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToggleSwitchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToggleSwitchComponent, "ux-toggleswitch", never, { "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; "value": { "alias": "value"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; "clickable": { "alias": "clickable"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "ariaLabel": { "alias": "aria-label"; "required": false; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, { "valueChange": "valueChange"; }, never, ["*"], true, never>;
}

declare class ToggleSwitchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ToggleSwitchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ToggleSwitchModule, never, [typeof AccessibilityModule, typeof i3$2.FormsModule, typeof ToggleSwitchComponent], [typeof ToggleSwitchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ToggleSwitchModule>;
}

declare class ToolbarSearchButtonDirective {
    private readonly _elementRef;
    /** Emit whenever the button is clicked */
    clicked: EventEmitter<void>;
    /** Get the width of the button element */
    get width(): number;
    clickHandler(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarSearchButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarSearchButtonDirective, "[uxToolbarSearchButton]", never, {}, { "clicked": "clicked"; }, never, never, true, never>;
}

declare const TOOLBAR_SEARCH_VALUE_ACCESSOR: {
    provide: i0.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: i0.Type<any>;
    multi: boolean;
};
declare class ToolbarSearchFieldDirective implements ControlValueAccessor {
    private readonly _elementRef;
    private readonly _changeDetector;
    /** Emit whenever the escape key is pressed */
    cancel: EventEmitter<void>;
    /** Emit whenever the enter key is pressed */
    submitted: EventEmitter<string>;
    /** Get the current value of the input control */
    get text(): string;
    /** For use with the Forms and ReactiveForms */
    private onTouchedCallback;
    /** Call this function with the latest value to update ngModel or formControl name */
    private onChangeCallback;
    focus(): void;
    blur(): void;
    /** Clear the input, if we have an ngModel reset its value otherwise just set the input value to empty */
    clear(): void;
    onEnter(): void;
    onEscape(): void;
    onInput(): void;
    /** Update the input value based on ngModel or formControl */
    writeValue(value: string): void;
    /** Register a function to update form control */
    registerOnChange(fn: any): void;
    /** Register a function to mark form control as touched */
    registerOnTouched(fn: any): void;
    /** Update the value in all required places */
    private setValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarSearchFieldDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarSearchFieldDirective, "[uxToolbarSearchField]", never, {}, { "cancel": "cancel"; "submitted": "submitted"; }, never, never, true, never>;
}

declare class ToolbarSearchComponent implements AfterContentInit, OnDestroy {
    private readonly _platformId;
    private readonly _elementRef;
    private readonly _colorService;
    private readonly _renderer;
    /** The direction in which the search box will expand. If the search button is aligned to the right edge of the container, specify left. */
    direction: 'left' | 'right';
    /** Whether the color scheme is inverted. For use when the component is hosted on a dark background, e.g. the masthead. */
    inverse: boolean;
    /** Indicate whether or not the search field should always be expanded */
    alwaysExpanded: boolean;
    /** Whether the input field is visible. Use this to collapse or expand the control in response to other events. */
    set expanded(value: boolean);
    get expanded(): boolean;
    set background(value: string);
    /** Emitted when the expanded state changes */
    expandedChange: EventEmitter<boolean>;
    /**
     * Emitted when a search query has been submitted, either by pressing enter when the search field has focus, or by clicking the search button
     * when the search field contains text. The event contains the search text.
     */
    search: EventEmitter<string>;
    /** Return the correct animation based on the expanded state */
    get _expandedAnimation(): {
        value: string;
        params: {
            initialWidth: string;
        };
    };
    /** Access the input field element */
    field: ToolbarSearchFieldDirective;
    /** Access the search button element */
    button: ToolbarSearchButtonDirective;
    /** Store the CSS position value as this may change to absolute */
    _position: string;
    /** Store the active background color */
    _backgroundColor: string;
    /** Store the expanded state */
    private _expanded;
    /** Store the programmatically created placeholder element */
    private _placeholder;
    /** Unsubscribe from all subscriptions on component destroy */
    private readonly _onDestroy;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    animationStart(event: AnimationEvent): void;
    animationDone(event: AnimationEvent): void;
    /** Programmatically create a placeholder element */
    private createPlaceholder;
    /** Update the display state of the placeholder node */
    private setPlaceholderVisible;
    /** Set the placeholder height to match the height of this component. */
    private setPlaceholderHeight;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarSearchComponent, "ux-toolbar-search", never, { "direction": { "alias": "direction"; "required": false; }; "inverse": { "alias": "inverse"; "required": false; }; "alwaysExpanded": { "alias": "alwaysExpanded"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "background": { "alias": "background"; "required": false; }; }, { "expandedChange": "expandedChange"; "search": "search"; }, ["field", "button"], ["*"], true, never>;
}

declare class ToolbarSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ToolbarSearchModule, never, [typeof i2.CommonModule, typeof ToolbarSearchComponent, typeof ToolbarSearchFieldDirective, typeof ToolbarSearchButtonDirective], [typeof ToolbarSearchComponent, typeof ToolbarSearchFieldDirective, typeof ToolbarSearchButtonDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ToolbarSearchModule>;
}

/**
 * This implementation is inspired by the CDK virtual for:
 * https://github.com/angular/material2/blob/master/src/cdk/scrolling/virtual-for-of.ts
 * However the CDK requires a container component which limits use in places such
 * as fixed header tables, so this is a more generic implementation that does not
 * require a parent element but instead uses an attribute on the parent container instead
 */
declare class VirtualForDirective<T> implements OnInit, DoCheck, OnDestroy {
    /** A reference to the container element where we will insert elements. */
    private readonly _viewContainerRef;
    /** The template for all items */
    private readonly _templateRef;
    /** Gets the set of Angular differs for detecting changes. */
    private readonly _differs;
    /** Get the renderer to perform DOM manipulation */
    private readonly _renderer;
    private readonly _changeDetector;
    /** A service to share values between the container and child elements */
    private readonly _virtualScroll;
    /** Store the list of items to display */
    set uxVirtualForOf(dataset: T[]);
    /** Provide a trackBy function to optimize rendering */
    uxVirtualForTrackBy: TrackByFunction<T> | undefined;
    /** The instance of the differ we create */
    private _differ;
    /** Keep a local reference to the dataset */
    private _dataset;
    /** Store the currently rendered range */
    private _renderedRange;
    /** Store a list of all the currently rendered items */
    private _renderedItems;
    /** Indicate whether we need to perform a view update */
    private _isDirty;
    /** Store a cache of recently disposed views for reuse */
    private readonly _templateCache;
    /** Limit the size of the cache as it can use a lot of memory */
    private readonly _cacheSize;
    /** Unsubscribe from all observables */
    private readonly _onDestroy;
    constructor();
    ngOnInit(): void;
    ngDoCheck(): void;
    ngOnDestroy(): void;
    /** If an itemSize is not specified we need to calculate it */
    getHeight(context: T, length: number): number;
    /** Determine if the range has changed (performance optimization) */
    private isRangeSame;
    private onRangeChange;
    /** Determine which items have changed */
    private getChanges;
    /** Insert, move and remove any items within the view */
    private applyChanges;
    updateContexts(): void;
    private createView;
    private defaultTrackBy;
    static ɵfac: i0.ɵɵFactoryDeclaration<VirtualForDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<VirtualForDirective<any>, "[uxVirtualFor][uxVirtualForOf]", never, { "uxVirtualForOf": { "alias": "uxVirtualForOf"; "required": false; }; "uxVirtualForTrackBy": { "alias": "uxVirtualForTrackBy"; "required": false; }; }, {}, never, never, true, never>;
}
/** We want to supply the same properties as `ngFor` */
interface VirtualForOfContext<T> {
    $implicit: T;
    index: number;
    count: number;
    first: boolean;
    last: boolean;
    even: boolean;
    odd: boolean;
}

declare class VirtualForContainerComponent<T> implements AfterViewInit, OnDestroy {
    /** Get the ElementRef of the container element */
    private readonly _elementRef;
    /** A service to share values between the container and child elements */
    private readonly _virtualScroll;
    /** Handle key presses if there is a tabbable list */
    private readonly _tabbableList;
    /** Define the height of each virtual item */
    set itemSize(itemSize: number);
    get itemSize(): number;
    /** Store the container height */
    _totalHeight: number;
    /** Keep a local reference of the dataset */
    private _dataset;
    /** Store the current visible range */
    private _range;
    /** Indicate if the component has finished initialising */
    private _initialized;
    /** Unsubscribe from all observables */
    private readonly _onDestroy;
    /** Determine if this is a table */
    get _isTable(): boolean;
    /** Determine if this is a list */
    get _isList(): boolean;
    /** Access the uxVirtualFor child directive */
    virtualFor: VirtualForDirective<T>;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    updateContainer(): void;
    /** If cells are automatically getting their height detected you may want to update the size */
    recalculateCellSize(): void;
    onKeydown(event: KeyboardEvent, keyCode: number): void;
    private getScrollOffset;
    private getContainerHeight;
    static ɵfac: i0.ɵɵFactoryDeclaration<VirtualForContainerComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VirtualForContainerComponent<any>, "[uxVirtualForContainer]", never, { "itemSize": { "alias": "itemSize"; "required": false; }; }, {}, ["virtualFor"], ["*"], true, never>;
}

declare class VirtualForService<T> {
    /** Store the size of each item */
    itemSize: number;
    /** Emit the current dataset */
    dataset: ReplaySubject<T[]>;
    /** Emit the visible range */
    range: ReplaySubject<VirtualForRange>;
    static ɵfac: i0.ɵɵFactoryDeclaration<VirtualForService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VirtualForService<any>>;
}
interface VirtualForRange {
    start: number;
    end: number;
}

declare class VirtualScrollComponent<T> implements OnInit, AfterContentInit, OnChanges, OnDestroy {
    readonly resizeService: ResizeService;
    private readonly _elementRef;
    /** Provide the collection of items to display */
    collection: Observable<T[]>;
    /** Specify the height of each cell */
    cellHeight: number;
    /** Indicate whether pages should be loaded on scroll or button click */
    loadOnScroll: boolean;
    /** Emit when we need to load another page */
    loading: EventEmitter<number>;
    cellTemplate: TemplateRef<void>;
    loadingIndicatorTemplate: TemplateRef<void>;
    loadButtonTemplate: TemplateRef<void>;
    cells: BehaviorSubject<VirtualCell<T>[]>;
    scrollTop: number;
    isLoading: boolean;
    pageNumber: number;
    data: ReadonlyArray<T>;
    loadingComplete: boolean;
    private readonly _buffer;
    private _subscription;
    private _height;
    private readonly _onDestroy;
    constructor();
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    setupObservable(): void;
    renderCells(): void;
    getVisibleCells(): VirtualCell<T>[];
    getTotalHeight(): number;
    loadNextPage(): void;
    reset(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VirtualScrollComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VirtualScrollComponent<any>, "ux-virtual-scroll", never, { "collection": { "alias": "collection"; "required": false; }; "cellHeight": { "alias": "cellHeight"; "required": false; }; "loadOnScroll": { "alias": "loadOnScroll"; "required": false; }; }, { "loading": "loading"; }, ["cellTemplate", "loadingIndicatorTemplate", "loadButtonTemplate"], never, true, never>;
}
interface VirtualCell<T> {
    data: T;
    index: number;
}

declare class VirtualScrollLoadingDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<VirtualScrollLoadingDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<VirtualScrollLoadingDirective, "[uxVirtualScrollLoading]", never, {}, {}, never, never, true, never>;
}

declare class VirtualScrollLoadButtonDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<VirtualScrollLoadButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<VirtualScrollLoadButtonDirective, "[uxVirtualScrollLoadButton]", never, {}, {}, never, never, true, never>;
}

declare class VirtualScrollCellDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<VirtualScrollCellDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<VirtualScrollCellDirective, "[uxVirtualScrollCell]", never, {}, {}, never, never, true, never>;
}

declare class VirtualScrollModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VirtualScrollModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VirtualScrollModule, never, [typeof AccessibilityModule, typeof i2.CommonModule, typeof ResizeModule, typeof VirtualScrollComponent, typeof VirtualScrollLoadingDirective, typeof VirtualScrollLoadButtonDirective, typeof VirtualScrollCellDirective, typeof VirtualForContainerComponent, typeof VirtualForDirective], [typeof VirtualScrollComponent, typeof VirtualScrollLoadingDirective, typeof VirtualScrollLoadButtonDirective, typeof VirtualScrollCellDirective, typeof VirtualForContainerComponent, typeof VirtualForDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VirtualScrollModule>;
}

declare class AutoGrowDirective implements AfterViewInit {
    private readonly _elementRef;
    private readonly _renderer;
    constructor();
    ngAfterViewInit(): void;
    update(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AutoGrowDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AutoGrowDirective, "[uxAutoGrow]", never, {}, {}, never, never, true, never>;
}

declare class AutoGrowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AutoGrowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AutoGrowModule, never, [typeof AutoGrowDirective], [typeof AutoGrowDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AutoGrowModule>;
}

type BadgeVerticalPosition = 'above' | 'below';
type BadgeHorizontalPosition = 'before' | 'after';
type BadgeSize = 'small' | 'medium' | 'large';
declare class BadgeDirective implements AfterViewInit, OnChanges, OnDestroy {
    private readonly _element;
    private readonly _renderer;
    private readonly _colorService;
    private readonly _contrastService;
    private readonly _className;
    private readonly _darkColor;
    private readonly _lightColor;
    private _badgeElement;
    private _isNumber;
    /**
     * Directive parameter that sets the content of the badge
     */
    private _badgeDisplayContent;
    get badgeContent(): string | number;
    set badgeContent(badge: string | number);
    private _badgeContent;
    /**
     * Define the badge background color
     */
    get badgeColor(): string;
    set badgeColor(color: string);
    private _badgeColor;
    /**
     * Define the badge border color - if unset there is no border
     */
    get badgeBorderColor(): string;
    set badgeBorderColor(color: string);
    private _badgeBorderColor;
    /**
     * Set the badge vertical position in relation to the parent element
     */
    badgeVerticalPosition: BadgeVerticalPosition;
    /**
     * Set the badge horizontal position in relation to the parent element
     */
    badgeHorizontalPosition: BadgeHorizontalPosition;
    /**
     * Set if the badge overlaps parent content or flows after parent
     */
    badgeOverlap: boolean;
    /**
     * Max value that can be displayed - if string measures no. of characters,
     * if number checks against exact number not no. of characters
     */
    badgeMaxValue: number;
    /**
     * Badge size (based on CSS styles)
     */
    badgeSize: BadgeSize;
    /**
     * Hide badge from view
     */
    badgeHidden: boolean;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private setContent;
    private setBadgeColor;
    private setBadgeBorderColor;
    private setBadgeSize;
    private determineContentTextColor;
    private parseThemeColor;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BadgeDirective, "[uxBadge]", ["ux-badge"], { "badgeContent": { "alias": "uxBadge"; "required": false; }; "badgeColor": { "alias": "badgeColor"; "required": false; }; "badgeBorderColor": { "alias": "badgeBorderColor"; "required": false; }; "badgeVerticalPosition": { "alias": "badgeVerticalPosition"; "required": false; }; "badgeHorizontalPosition": { "alias": "badgeHorizontalPosition"; "required": false; }; "badgeOverlap": { "alias": "badgeOverlap"; "required": false; }; "badgeMaxValue": { "alias": "badgeMaxValue"; "required": false; }; "badgeSize": { "alias": "badgeSize"; "required": false; }; "badgeHidden": { "alias": "badgeHidden"; "required": false; }; }, {}, never, never, true, never>;
}

declare class BadgeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BadgeModule, never, [typeof ColorServiceModule, typeof AccessibilityModule, typeof BadgeDirective], [typeof BadgeDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BadgeModule>;
}

declare class FixedHeaderTableDirective<T> implements OnInit, OnDestroy {
    private readonly _elementRef;
    private readonly _renderer;
    private readonly _resizeService;
    /** Allow dataset changes to trigger re-layout */
    set dataset(_dataset: ReadonlyArray<T>);
    /** Define the table height */
    tableHeight: number | string;
    /** Emit when the table tries to load more data */
    tablePaging: EventEmitter<number>;
    /** Apply a class whenever the table has scrolled */
    _hasScrolled: boolean;
    /** Store the table head element */
    private _tableHead;
    /** Store the table body element */
    private _tableBody;
    /** Unsubscribe from all observables on destroy */
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /**
     * Get the table element
     * Primarily used by column width directive
     */
    getTable(): HTMLTableElement;
    /**
     * Update the size of the table header to account for the scrollbar.
     * This is important to keep the columns aligned
     */
    setLayout(): void;
    /**
     * Handle scroll events
     */
    private onScroll;
    static ɵfac: i0.ɵɵFactoryDeclaration<FixedHeaderTableDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FixedHeaderTableDirective<any>, "[uxFixedHeaderTable]", ["ux-fixed-header-table"], { "dataset": { "alias": "dataset"; "required": false; }; "tableHeight": { "alias": "tableHeight"; "required": false; }; }, { "tablePaging": "tablePaging"; }, never, never, true, never>;
}

declare class FixedHeaderTableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FixedHeaderTableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FixedHeaderTableModule, never, [typeof ResizeModule, typeof FixedHeaderTableDirective], [typeof FixedHeaderTableDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FixedHeaderTableModule>;
}

declare class FloatLabelDirective<T = string> implements OnInit, OnChanges, OnDestroy {
    private readonly _elementRef;
    private readonly _renderer;
    private readonly _autofillMonitor;
    set input(input: HTMLInputElement);
    get input(): HTMLInputElement;
    value: T;
    mode: 'focus' | 'input';
    raised: boolean;
    private _input;
    private _focused;
    private readonly _eventHandles;
    private _subscription;
    ngOnInit(): void;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    private hasText;
    private inputFocus;
    private inputBlur;
    private inputChange;
    static ɵfac: i0.ɵɵFactoryDeclaration<FloatLabelDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FloatLabelDirective<any>, "[uxFloatLabel]", never, { "input": { "alias": "uxFloatLabel"; "required": false; }; "value": { "alias": "value"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FloatLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FloatLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FloatLabelModule, never, [typeof FloatLabelDirective], [typeof FloatLabelDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FloatLabelModule>;
}

declare class HelpCenterService {
    items: BehaviorSubject<HelpCenterItem[]>;
    registerItem(item: HelpCenterItem): void;
    unregisterItem(item: HelpCenterItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpCenterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HelpCenterService>;
}
interface HelpCenterItem {
    icon?: string;
    title: string;
    select?: () => void;
}

declare class HelpCenterItemDirective implements OnInit, OnDestroy {
    private readonly _helpCenterService;
    uxHelpCenterItem: HelpCenterItem;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpCenterItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HelpCenterItemDirective, "[uxHelpCenterItem]", never, { "uxHelpCenterItem": { "alias": "uxHelpCenterItem"; "required": false; }; }, {}, never, never, true, never>;
}

declare class HelpCenterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpCenterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HelpCenterModule, never, [typeof HelpCenterItemDirective], [typeof HelpCenterItemDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HelpCenterModule>;
}

declare class HoverActionDirective implements OnDestroy {
    private readonly _elementRef;
    private readonly _hoverActionService;
    readonly focusIndicatorService: FocusIndicatorService;
    tabindex: number;
    active: boolean;
    focused: boolean;
    private readonly _focusIndicator;
    private readonly _onDestroy;
    constructor();
    ngOnDestroy(): void;
    focus(): void;
    onFocus(): void;
    onBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HoverActionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HoverActionDirective, "[uxHoverAction]", never, { "tabindex": { "alias": "tabindex"; "required": false; }; }, {}, never, never, true, never>;
}

declare class HoverActionContainerDirective implements OnInit, OnDestroy {
    private readonly _elementRef;
    private readonly _managedFocusContainerService;
    private readonly _hoverActionService;
    tabindex: number;
    active: boolean;
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    onHover(): void;
    onLeave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HoverActionContainerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HoverActionContainerDirective, "[uxHoverActionContainer]", never, { "tabindex": { "alias": "tabindex"; "required": false; }; }, {}, never, never, true, never>;
}

declare class HoverActionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HoverActionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HoverActionModule, never, [typeof AccessibilityModule, typeof HoverActionDirective, typeof HoverActionContainerDirective], [typeof HoverActionDirective, typeof HoverActionContainerDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HoverActionModule>;
}

declare class LayoutSwitcherItemDirective {
    private readonly _templateRef;
    private readonly _viewContainerRef;
    private readonly _config;
    private _embeddedView;
    getLayout(): TemplateRef<void>;
    getConfig(): LayoutSwitcherItem;
    activate(): void;
    deactivate(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutSwitcherItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<LayoutSwitcherItemDirective, "[uxLayoutSwitcherItem]", never, { "_config": { "alias": "uxLayoutSwitcherItem"; "required": false; }; }, {}, never, never, true, never>;
}
interface LayoutSwitcherItem {
    group?: string;
    minWidth?: number;
    maxWidth?: number;
}

declare class LayoutSwitcherDirective implements AfterContentInit, OnChanges {
    readonly resizeService: ResizeService;
    private readonly _elementRef;
    private readonly _viewContainerRef;
    group: string;
    private readonly _layouts;
    private _width;
    private _activeLayout;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    getActiveLayout(): LayoutSwitcherItemDirective | null;
    updateActiveLayout(): void;
    ngAfterContentInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutSwitcherDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<LayoutSwitcherDirective, "[uxLayoutSwitcher]", never, { "group": { "alias": "group"; "required": false; }; }, {}, ["_layouts"], never, true, never>;
}

declare class LayoutSwitcherModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutSwitcherModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LayoutSwitcherModule, never, [typeof ResizeModule, typeof LayoutSwitcherDirective, typeof LayoutSwitcherItemDirective], [typeof LayoutSwitcherDirective, typeof LayoutSwitcherItemDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LayoutSwitcherModule>;
}

declare class MenuNavigationItemDirective implements OnDestroy {
    readonly focusIndicatorService: FocusIndicatorService;
    private readonly _elementRef;
    private readonly _menuNavigationService;
    /** Emit when this menu is activated */
    activated: EventEmitter<void>;
    /** Unsubscribe from all observables on destroy */
    private readonly _onDestroy;
    /** Keep a reference to the focus indicator */
    private readonly _focusIndicator;
    constructor();
    ngOnDestroy(): void;
    setActive(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuNavigationItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MenuNavigationItemDirective, "[uxMenuNavigationItem]", never, {}, { "activated": "activated"; }, never, never, true, never>;
}

declare class MenuNavigationToggleDirective implements OnDestroy {
    readonly elementRef: ElementRef<any>;
    readonly focusIndicatorService: FocusIndicatorService;
    /** Define if the menu is open */
    get menuOpen(): boolean;
    set menuOpen(value: boolean);
    /** Define the position the menu appears relative to the button */
    menuPosition: 'top' | 'right' | 'bottom' | 'left';
    /** Emit when the menu open state changes */
    menuOpenChange: EventEmitter<boolean>;
    /** Emits whenever a key that opens the menu is pressed */
    keyEnter: EventEmitter<void>;
    /** Store the current menu open state */
    private _menuOpen;
    /** Store a reference to the focus indicator */
    private readonly _focusIndicator;
    constructor();
    ngOnDestroy(): void;
    focus(origin?: FocusOrigin): void;
    keydownHandler(event: KeyboardEvent): void;
    private isKeyMatch;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuNavigationToggleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MenuNavigationToggleDirective, "[uxMenuNavigationToggle]", ["uxMenuNavigationToggle"], { "menuOpen": { "alias": "menuOpen"; "required": false; }; "menuPosition": { "alias": "menuPosition"; "required": false; }; }, { "menuOpenChange": "menuOpenChange"; "keyEnter": "keyEnter"; }, never, never, true, never>;
}

declare class MenuNavigationDirective implements OnInit, OnDestroy {
    private readonly _menuNavigationService;
    /** Define the menu toggle button */
    toggleButton: MenuNavigationToggleDirective;
    /** Define the position of the toggle button relative to the menu */
    toggleButtonPosition: 'top' | 'right' | 'bottom' | 'left';
    /** Emit when the menu is no longer focused */
    navigatedOut: EventEmitter<KeyboardEvent>;
    /** Get the index of the currently active item */
    get activeIndex(): number;
    get menuItems(): ReadonlyArray<MenuNavigationItemDirective>;
    /** Determine if the menu currently has focus */
    private _isFocused;
    /** Unsubscribe from all observables on destroy */
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    focusFirst(): void;
    onFocusIn(): void;
    onFocusOut(): void;
    keydownHandler(event: KeyboardEvent): void;
    private moveNext;
    private movePrevious;
    private moveFirst;
    private moveLast;
    private moveToToggleButton;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuNavigationDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MenuNavigationDirective, "[uxMenuNavigation]", ["uxMenuNavigation"], { "toggleButton": { "alias": "toggleButton"; "required": false; }; "toggleButtonPosition": { "alias": "toggleButtonPosition"; "required": false; }; }, { "navigatedOut": "navigatedOut"; }, never, never, true, never>;
}

declare class MenuNavigationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuNavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MenuNavigationModule, never, [typeof AccessibilityModule, typeof MenuNavigationDirective, typeof MenuNavigationItemDirective, typeof MenuNavigationToggleDirective], [typeof MenuNavigationDirective, typeof MenuNavigationItemDirective, typeof MenuNavigationToggleDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MenuNavigationModule>;
}

declare class OverflowDirective implements OnInit, AfterViewInit, OnDestroy {
    private readonly _elementRef;
    /** Allow a observable to be used to check for overflow */
    trigger: Observable<void>;
    /** Allow overflow to be within a range before emitting */
    tolerance: number;
    /** Emit when there is a change to the overflow state - horizontal or vertical */
    uxOverflowObserver: EventEmitter<boolean>;
    /** Emit when there is a change to overflow on the horizontal axis */
    uxOverflowHorizontalObserver: EventEmitter<boolean>;
    /** Emit when there is a change to overflow on the vertical axis */
    uxOverflowVerticalObserver: EventEmitter<boolean>;
    /** Store the overflow state on both axis */
    private _state;
    /** Unsubscribe from all the observables */
    private readonly _onDestroy;
    /** Set up the trigger if specified */
    ngOnInit(): void;
    /** Perform an intial check for overflow */
    ngAfterViewInit(): void;
    /** Unsubscribe from the trigger */
    ngOnDestroy(): void;
    /** Programmatically trigger check for overflow */
    checkForOverflow(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OverflowDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OverflowDirective, "[uxOverflowObserver], [uxOverflowHorizontalObserver], [uxOverflowVerticalObserver]", ["ux-overflow-observer"], { "trigger": { "alias": "trigger"; "required": false; }; "tolerance": { "alias": "tolerance"; "required": false; }; }, { "uxOverflowObserver": "uxOverflowObserver"; "uxOverflowHorizontalObserver": "uxOverflowHorizontalObserver"; "uxOverflowVerticalObserver": "uxOverflowVerticalObserver"; }, never, never, true, never>;
}

declare class ObserversModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ObserversModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ObserversModule, never, [typeof OverflowDirective], [typeof OverflowDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ObserversModule>;
}

declare class ScrollIntoViewService {
    scrollIntoView(elem: HTMLElement, scrollParent: HTMLElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollIntoViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ScrollIntoViewService>;
}

declare class TreeGridState {
    readonly level: number;
    readonly setSize: number;
    readonly positionInSet: number;
    readonly loading$: BehaviorSubject<boolean>;
    constructor(level: number, setSize: number, positionInSet: number);
}

interface TreeGridItem {
    children?: TreeGridItem[];
    expanded?: boolean;
    state?: TreeGridState;
}

declare class TreeGridRowDirective implements OnInit, OnDestroy {
    private readonly _treeGridService;
    item: TreeGridItem;
    canExpand: boolean;
    set expanded(value: boolean);
    get expanded(): boolean;
    expandedChange: EventEmitter<boolean>;
    loading: boolean;
    private _expanded;
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    collapse(event?: Event): void;
    expand(event?: Event): void;
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeGridRowDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TreeGridRowDirective, "[uxTreeGridRow]", ["uxTreeGridRow"], { "item": { "alias": "uxTreeGridRow"; "required": false; }; "canExpand": { "alias": "canExpand"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "expandedChange": "expandedChange"; }, never, never, true, never>;
}

declare class TreeGridIndentDirective {
    readonly _row: TreeGridRowDirective;
    /** The amount each level should be indented by */
    set uxTreeGridIndent(value: number | undefined);
    get uxTreeGridIndent(): number | undefined;
    /** The padding value applied to each level */
    get indentation(): number;
    private _indent;
    static ngAcceptInputType_uxTreeGridIndent: NumberInput | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeGridIndentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TreeGridIndentDirective, "[uxTreeGridIndent]", never, { "uxTreeGridIndent": { "alias": "uxTreeGridIndent"; "required": false; }; }, {}, never, never, true, never>;
}

type TreeGridLoadFunction = (parent: TreeGridItem) => TreeGridItem[] | Promise<TreeGridItem[]> | Observable<TreeGridItem[]>;

declare class TreeGridDirective implements OnInit, OnDestroy {
    private readonly _changeDetector;
    private readonly _treeGridService;
    set data(data: TreeGridItem[]);
    set loadChildren(loadChildren: TreeGridLoadFunction);
    rowsChange: EventEmitter<TreeGridItem[]>;
    private readonly _onDestroy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeGridDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TreeGridDirective, "[uxTreeGrid]", never, { "data": { "alias": "uxTreeGrid"; "required": false; }; "loadChildren": { "alias": "loadChildren"; "required": false; }; }, { "rowsChange": "rowsChange"; }, never, never, true, never>;
}

declare class TreeGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TreeGridModule, never, [typeof TreeGridDirective, typeof TreeGridRowDirective, typeof TreeGridIndentDirective], [typeof TreeGridDirective, typeof TreeGridRowDirective, typeof TreeGridIndentDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TreeGridModule>;
}

declare class StringFilterPipe implements PipeTransform {
    transform(items: string[], value: string): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<StringFilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<StringFilterPipe, "stringFilter", true>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StringFilterPipe>;
}

declare class StringFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StringFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StringFilterModule, never, [typeof StringFilterPipe], [typeof StringFilterPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StringFilterModule>;
}

declare class TimelineChartPlugin {
    id: string;
    /** We only want to register the plugin once per application */
    private static _isRegistered;
    /** Register this plugin */
    static register(): void;
    isVersion3(): boolean;
    /**
     * When chart is initialised store the chart instance and context
     * for use outside lifecycle hooks.
     *
     * We should also supply default options for any options that have
     * not been specified by the consuming application.
     *
     * We also need to add some event listeners for events that Chart.js
     * does not inform us of.
     */
    beforeInit(chart: TimelineChart): void;
    /**
     * We want to setup some additional functionality
     * after the chart has initialized.
     */
    afterInit(chart: TimelineChart): void;
    /**
     * The timeline chart should have a subtle background
     * color behind the main chart area (excluding the axis area).
     * Suprisingly Chart.js does not support this out of the box
     * so we need to add this functionality but it should be behind
     * all chart elements.
     */
    beforeDraw(chart: TimelineChart): void;
    /**
     * Once the Chart elements have been drawn we want to draw the drag
     * handles and the overlay showing the selected region
     */
    afterDraw(chart: TimelineChart): void;
    /**
     * We want to update the cursor whenever the mouse is over
     * one of the drag handles. We have do calculate this manually
     * as there are no DOM element to add CSS to.
     */
    afterEvent(chart: TimelineChart, parentEvent: any): void;
    /**
     * Unbind from the event listeners we manually set up
     */
    destroy(chart: TimelineChart): void;
    /** Get the timeline options from the chart instance */
    private getOptions;
    /** Determine if this chart is using the timeline */
    private getEnabled;
    /** Get the timeline range from the chart instance */
    private getRange;
    /** Get the chart area but include any padding */
    private getChartArea;
    /** Get stored state inside the chart options */
    private getState;
    /** Store state inside the chart options */
    private setState;
    /** Call the callback with the latest range */
    private triggerOnChange;
    /** To make the chart accessible add some internal elements that can be focused */
    private setupAccessibility;
    /** Handle keyboard accessibility events */
    private onKeydown;
    /**
     * Handle range changes made with the keyboard as these are exempt from
     * many of the validation checks that are required when dragging only one
     * handle at a time.
     */
    private onRangeKeydown;
    /**
     * When the mouse is first pressed within a chart we should see if we are
     * currently over a drag handle to start the dragging
     */
    private onMouseDown;
    /** When the mouse is released we are no longer dragging */
    private onMouseUp;
    private handleMouseMove;
    private hideTooltip;
    private getOrCreateTooltip;
    private externalTooltipHandler;
    private tooltipPositioner;
    /** Update the range when dragged */
    private setRangeOnDrag;
    /**
     * Draw the background color in the region that sits behind all the chart content
     */
    private drawBackgroundColor;
    /** Draw the overlay that indicates the selected region */
    private drawSelection;
    /** Darw the drag handles */
    private drawHandles;
    /**
     * Update the CSS cursor on the canvas element if we are hovering over a drag handle
     */
    private setCursor;
    private resetCursor;
    private isHandleFocused;
    /** Determine if a position is within one of the drag handles */
    private isWithinHandle;
    /** Get the area a specific handle covers within the chart */
    private getHandleArea;
    /**
     * Get the minimum and maximum values on the x-axis
     */
    private getChartRange;
    /** Get the value for a given handle */
    private getHandleValue;
    private setHandleValue;
    private getHandleMinimum;
    private getHandleMaximum;
    private getOptionsWithDefaults;
}
/**
 * Directly exporting a file that is not an Angular component, module, etc..
 * can cause build issues. We can use a module that instantiates the plugin
 * instead of directly exporting the Chart.js plugin.
 */
declare class TimelineChartModule {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineChartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TimelineChartModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TimelineChartModule>;
}
declare enum TimelineHandle {
    Lower = "lower",
    Upper = "upper",
    Range = "range"
}
interface TimelineChartOptions {
    timeline?: {
        backgroundColor?: ChartColor;
        selectionColor?: ChartColor;
        onChange?: (lower: Date, upper: Date) => void;
        keyboard?: {
            step?: number;
        };
        handles?: {
            backgroundColor?: ChartColor;
            foregroundColor?: ChartColor;
            focusIndicatorColor?: ChartColor;
            tooltip?: {
                label: Function;
            };
        };
        range: {
            lower: Date;
            upper: Date;
            minimum?: number;
            maximum?: number;
            tooltip?: {
                label: Function;
            };
        };
    };
}
/**
 * Store internal state of the chart but don't expose it
 * in the public options interface
 */
interface TimelineChartStateOptions {
    timeline?: {
        state: TimelineChartState;
    };
}
interface TimelineChartState {
    handle?: TimelineHandle | null;
    mouseX?: number;
    onMouseDown?: (event: MouseEvent) => void;
    onMouseUp?: (event: MouseEvent) => void;
    onMouseEnter?: (event: MouseEvent) => void;
    onKeydown?: (event: KeyboardEvent) => void;
    lowerHandleFocus?: boolean;
    upperHandleFocus?: boolean;
    rangeHandleFocus?: boolean;
    lowerHandleElement?: HTMLDivElement;
    upperHandleElement?: HTMLDivElement;
    rangeHandleElement?: HTMLDivElement;
}
interface ChartArea {
    top: number;
    right: number;
    bottom: number;
    left: number;
}
type ChartColor = string | CanvasGradient | CanvasPattern;
interface TimelineChartConfig {
    config: {
        options: TimelineChartOptions & TimelineChartStateOptions;
    };
    chart: Chart;
}
type TimelineChart = Chart & TimelineChartConfig;

declare class OverlayPlacementService {
    /** Updates the position of the current menu. */
    updatePosition(overlayRef: OverlayRef, placement: string, alignment: string, customFallbackPlacement?: AnchorPlacement): void;
    /** Apply position to position strategy */
    private addPositions;
    /** Get the origin position based on the specified tooltip placement */
    private getOrigin;
    /** Calculate the overlay position based on the specified tooltip placement */
    private getOverlayPosition;
    /** Convert the alignment property to a valid CDK alignment value */
    private getVerticalAlignment;
    /** Inverts an overlay position. */
    private invertPosition;
    invertHorizontalPosition(y: string): 'top' | 'center' | 'bottom';
    private getFallbackPosition;
    static ɵfac: i0.ɵɵFactoryDeclaration<OverlayPlacementService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OverlayPlacementService>;
}

declare class PersistentDataModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PersistentDataModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PersistentDataModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PersistentDataModule>;
}

declare class PersistentDataService {
    /**
     * Save the item in some form of persistent storage
     */
    setItem(key: string, value: string, type?: PersistentDataStorageType): void;
    /**
     * Get a stored value from persistent storage
     */
    getItem(key: string, type?: PersistentDataStorageType): string;
    /**
     * Remove a stored value from persistent storage
     */
    removeItem(key: string, type?: PersistentDataStorageType): void;
    /**
     * Remove a stored value from persistent storage
     */
    clear(type?: PersistentDataStorageType): void;
    /**
     * Return the appropriate adapter based on the type requested
     */
    private getAdapter;
    static ɵfac: i0.ɵɵFactoryDeclaration<PersistentDataService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PersistentDataService>;
}
declare enum PersistentDataStorageType {
    LocalStorage = 0,
    Cookie = 1,
    SessionStorage = 2
}

declare abstract class StorageAdapter {
    abstract getItem(key: string): string;
    abstract setItem(key: string, value: string): void;
    abstract removeItem(key: string): void;
    abstract clear(): void;
    abstract getSupported(): StorageAdapter;
}

declare class CookieAdapter implements StorageAdapter {
    getItem(key: string): string;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
    clear(): void;
    getSupported(): StorageAdapter;
}

declare class LocalStorageAdapter implements StorageAdapter {
    getItem(key: string): string;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
    clear(): void;
    getSupported(): StorageAdapter;
}

declare class SessionStorageAdapter implements StorageAdapter {
    getItem(key: string): string;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
    clear(): void;
    getSupported(): StorageAdapter;
}

export { ACCESSIBILITY_OPTIONS_TOKEN, AccessibilityModule, AccessibilityOptionsService, AccordionComponent, AccordionModule, AccordionPanelComponent, AccordionPanelHeadingDirective, AccordionService, ActionDirection, AlertComponent, AlertIconDirective, AlertModule, AudioService, AudioServiceModule, AutoGrowDirective, AutoGrowModule, BadgeDirective, BadgeModule, BaseSearchComponent, BreadcrumbsComponent, BreadcrumbsModule, CHECKBOX_VALUE_ACCESSOR, COLOR_SET_TOKEN, CONDUITS, CardTabComponent, CardTabContentDirective, CardTabsModule, CardTabsService, CardTabsetComponent, CheckboxComponent, CheckboxModule, ClickOutsideDirective, ClickOutsideModule, Color, ColorContrastDirective, ColorPickerColor, ColorPickerComponent, ColorPickerModule, ColorService, ColorServiceModule, ColumnPickerComponent, ColumnSortingComponent, ColumnSortingDirective, ColumnSortingModule, ColumnSortingState, Conduit, ConduitComponent, ConduitModule, ConduitSubject, ConduitZone, ConduitZoneComponent, ContrastService, CookieAdapter, DashboardComponent, DashboardDragHandleDirective, DashboardGrabHandleDirective, DashboardModule, DashboardService, DashboardWidgetComponent, DateFormatterPipe, DateFormatterPipeModule, DatePickerHeaderEvent, DatePickerMode, DateRangeOptions, DateRangePicker, DateRangePickerComponent, DateRangePickerDirective, DateRangePickerModule, DateRangeService, DateTimePickerComponent, DateTimePickerConfig, DateTimePickerModule, DateTimePickerService, DefaultFocusIndicatorDirective, DragDirective, DragModule, DragService, DropDirective, DurationPipe, DurationPipeModule, EboxComponent, EboxContentDirective, EboxHeaderDirective, EboxModule, Facet, FacetCheckListComponent, FacetCheckListItemComponent, FacetClearButtonDirective, FacetContainerComponent, FacetDeselect, FacetDeselectAll, FacetHeaderComponent, FacetSelect, FacetService, FacetTypeaheadHighlight, FacetTypeaheadListComponent, FacetTypeaheadListItemComponent, FacetsModule, FileSizePipe, FileSizePipeModule, FilterAddEvent, FilterContainerComponent, FilterDropdownComponent, FilterDynamicComponent, FilterModule, FilterRemoveAllEvent, FilterRemoveEvent, FilterService, FilterTypeaheadHighlight, FixedHeaderTableDirective, FixedHeaderTableModule, FlippableCardBackDirective, FlippableCardComponent, FlippableCardFrontDirective, FlippableCardModule, FloatLabelDirective, FloatLabelModule, FloatingActionButtonComponent, FloatingActionButtonsComponent, FloatingActionButtonsModule, FocusIfDirective, FocusIfModule, FocusIndicator, FocusIndicatorDirective, FocusIndicatorOptionsDirective, FocusIndicatorOrigin, FocusIndicatorOriginDirective, FocusIndicatorOriginService, FocusIndicatorService, FocusWithinDirective, FocusableItemToken, FrameExtractionService, HelpCenterItemDirective, HelpCenterModule, HelpCenterService, HierarchyBarCollapsedComponent, HierarchyBarComponent, HierarchyBarModule, HierarchyBarNodeIconDirective, HierarchyBarStandardComponent, HoverActionContainerDirective, HoverActionDirective, HoverActionModule, ICON_OPTIONS_TOKEN, IconComponent, IconModule, IconService, IconType, InfiniteScrollDirective, InfiniteScrollLoadButtonDirective, InfiniteScrollLoadErrorEvent, InfiniteScrollLoadedEvent, InfiniteScrollLoadingDirective, InfiniteScrollLoadingEvent, InfiniteScrollModule, InputDropdownComponent, InputDropdownModule, ItemDisplayPanelComponent, ItemDisplayPanelContentDirective, ItemDisplayPanelFooterDirective, ItemDisplayPanelModule, LayoutSwitcherDirective, LayoutSwitcherItemDirective, LayoutSwitcherModule, LocalFocusIndicatorOptions, LocalStorageAdapter, ManagedFocusContainerDirective, ManagedFocusContainerService, MarqueeWizardComponent, MarqueeWizardModule, MarqueeWizardStepComponent, MarqueeWizardStepIconDirective, MediaPlayerBaseExtensionDirective, MediaPlayerComponent, MediaPlayerControlsExtensionComponent, MediaPlayerCustomControlDirective, MediaPlayerModule, MediaPlayerTimelineExtensionComponent, MenuComponent, MenuDividerComponent, MenuInitialFocusDirective, MenuItemComponent, MenuItemCustomControlDirective, MenuItemType, MenuModule, MenuNavigationDirective, MenuNavigationItemDirective, MenuNavigationModule, MenuNavigationToggleDirective, MenuTabbableItemDirective, MenuTriggerDirective, ModeDirection, NAVIGATION_MODULE_OPTIONS, NUMBER_PICKER_VALUE_ACCESSOR, NavigationComponent, NavigationItemComponent, NavigationLinkDirective, NavigationModule, NavigationService, NestedDonutChartComponent, NestedDonutChartModule, NotificationListComponent, NotificationModule, NotificationService, NumberPickerComponent, NumberPickerModule, ObserversModule, OrganizationChartAxis, OrganizationChartComponent, OrganizationChartModule, OverflowDirective, OverlayPlacementService, PAGINATION_CONTROL_VALUE_ACCESSOR, PageHeaderComponent, PageHeaderCustomMenuDirective, PageHeaderIconMenuComponent, PageHeaderModule, PageHeaderNavigationComponent, PaginationComponent, PaginationModule, PartitionMapComponent, PartitionMapModule, PartitionMapSegmentEventsDirective, PersistentDataModule, PersistentDataService, PersistentDataStorageType, PopoverComponent, PopoverDirective, PopoverModule, ProgressBarComponent, ProgressBarModule, RADIOBUTTON_VALUE_ACCESSOR, RADIO_GROUP_CONTROL_VALUE_ACCESSOR, RadioButtonComponent, RadioButtonGroupDirective, RadioButtonModule, ReorderableDirective, ReorderableHandleDirective, ReorderableModelDirective, ReorderableModule, ResizableExpandingTableDirective, ResizableTableCellComponent, ResizableTableColumnComponent, ResizableTableDirective, ResizeDirective, ResizeModule, ResizeService, Rounding, SELECT_VALUE_ACCESSOR, SPIN_BUTTON_VALUE_ACCESSOR, SankeyChart, SankeyChartComponent, SankeyChartModule, SankeyNodeDirective, ScrollIntoViewDirective, ScrollIntoViewIfDirective, ScrollIntoViewService, ScrollModule, SearchBuilderComponent, SearchBuilderFocusService, SearchBuilderGroupComponent, SearchBuilderGroupService, SearchBuilderModule, SearchBuilderOutletDirective, SearchBuilderService, SearchDateComponent, SearchDateRangeComponent, SearchSelectComponent, SearchTextComponent, SelectComponent, SelectListComponent, SelectListItemComponent, SelectListModule, SelectModule, SelectionDirective, SelectionItemDirective, SelectionModule, SelectionService, SelectionStrategy, SessionStorageAdapter, SidePanelCloseDirective, SidePanelComponent, SidePanelModule, SliderCalloutTrigger, SliderComponent, SliderModule, SliderSize, SliderSnap, SliderStyle, SliderThumb, SliderThumbEvent, SliderTickType, SliderType, SparkComponent, SparkModule, SpinButtonComponent, SpinButtonModule, SplitterAccessibilityDirective, StepChangingEvent, StepDirection, StorageAdapter, StringFilterModule, StringFilterPipe, TIME_PICKER_VALUE_ACCESSOR, TOOLBAR_SEARCH_VALUE_ACCESSOR, TabComponent, TabHeadingDirective, TabbableListDirective, TabbableListItemDirective, TabbableListService, TableModule, TabsetComponent, TabsetModule, TabsetService, TagInputComponent, TagInputEvent, TagInputModule, ThemeColor, TimePickerComponent, TimePickerModule, TimelineChartModule, TimelineChartPlugin, TimelineComponent, TimelineEventComponent, TimelineHandle, TimelineModule, ToggleSwitchComponent, ToggleSwitchModule, ToolbarSearchButtonDirective, ToolbarSearchComponent, ToolbarSearchFieldDirective, ToolbarSearchModule, TooltipComponent, TooltipDirective, TooltipModule, TooltipService, TreeGridDirective, TreeGridIndentDirective, TreeGridModule, TreeGridRowDirective, TreeGridState, TypeaheadComponent, TypeaheadKeyService, TypeaheadModule, TypeaheadOptionEvent, VirtualForContainerComponent, VirtualForDirective, VirtualForService, VirtualScrollCellDirective, VirtualScrollComponent, VirtualScrollLoadButtonDirective, VirtualScrollLoadingDirective, VirtualScrollModule, WizardComponent, WizardModule, WizardService, WizardStepComponent, colorSets, compareDays, dateComparator, dateRange, defaultConduitProps, defaultOptions, differenceBetweenDates, getIconType, getStartOfDay, gridify, isColumnPickerGroupItem, isDateAfter, isDateBefore, isKeyboardTrigger, isMouseTrigger, meridians, months, monthsShort, range, tick, timezoneComparator, timezones, uxIconset, weekdays, weekdaysShort };
export type { AccessibilityOptions, AlertType, AnchorAlignment, AnchorPlacement, AudioMetadata, BadgeHorizontalPosition, BadgeSize, BadgeVerticalPosition, BaseSearchComponentConfig, Breadcrumb, CardTabsBounds, ChartArea, ChartColor, ColorIdentifier, ColorSet, ColumnPickerActionsContext, ColumnPickerGroup, ColumnPickerGroupItem, ColumnSortingIndicatorContext, ColumnSortingOrder, ConduitEvent, ConduitMetadata, ConduitProperties, DashboardAction, DashboardCache, DashboardDimensions, DashboardLayoutData, DashboardLayoutDiff, DashboardOptions, DashboardPlaceholder, DashboardRegion, DashboardSpace, DashboardWidgetDimensions, DateFormatter, DateRangeTime, DateTimePickerTimezone, DragScrollEvent, ExtractedFrame, FacetEvent, FacetReorderEvent, FacetTypeaheadListConfig, Filter, FilterDynamicListConfig, FilterEvent, FocusIndicatorOptions, HelpCenterItem, HierarchyBarNode, HierarchyBarNodeChildren, IconChangeEvent, IconDefinition, IconModuleOptions, IconRotation, InfiniteScrollLoadFunction, LayoutSwitcherItem, MarqueeWizardStepContext, MediaPlayerBuffer, MediaPlayerBuffered, MediaPlayerType, NavigationItem, NavigationItemRouterOptions, NavigationModuleOptions, NestedDonutChartArc, NestedDonutChartData, NotificationListDirection, NotificationListPostion, NotificationOptions, NotificationRef, OrganizationChartConnector, OrganizationChartNode, OrganizationChartNodeContext, OrganizationChartPortalRef, OverlayTrigger, Page, PageHeaderIconMenu, PageHeaderIconMenuDropdownItem, PageHeaderNavigationAlignment, PageHeaderNavigationDropdownItem, PageHeaderNavigationItem, PageHeaderSecondaryNavigationItem, PartitionMapCustomSegmentContext, PartitionMapSegment, PartitionMapSegmentAnnouncementInfo, PartitionMapSegmentBase, PartitionMapSegmentWithChildren, PartitionMapSegmentWithValue, ReorderEvent, ResizeDimensions, SankeyColumn, SankeyLink, SankeyLinkInteraction, SankeyLinkPlot, SankeyNode, SankeyNodeContext, SankeyTooltipPosition, SearchBuilderComponentContext, SearchBuilderComponentDefinition, SearchBuilderFocus, SearchBuilderGroupOperator, SearchBuilderGroupQuery, SearchBuilderQuery, SearchDateConfig, SearchDateRangeConfig, SearchSelectConfig, SearchTextConfig, SelectionMode, SingleIconDefinition, SliderAriaOptions, SliderCallout, SliderHandleOptions, SliderKeyboardOptions, SliderOptions, SliderTick, SliderTickOptions, SliderTicksOptions, SliderTrackColors, SliderTrackOptions, SliderValue, StackableValue, TagApi, TagClassFunction, TagInputDisplayFunction, TagTemplateContext, Theme, TimelineChart, TimelineChartConfig, TimelineChartOptions, TimelineChartState, TimelineChartStateOptions, TreeGridItem, TreeGridLoadFunction, UxDragEvent, VirtualCell, VirtualForOfContext, VirtualForRange, WaveformPoint, WizardFooterContext, WizardValidEvent, YearRange };
